/* SALEK HYPERCORE — realtime AudioWorklet engine
   No heap allocations in process(). Block + control-rate modulation. */

const TAU = Math.PI * 2;
const WT_SIZE = 2048;
const WT_FRAMES = 64;
const MAX_VOICES = 12;
const UNI = 7;
const CR = 32;
const NUM_LFO = 8;
const NUM_MAT = 64;
const SEQ_STEPS = 64;
const LUT = 4096;

const SINE = new Float32Array(LUT + 1);
for (let i = 0; i <= LUT; i++) SINE[i] = Math.sin((TAU * i) / LUT);

function sinLut(ph) {
  const x = (ph - Math.floor(ph)) * LUT;
  const i = x | 0;
  return SINE[i] + (SINE[i + 1] - SINE[i]) * (x - i);
}
function clamp(x, a, b) {
  return x < a ? a : x > b ? b : x;
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}
function midiHz(n) {
  return 440 * Math.pow(2, (n - 69) / 12);
}
function expMap(x, lo, hi) {
  return lo * Math.pow(hi / lo, clamp(x, 0, 1));
}
function tanhF(x) {
  if (x < -3) return -1;
  if (x > 3) return 1;
  const x2 = x * x;
  return (x * (27 + x2)) / (27 + 9 * x2);
}
function curve01(t, c) {
  t = clamp(t, 0, 1);
  if (Math.abs(c) < 0.01) return t;
  const k = c * 3;
  if (k > 0) return Math.pow(t, 1 + k);
  return 1 - Math.pow(1 - t, 1 - k);
}
function polyblep(t, dt) {
  if (t < dt) {
    const x = t / dt;
    return x + x - x * x - 1;
  }
  if (t > 1 - dt) {
    const x = (t - 1) / dt;
    return x * x + x + x + 1;
  }
  return 0;
}

function analogWave(ph, dt, type, pwm) {
  const t = ph - Math.floor(ph);
  if (type === 0) return sinLut(t);
  if (type === 1) {
    const s = t < 0.5 ? 4 * t - 1 : 3 - 4 * t;
    return s + polyblep(t, dt) - polyblep((t + 0.5) % 1, dt);
  }
  if (type === 2) return 2 * t - 1 - polyblep(t, dt);
  if (type === 3) {
    let s = t < 0.5 ? 1 : -1;
    s += polyblep(t, dt);
    s -= polyblep((t + 0.5) % 1, dt);
    return s;
  }
  const w = clamp(pwm, 0.03, 0.97);
  let s = t < w ? 1 : -1;
  s += polyblep(t, dt);
  s -= polyblep((t + w) % 1, dt);
  return s;
}

function normalizeFrame(buf, off, size) {
  let peak = 1e-12;
  for (let i = 0; i < size; i++) peak = Math.max(peak, Math.abs(buf[off + i]));
  const g = 0.99 / peak;
  for (let i = 0; i < size; i++) buf[off + i] *= g;
}

function makeTable(fn, frames, size) {
  const data = new Float32Array(frames * size);
  for (let f = 0; f < frames; f++) {
    const t = frames === 1 ? 0 : f / (frames - 1);
    const off = f * size;
    for (let i = 0; i < size; i++) data[off + i] = fn(i / size, t);
    normalizeFrame(data, off, size);
  }
  return data;
}

function factoryTables() {
  const F = WT_FRAMES,
    S = WT_SIZE;
  const blSaw = (p, h) => {
    let s = 0;
    for (let n = 1; n <= h; n++) s += Math.sin(TAU * n * p) / n;
    return s * (2 / Math.PI);
  };
  const blSq = (p, h) => {
    let s = 0;
    for (let n = 1; n <= h; n += 2) s += Math.sin(TAU * n * p) / n;
    return s * (4 / Math.PI);
  };
  const tables = [];
  tables.push(
    makeTable((p, t) => {
      const saw = blSaw(p, 24),
        sq = blSq(p, 24);
      const tri = (2 / Math.PI) * Math.asin(Math.sin(TAU * p));
      const sine = Math.sin(TAU * p);
      if (t < 0.33) return lerp(saw, sq, t / 0.33);
      if (t < 0.66) return lerp(sq, tri, (t - 0.33) / 0.33);
      return lerp(tri, sine, (t - 0.66) / 0.34);
    }, F, S),
  );
  tables.push(makeTable((p, t) => blSaw(p, 2 + (t * 46) | 0), F, S));
  const vows = [
    [1, 3, 5],
    [1, 2.4, 7],
    [1, 5, 9],
    [1, 2.2, 4.4],
    [1, 1.8, 8],
  ];
  tables.push(
    makeTable((p, t) => {
      const i = t * 4;
      const a = vows[i | 0],
        b = vows[Math.min(4, (i | 0) + 1)],
        u = i - (i | 0);
      let s = 0;
      for (let k = 0; k < 3; k++) {
        const f = a[k] + (b[k] - a[k]) * u;
        s += Math.sin(TAU * f * p) * Math.exp(-0.08 * f);
      }
      return s;
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const r = 1.41 + t * 1.7;
      return (
        Math.sin(TAU * p) +
        0.55 * Math.sin(TAU * p * r) +
        0.32 * Math.sin(TAU * p * r * 1.61) +
        0.18 * Math.sin(TAU * p * (2 + t * 5))
      );
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const ratio = 1 + t * 11;
      return blSaw((p * ratio) % 1, 18) * (1 - p * 0.35);
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      let s = blSaw(p, 20);
      s = Math.sin(s * (1 + t * 6) * Math.PI);
      s = Math.abs(s) * 2 - 1;
      return Math.sin(s * (1 + t * 3));
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const mod = Math.sin(TAU * p * (1 + (t * 7) | 0));
      return Math.sin(TAU * p + mod * (0.4 + t * 8));
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const bars = [1, 0.7, 0.45, 0.6, 0.3, 0.25, 0.18, 0.12];
      let s = 0;
      for (let n = 0; n < 8; n++) s += Math.sin(TAU * p * (n + 1)) * bars[n] * (n < 2 + t * 6 ? 1 : 0.35 + t);
      return s;
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const h = 8 + t * 30;
      let s = 0;
      for (let n = 1; n <= h; n++) s += (Math.sin(TAU * n * p) / n) * (n > 6 ? 1 : 0.15);
      return tanhF(s * (2 + t * 4));
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      let s = 0;
      for (let n = 1; n <= 16; n++) s += Math.sin(TAU * n * (1 + t * 0.07 * n) * p) / (n * n);
      return s;
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const steps = Math.pow(2, 3 + t * 5);
      return Math.round(blSaw(p, 16) * steps) / steps;
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const r = 3.6 + t * 0.399;
      let x = 0.2 + p * 0.6;
      for (let i = 0; i < 8; i++) x = r * x * (1 - x);
      return x * 2 - 1;
    }, F, S),
  );
  tables.push(makeTable((p, t) => (p < 0.08 + t * 0.42 ? 1 : -1), F, S));
  tables.push(
    makeTable((p, t) => {
      let s = 0;
      const tilt = -0.2 - t * 1.4;
      for (let n = 1; n <= 40; n++) s += Math.sin(TAU * n * p) * Math.pow(n, tilt);
      return s;
    }, F, S),
  );
  tables.push(
    makeTable((p, t) => {
      const f1 = 2 + t * 4,
        f2 = 6 + Math.sin(t * 6) * 3,
        f3 = 11 + t * 5;
      return Math.sin(TAU * f1 * p) * 0.7 + Math.sin(TAU * f2 * p) * 0.45 + Math.sin(TAU * f3 * p) * 0.22;
    }, F, S),
  );
  tables.push(makeTable((p) => Math.sin(TAU * p), F, S));
  return tables;
}

function lookupWT(data, frames, size, framePos, phase) {
  const f = clamp(framePos, 0, 1) * (frames - 1);
  const f0 = f | 0;
  const f1 = Math.min(frames - 1, f0 + 1);
  const ft = f - f0;
  let ph = phase - Math.floor(phase);
  if (ph < 0) ph += 1;
  const p = ph * size;
  const i0 = p | 0;
  const i1 = i0 + 1 < size ? i0 + 1 : 0;
  const pt = p - i0;
  const a = data[f0 * size + i0] + (data[f0 * size + i1] - data[f0 * size + i0]) * pt;
  const b = data[f1 * size + i0] + (data[f1 * size + i1] - data[f1 * size + i0]) * pt;
  return a + (b - a) * ft;
}

function warpPhase(ph, type, amt) {
  let t = ph - Math.floor(ph);
  if (t < 0) t += 1;
  const a = clamp(amt, 0, 1);
  switch (type) {
    case 0:
      return t;
    case 1: {
      const k = 1 + a * 4;
      return Math.pow(t, k);
    }
    case 2: {
      const k = 1 + a * 4;
      return 1 - Math.pow(1 - t, k);
    }
    case 3:
      return t < 0.5 ? t * (1 + a) : 1 - (1 - t) * (1 + a);
    case 4:
      return (t * (1 + a * 8)) % 1;
    case 5:
      return (t * (1 + a * 16)) % 1;
    case 6: {
      const r = 1 + a * 8;
      return 1 - ((t * r) % 1);
    }
    case 7: {
      const w = 0.5 + a * 0.45;
      return t < w ? t / w * 0.5 : 0.5 + ((t - w) / (1 - w)) * 0.5;
    }
    case 8:
      return clamp(t + (t - 0.5) * a, 0, 0.9999);
    case 9:
      return t < 0.5 ? Math.pow(t * 2, 1 + a * 3) * 0.5 : 1 - Math.pow((1 - t) * 2, 1 + a * 3) * 0.5;
    case 10:
      return (t * (1 - a * 0.85) + a * 0.075) % 1;
    case 11:
      return 0.5 + (t - 0.5) * (1 - a * 0.9);
    case 15:
      return t + a * 0.35 * sinLut(t * 3);
    case 16:
      return t + a * 0.5 * sinLut(t);
    case 17: {
      const d = 1 + a * 6;
      return (t + a * 0.25 * Math.sin(TAU * t * d)) % 1;
    }
    case 18:
      return Math.pow(t, 1 / (1 + a * 3));
    case 19:
      return Math.pow(t, 1 + a * 4);
    case 20:
      return (t + a * 0.18 * sinLut(t * 5)) % 1;
    case 21:
      return (t + a * 0.12 * sinLut(t * 3) + a * 0.08 * sinLut(t * 7)) % 1;
    default:
      return t;
  }
}

function warpSample(s, type, amt, hold) {
  const a = clamp(amt, 0, 1);
  switch (type) {
    case 12:
      return tanhF(s * (1 + a * 6));
    case 13: {
      const x = Math.abs(s);
      return (x * 2 - 1) * Math.sign(s || 1) * (1 - a) + Math.sin(s * (1 + a * 8)) * a;
    }
    case 14:
      return s < 0 ? s * (1 - a) : s;
    case 22: {
      const bits = 2 + (1 - a) * 10;
      const st = Math.pow(2, bits);
      return Math.round(s * st) / st;
    }
    case 23: {
      const st = 2 + a * 14;
      return Math.round(s * st) / st;
    }
    case 24:
      return hold;
    case 25:
      return Math.abs(s) * (1 + a) - a;
    case 26:
      return tanhF(s * (1 + a * 8));
    case 27:
      return clamp(s * (1 + a * 4), -1, 1);
    case 28: {
      let x = s * (1 + a * 5);
      while (x > 1 || x < -1) x = x > 1 ? 2 - x : -2 - x;
      return x;
    }
    case 29: {
      let x = s;
      for (let i = 0; i < 1 + (a * 4) | 0; i++) x = Math.sin(x * Math.PI * (1 + a));
      return x;
    }
    case 30:
      return sinLut((s * 0.5 + 0.5) * (1 + a * 7));
    case 31: {
      const r = 3.5 + a * 0.49;
      let x = (s * 0.5 + 0.5) * 0.9 + 0.05;
      x = r * x * (1 - x);
      return x * 2 - 1;
    }
    case 32:
      return s * (1 - a) + (Math.random() * 2 - 1) * a;
    default:
      return s;
  }
}

class SVF {
  constructor() {
    this.ic1 = 0;
    this.ic2 = 0;
  }
  reset() {
    this.ic1 = 0;
    this.ic2 = 0;
  }
  tick(x, cutoff, res, sr) {
    const ny = sr * 0.49;
    const f = clamp(cutoff, 8, ny);
    const g = Math.tan((Math.PI * f) / sr);
    const k = 2 - 2 * clamp(res, 0, 0.97);
    const hp = (x - this.ic1 * k - this.ic2) / (1 + g * (g + k));
    const bp = hp * g + this.ic1;
    const lp = bp * g + this.ic2;
    this.ic1 = hp * g + bp;
    this.ic2 = bp * g + lp;
    if (Math.abs(this.ic1) < 1e-20) this.ic1 = 0;
    if (Math.abs(this.ic2) < 1e-20) this.ic2 = 0;
    return { lp, bp, hp, notch: lp + hp };
  }
}

class Ladder {
  constructor() {
    this.z = [0, 0, 0, 0];
  }
  reset() {
    this.z[0] = this.z[1] = this.z[2] = this.z[3] = 0;
  }
  tick(x, cutoff, res, sr) {
    const f = clamp((2 * Math.PI * cutoff) / sr, 0.0001, 1.2);
    const k = clamp(res, 0, 0.98) * 4.2;
    let u = tanhF(x - k * this.z[3]);
    for (let i = 0; i < 4; i++) {
      this.z[i] = this.z[i] + f * (tanhF(u) - tanhF(this.z[i]));
      u = this.z[i];
    }
    return this.z[3];
  }
}

class Comb {
  constructor(sr) {
    this.n = Math.max(32, (sr * 0.05) | 0);
    this.buf = new Float32Array(this.n);
    this.i = 0;
    this.lp = 0;
  }
  reset() {
    this.buf.fill(0);
    this.i = 0;
    this.lp = 0;
  }
  tick(x, freq, fb, sr) {
    const d = clamp(sr / Math.max(40, freq), 2, this.n - 2);
    const d0 = d | 0;
    const frac = d - d0;
    let i1 = this.i - d0;
    if (i1 < 0) i1 += this.n;
    let i2 = i1 - 1;
    if (i2 < 0) i2 += this.n;
    const y = this.buf[i1] * (1 - frac) + this.buf[i2] * frac;
    this.lp = this.lp * 0.65 + y * 0.35;
    const out = x + this.lp * clamp(fb, 0, 0.97);
    this.buf[this.i] = tanhF(out);
    this.i++;
    if (this.i >= this.n) this.i = 0;
    return out;
  }
}

class Env {
  constructor() {
    this.stage = 0;
    this.t = 0;
    this.val = 0;
    this.releaseFrom = 0;
  }
  reset(retrigger) {
    this.stage = 1;
    this.t = 0;
    if (retrigger) this.val = 0;
  }
  release() {
    this.stage = 5;
    this.t = 0;
    this.releaseFrom = this.val;
  }
  process(p, sr) {
    if (this.stage === 0) return 0;
    const A = Math.max(1 / sr, p.attack);
    const H = Math.max(0, p.hold);
    const D = Math.max(1 / sr, p.decay);
    const S = clamp(p.sustain, 0, 1);
    const R = Math.max(1 / sr, p.release);
    if (this.stage === 1) {
      this.t += 1 / sr;
      const u = clamp(this.t / A, 0, 1);
      this.val = curve01(u, p.aCurve);
      if (u >= 1) {
        this.stage = H > 0 ? 2 : 3;
        this.t = 0;
      }
    } else if (this.stage === 2) {
      this.t += 1 / sr;
      this.val = 1;
      if (this.t >= H) {
        this.stage = 3;
        this.t = 0;
      }
    } else if (this.stage === 3) {
      this.t += 1 / sr;
      const u = clamp(this.t / D, 0, 1);
      this.val = 1 - curve01(u, p.dCurve) * (1 - S);
      if (u >= 1) {
        this.stage = 4;
        this.t = 0;
        this.val = S;
      }
    } else if (this.stage === 4) {
      this.val = S;
      if (p.loop && S < 0.99) {
        this.stage = 1;
        this.t = 0;
      }
    } else if (this.stage === 5) {
      this.t += 1 / sr;
      const u = clamp(this.t / R, 0, 1);
      this.val = this.releaseFrom * (1 - curve01(u, p.rCurve));
      if (u >= 1) {
        this.stage = 0;
        this.val = 0;
      }
    }
    return this.val;
  }
}

class DelayLine {
  constructor(max) {
    this.buf = new Float32Array(max);
    this.i = 0;
    this.n = max;
  }
  write(x) {
    this.buf[this.i] = x;
    this.i++;
    if (this.i >= this.n) this.i = 0;
  }
  read(samples) {
    const d = clamp(samples, 1, this.n - 2);
    let i = this.i - d;
    while (i < 0) i += this.n;
    const i0 = i | 0;
    const f = i - i0;
    const i1 = i0 + 1 >= this.n ? 0 : i0 + 1;
    return this.buf[i0] * (1 - f) + this.buf[i1] * f;
  }
}

function lfoShape(shape, ph, custom) {
  const t = ph - Math.floor(ph);
  switch (shape) {
    case 0:
      return sinLut(t);
    case 1:
      return t < 0.5 ? t * 4 - 1 : 3 - 4 * t;
    case 2:
      return 1 - 2 * t;
    case 3:
      return 2 * t - 1;
    case 4:
      return t < 0.5 ? 1 : -1;
    case 5:
      return 0;
    case 6:
      return sinLut(t * 0.5) * 2 - 1;
    case 7: {
      if (!custom || !custom.length) return sinLut(t);
      const n = custom.length;
      const x = t * n;
      const i0 = x | 0;
      const i1 = (i0 + 1) % n;
      return custom[i0] + (custom[i1] - custom[i0]) * (x - i0);
    }
    default:
      return sinLut(t);
  }
}

const SRC_ENV = 1;
const SRC_LFO = 5;
const SRC_MACRO = 13;
const SRC_VEL = 21;
const SRC_NOTE = 22;
const SRC_KEY = 23;
const SRC_AT = 24;
const SRC_WHL = 25;
const SRC_BEND = 26;
const SRC_MPEX = 27;
const SRC_MPEY = 28;
const SRC_MPEP = 29;
const SRC_RAND = 30;
const SRC_SH = 31;
const SRC_PERL = 32;
const SRC_LOR = 33;
const SRC_CHAOS = 34;
const SRC_AENV = 35;
const SRC_SEQ = 36;

class Voice {
  constructor(sr) {
    this.sr = sr;
    this.active = false;
    this.releasing = false;
    this.note = 60;
    this.glide = 60;
    this.vel = 1;
    this.age = 0;
    this.ch = 0;
    this.amp = 0;
    this.phases = new Float32Array(3 * UNI);
    this.fb = new Float32Array(3);
    this.subPh = 0;
    this.modPh = 0;
    this.noise = 1234567;
    this.pink = [0, 0, 0, 0, 0, 0, 0];
    this.brown = 0;
    this.env = [new Env(), new Env(), new Env(), new Env()];
    this.svf = [new SVF(), new SVF(), new SVF(), new SVF(), new SVF(), new SVF()];
    this.ladder = [new Ladder(), new Ladder()];
    this.comb = [new Comb(sr), new Comb(sr)];
    this.formant = [new SVF(), new SVF(), new SVF()];
    this.grainPh = new Float32Array(4);
    this.grainOff = new Float32Array(4);
    this.dsHold = [0, 0, 0];
    this.dsCnt = [0, 0, 0];
    this.lfoPh = new Float32Array(NUM_LFO);
    this.lfoFade = new Float32Array(NUM_LFO);
    this.sh = 0;
    this.rand = 0;
    this.mpeX = 0;
    this.mpeY = 0;
    this.mpeP = 0;
  }
  steal() {
    this.active = false;
    this.releasing = false;
    this.amp = 0;
    for (const e of this.env) {
      e.stage = 0;
      e.val = 0;
    }
  }
  start(note, vel, ch, patch, steal) {
    this.active = true;
    this.releasing = false;
    this.note = note;
    if (!steal || patch.voice.mode === 0 || patch.voice.glide < 0.001) this.glide = note;
    this.vel = vel;
    this.ch = ch || 0;
    this.age = 0;
    this.rand = Math.random() * 2 - 1;
    const retrig = patch.voice.retrigger || patch.voice.mode === 0;
    for (let e = 0; e < 4; e++) this.env[e].reset(patch.env[e].retrigger && retrig);
    for (let o = 0; o < 3; o++) {
      const osc = patch.osc[o];
      for (let u = 0; u < UNI; u++) {
        const pr = osc.phaseRand > 0.001 ? Math.random() * osc.phaseRand : 0;
        this.phases[o * UNI + u] = osc.retrigger ? osc.phase + pr : this.phases[o * UNI + u];
      }
      this.fb[o] = 0;
    }
    this.subPh = 0;
    this.modPh = 0;
    if (retrig) {
      for (let i = 0; i < NUM_LFO; i++) {
        if (patch.lfo[i].retrigger || patch.lfo[i].oneshot) {
          this.lfoPh[i] = patch.lfo[i].phase;
          this.lfoFade[i] = 0;
        }
      }
    }
  }
  release() {
    this.releasing = true;
    for (const e of this.env) e.release();
  }
}

class HypercoreProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.sr = sampleRate;
    this.tables = factoryTables();
    this.userTable = this.tables[15];
    this.voices = Array.from({ length: MAX_VOICES }, () => new Voice(this.sr));
    this.patch = null;
    this.bpm = 174;
    this.wheel = 0;
    this.bend = 0;
    this.at = 0;
    this.macro = new Float32Array(8);
    this.lfoPhG = new Float32Array(NUM_LFO);
    this.lfoVal = new Float32Array(NUM_LFO);
    this.held = [];
    this.seqPos = 0;
    this.seqTimer = 0;
    this.seqMod = 0;
    this.arpIdx = 0;
    this.arpTimer = 0;
    this.arpNote = -1;
    this.audioEnv = 0;
    this.shHold = 0;
    this.shPh = 0;
    this.lor = { x: 0.1, y: 0, z: 0 };
    this.perl = 0;
    this.perlT = 0;
    this.logi = 0.31;
    this.chaosS = 0;
    this.mixL = 0;
    this.mixR = 0;
    this.dcL = 0;
    this.dcR = 0;
    this.peak = 0;
    this.rmsAcc = 0;
    this.vizWave = new Float32Array(512);
    this.vizW = 0;
    this.vizClock = 0;
    this.scope = new Float32Array(1024);
    this.scopeI = 0;
    this.dlyL = new DelayLine((this.sr * 2) | 0);
    this.dlyR = new DelayLine((this.sr * 2) | 0);
    this.apL = [0, 0, 0, 0];
    this.apR = [0, 0, 0, 0];
    this.combL = [0, 0, 0, 0];
    this.combR = [0, 0, 0, 0];
    this.combPos = [0, 0, 0, 0, 0, 0, 0, 0];
    this.revBufL = [
      new Float32Array(1557),
      new Float32Array(1617),
      new Float32Array(1491),
      new Float32Array(1422),
    ];
    this.revBufR = [
      new Float32Array(1553),
      new Float32Array(1591),
      new Float32Array(1481),
      new Float32Array(1453),
    ];
    this.phaser = [0, 0, 0, 0, 0, 0];
    this.chorus = new DelayLine((this.sr * 0.05) | 0);
    this.chorusR = new DelayLine((this.sr * 0.05) | 0);
    this.chorusPh = 0;
    this.shiftPh = 0;
    this.ringPh = 0;
    this.psychPh = 0;
    this.freeze = new Float32Array(2048);
    this.freezeI = 0;
    this.freezeOn = false;
    this.smear = new DelayLine(4096);
    this.eqLp = new SVF();
    this.eqHp = new SVF();
    this.compEnv = 0;
    this.preL = 0;
    this.preR = 0;
    this.modScratch = new Float32Array(8);
    this.blockN = 0;
    this.port.onmessage = (e) => this.handle(e.data);
    this.ready = false;
  }

  handle(m) {
    if (!m || !m.type) return;
    switch (m.type) {
      case "patch":
        this.patch = m.patch;
        this.bpm = m.patch.bpm || this.bpm;
        if (m.patch.macros) {
          for (let i = 0; i < 8; i++) this.macro[i] = m.patch.macros[i] ? m.patch.macros[i].value : 0;
        }
        this.ready = true;
        break;
      case "set":
        this.setPath(m.path, m.value);
        break;
      case "noteOn":
        this.noteOn(m.note, m.velocity, m.channel || 0);
        break;
      case "noteOff":
        this.noteOff(m.note);
        break;
      case "cc":
        if (m.cc === 1) this.wheel = m.value;
        if (m.cc === 74) {
          if (this.patch) this.patch.filt[0].cutoff = m.value;
        }
        break;
      case "bend":
        this.bend = m.value;
        break;
      case "at":
        this.at = m.value;
        break;
      case "panic":
        this.panic();
        break;
      case "tables":
        if (m.tables && m.tables.length) {
          this.tables = m.tables.map((b) => new Float32Array(b));
        }
        break;
      case "userTable":
        this.userTable = new Float32Array(m.data);
        this.tables[15] = this.userTable;
        break;
      case "lfoShape":
        if (this.patch && this.patch.lfo[m.index]) this.patch.lfo[m.index].custom = m.points;
        break;
      case "bpm":
        this.bpm = m.value;
        if (this.patch) this.patch.bpm = m.value;
        break;
      default:
        break;
    }
  }

  setPath(path, value) {
    if (!this.patch) return;
    const parts = path.split(".");
    let cur = this.patch;
    for (let i = 0; i < parts.length - 1; i++) {
      const k = Number.isInteger(+parts[i]) ? +parts[i] : parts[i];
      cur = cur[k];
      if (cur == null) return;
    }
    const last = parts[parts.length - 1];
    const lk = Number.isInteger(+last) ? +last : last;
    cur[lk] = value;
    if (path.startsWith("macros.") && path.endsWith(".value")) {
      const i = +parts[1];
      if (i >= 0 && i < 8) this.macro[i] = value;
    }
    if (path === "bpm") this.bpm = value;
  }

  panic() {
    for (const v of this.voices) v.steal();
    this.held.length = 0;
    this.arpNote = -1;
  }

  noteOn(note, vel, ch) {
    if (!this.patch) return;
    const vels = clamp(vel, 0, 1);
    if (!this.held.includes(note)) this.held.push(note);
    if (this.patch.arp.on) return;
    const mode = this.patch.voice.mode;
    if (mode === 1 || mode === 2) {
      let v = this.voices[0];
      for (const cand of this.voices) {
        if (cand.active) {
          v = cand;
          break;
        }
      }
      if (mode === 2 && v.active && !v.releasing) {
        v.note = note;
        v.vel = vels;
        return;
      }
      v.start(note, vels, ch, this.patch, true);
      return;
    }
    let slot = null;
    let oldest = this.voices[0];
    for (const v of this.voices) {
      if (!v.active) {
        slot = v;
        break;
      }
      if (v.age > oldest.age) oldest = v;
    }
    (slot || oldest).start(note, vels, ch, this.patch, !slot);
  }

  noteOff(note) {
    const ix = this.held.indexOf(note);
    if (ix >= 0) this.held.splice(ix, 1);
    if (!this.patch) return;
    if (this.patch.arp.on) {
      if (!this.held.length && this.arpNote >= 0) {
        for (const v of this.voices) if (v.note === this.arpNote) v.release();
        this.arpNote = -1;
      }
      return;
    }
    const mode = this.patch.voice.mode;
    if ((mode === 1 || mode === 2) && this.held.length) {
      const next = this.held[this.held.length - 1];
      const v = this.voices.find((x) => x.active) || this.voices[0];
      v.note = next;
      if (mode === 1) v.start(next, v.vel, v.ch, this.patch, true);
      return;
    }
    for (const v of this.voices) {
      if (v.active && v.note === note) v.release();
    }
  }

  beats(div) {
    const map = [4, 2, 1, 0.5, 0.25, 0.125, 0.0625, 2 / 3, 1 / 3, 1 / 6, 1.5, 0.75, 0.375];
    return map[div | 0] || 0.25;
  }

  lfoHz(p) {
    if (p.sync) {
      const b = this.beats(p.syncDiv);
      return this.bpm / 60 / b;
    }
    return expMap(p.rate, 0.02, 40);
  }

  sourceVal(id, voice) {
    if (id <= 0) return 0;
    if (id >= SRC_ENV && id <= 4) return voice ? voice.env[id - 1].val : 0;
    if (id >= SRC_LFO && id <= 12) return this.lfoVal[id - SRC_LFO] || 0;
    if (id >= SRC_MACRO && id <= 20) return this.macro[id - SRC_MACRO] || 0;
    if (id === SRC_VEL) return voice ? voice.vel : 0;
    if (id === SRC_NOTE || id === SRC_KEY) return voice ? (voice.note - 60) / 24 : 0;
    if (id === SRC_AT) return this.at;
    if (id === SRC_WHL) return this.wheel;
    if (id === SRC_BEND) return this.bend;
    if (id === SRC_MPEX) return voice ? voice.mpeX : 0;
    if (id === SRC_MPEY) return voice ? voice.mpeY : 0;
    if (id === SRC_MPEP) return voice ? voice.mpeP : this.at;
    if (id === SRC_RAND) return voice ? voice.rand : this.chaosS;
    if (id === SRC_SH) return this.shHold;
    if (id === SRC_PERL) return this.perl;
    if (id === SRC_LOR) return clamp(this.lor.x * 0.12, -1, 1);
    if (id === SRC_CHAOS) return this.chaosS;
    if (id === SRC_AENV) return this.audioEnv;
    if (id === SRC_SEQ) return this.seqMod;
    return 0;
  }

  applyCurve(x, c) {
    const s = x < 0 ? -1 : 1;
    const a = Math.abs(x);
    if (c <= -0.01) return s * (1 - Math.pow(1 - a, 1 - c * 2));
    if (c >= 0.01) return s * Math.pow(a, 1 + c * 2);
    return x;
  }

  modDest(dest, voice) {
    let add = 0;
    const p = this.patch;
    if (!p) return 0;
    const mat = p.matrix;
    for (let i = 0; i < NUM_MAT; i++) {
      const s = mat[i];
      if (!s || !s.on || s.dest !== dest) continue;
      let src = this.sourceVal(s.source, voice);
      src = this.applyCurve(src, s.curve || 0);
      if (s.invert) src = -src;
      if (!s.bipolar) src = src * 0.5 + 0.5;
      if (s.aux > 0) src *= 1 - s.auxAmt + this.sourceVal(s.aux, voice) * s.auxAmt;
      add += src * s.amount;
    }
    const macros = p.macros;
    for (let i = 0; i < 8; i++) {
      const m = macros[i];
      if (!m || !m.routes) continue;
      const mv = this.macro[i];
      for (let r = 0; r < m.routes.length; r++) {
        if (m.routes[r].dest === dest) add += mv * m.routes[r].amount;
      }
    }
    return add;
  }

  tableFor(osc) {
    const i = osc.table | 0;
    if (i < 0 || i >= this.tables.length) return this.tables[0];
    return this.tables[i];
  }

  renderOsc(voice, oi, osc, freq, fm, table, sr) {
    if (!osc.on) return 0;
    const uni = clamp(osc.unison | 0, 1, UNI);
    const det = osc.detune;
    const spread = osc.spread;
    const wt = clamp(osc.wtPos + this.modDest("osc." + oi + ".wtPos", voice), 0, 1);
    const pwm = clamp(osc.pwm + this.modDest("osc." + oi + ".pwm", voice), 0.03, 0.97);
    const mode = osc.mode | 0;
    let sum = 0;
    const w0 = osc.warp[0],
      w1 = osc.warp[1],
      w2 = osc.warp[2];
    const w0a = clamp(w0.amount + this.modDest("osc." + oi + ".warp.0.amount", voice), 0, 1);
    const w1a = clamp(w1.amount + this.modDest("osc." + oi + ".warp.1.amount", voice), 0, 1);
    const w2a = clamp(w2.amount + this.modDest("osc." + oi + ".warp.2.amount", voice), 0, 1);
    const pm = fm + (osc.pmAmt || 0) * fm;
    for (let u = 0; u < uni; u++) {
      const idx = oi * UNI + u;
      const panOff = uni === 1 ? 0 : (u / (uni - 1) - 0.5) * 2 * spread;
      const cents = uni === 1 ? 0 : (u / (uni - 1) - 0.5) * 2 * det * 50;
      const f = freq * Math.pow(2, cents / 1200);
      const dt = f / sr;
      voice.phases[idx] += dt;
      if (voice.phases[idx] >= 1024) voice.phases[idx] -= 1024;
      let ph = voice.phases[idx] + pm + osc.fmFeedback * voice.fb[oi] * 0.15;
      ph = warpPhase(ph, w0.type, w0a);
      ph = warpPhase(ph, w1.type, w1a);
      let s = 0;
      if (mode === 0 || mode === 3) {
        s = lookupWT(table, WT_FRAMES, WT_SIZE, wt, ph);
      } else if (mode === 1) {
        s = analogWave(ph, dt, osc.analogWave | 0, pwm);
      } else if (mode === 2) {
        const t = ph - Math.floor(ph);
        const aw = osc.analogWave | 0;
        s = aw === 0 ? sinLut(t) : aw === 1 ? (t < 0.5 ? t * 4 - 1 : 3 - 4 * t) : aw === 2 ? 2 * t - 1 : t < pwm ? 1 : -1;
      } else if (mode === 4) {
        const gsz = 0.02 + osc.grainSize * 0.15;
        const dens = 1 + osc.grainDensity * 6;
        s = 0;
        for (let g = 0; g < 4; g++) {
          voice.grainPh[g] += dt * (0.85 + g * 0.07);
          const gp = voice.grainPh[g];
          const local = gp - Math.floor(gp / dens) * dens;
          const win = Math.sin((local / dens) * Math.PI);
          const pos = (wt + osc.grainSpray * (g * 0.17) + local * gsz) % 1;
          s += lookupWT(table, WT_FRAMES, WT_SIZE, pos, ph + g * 0.03) * win;
        }
        s *= 0.45;
      } else if (mode === 5 || mode === 7) {
        const parts = 4 + ((osc.additivePartials || 0.5) * 12) | 0;
        const bright = osc.spectralBright || 0.5;
        const t = ph - Math.floor(ph);
        s = 0;
        for (let n = 1; n <= parts; n++) {
          const amp = Math.pow(n, -0.4 - (1 - bright) * 1.4) * (n === 1 ? 1 : 0.8);
          s += sinLut(t * n) * amp;
        }
        s *= 0.35 + bright * 0.3;
      } else if (mode === 6) {
        voice.noise = (voice.noise * 1664525 + 1013904223) | 0;
        const white = (voice.noise >>> 0) / 4294967295 * 2 - 1;
        const nt = osc.analogWave | 0;
        if (nt <= 0) s = white;
        else if (nt === 1) {
          const p = voice.pink;
          p[0] = 0.99886 * p[0] + white * 0.0555179;
          p[1] = 0.99332 * p[1] + white * 0.0750759;
          p[2] = 0.969 * p[2] + white * 0.153852;
          p[3] = 0.8665 * p[3] + white * 0.3104856;
          p[4] = 0.55 * p[4] + white * 0.5329522;
          p[5] = -0.7616 * p[5] - white * 0.016898;
          s = p[0] + p[1] + p[2] + p[3] + p[4] + p[5] + p[6] + white * 0.5362;
          p[6] = white * 0.115926;
          s *= 0.11;
        } else {
          voice.brown = clamp(voice.brown + white * 0.02, -1, 1);
          s = voice.brown;
        }
      }
      s = warpSample(s, w0.type, w0a, voice.dsHold[oi]);
      s = warpSample(s, w1.type, w1a, voice.dsHold[oi]);
      s = warpSample(s, w2.type, w2a, voice.dsHold[oi]);
      if (w2.type === 24 || w1.type === 24 || w0.type === 24) {
        const rate = 1 + (1 - (w2.type === 24 ? w2a : w1.type === 24 ? w1a : w0a)) * 48;
        voice.dsCnt[oi]++;
        if (voice.dsCnt[oi] >= rate) {
          voice.dsCnt[oi] = 0;
          voice.dsHold[oi] = s;
        }
        s = voice.dsHold[oi];
      }
      voice.fb[oi] = s;
      const gUni = 1 / Math.sqrt(uni);
      const pan = clamp(osc.pan + panOff + this.modDest("osc." + oi + ".pan", voice), -1, 1);
      this.modScratch[0] += s * gUni * (0.707 * (1 - pan));
      this.modScratch[1] += s * gUni * (0.707 * (1 + pan));
      sum += s * gUni;
    }
    return sum;
  }

  filterSample(voice, fi, x, cutoff, res, type, sr) {
    const sv = voice.svf[fi * 3];
    const sv2 = voice.svf[fi * 3 + 1];
    const sv3 = voice.svf[fi * 3 + 2];
    if (type === 12 || type === 14) {
      return voice.ladder[fi].tick(x, cutoff, res, sr);
    }
    if (type === 7 || type === 11) {
      return voice.comb[fi].tick(x, cutoff, res, sr);
    }
    if (type === 8 || type === 9) {
      const y1 = voice.formant[0].tick(x, cutoff * 0.7, 0.7, sr).bp;
      const y2 = voice.formant[1].tick(x, cutoff * 1.6, 0.65, sr).bp;
      const y3 = voice.formant[2].tick(x, cutoff * 2.8, 0.5, sr).bp;
      return y1 * 0.5 + y2 * 0.35 + y3 * 0.25;
    }
    if (type === 15) {
      const a = sv.tick(x, cutoff, Math.min(0.96, res + 0.15), sr);
      const b = sv2.tick(a.lp, cutoff * 1.015, res, sr);
      return tanhF(b.lp * (1.2 + res));
    }
    const a = sv.tick(x, cutoff, res, sr);
    let y = a.lp;
    if (type === 0) y = a.lp;
    else if (type === 1) y = sv2.tick(a.lp, cutoff, res * 0.85, sr).lp;
    else if (type === 2) y = sv3.tick(sv2.tick(a.lp, cutoff, res * 0.8, sr).lp, cutoff, res * 0.75, sr).lp;
    else if (type === 3) y = a.hp;
    else if (type === 4) y = sv2.tick(a.hp, cutoff, res * 0.85, sr).hp;
    else if (type === 5) y = a.bp;
    else if (type === 6) y = a.notch;
    else if (type === 13) y = a.lp;
    else if (type === 10) y = voice.comb[fi].tick(x, cutoff * 0.5, 0.4 + res * 0.5, sr);
    return y;
  }

  tickChaos() {
    const p = this.patch.chaos;
    const rate = expMap(p.rate, 0.1, 30);
    const dt = rate / this.sr;
    this.lor.x += 10 * (this.lor.y - this.lor.x) * dt * 8;
    this.lor.y += (this.lor.x * (28 - this.lor.z) - this.lor.y) * dt * 8;
    this.lor.z += (this.lor.x * this.lor.y - 2.66 * this.lor.z) * dt * 8;
    this.logi = (3.7 + p.amount * 0.29) * this.logi * (1 - this.logi);
    this.perlT += dt;
    this.perl = Math.sin(this.perlT * 1.7) * 0.6 + Math.sin(this.perlT * 4.3 + 1.2) * 0.4;
    this.shPh += rate / this.sr;
    if (this.shPh >= 1) {
      this.shPh -= 1;
      this.shHold = Math.random() * 2 - 1;
    }
    const raw =
      p.type === 0
        ? this.shHold
        : p.type === 1
          ? this.perl
          : p.type === 2
            ? clamp(this.lor.x * 0.12, -1, 1)
            : this.logi * 2 - 1;
    const sm = 0.001 + p.smooth * 0.04;
    this.chaosS += (raw - this.chaosS) * sm;
  }

  processSeq(n) {
    const s = this.patch.seq;
    if (!s.on) return;
    const beats = this.beats(s.division);
    const stepSec = (60 / this.bpm) * beats;
    this.seqTimer += n / this.sr;
    while (this.seqTimer >= stepSec) {
      this.seqTimer -= stepSec;
      const i = this.seqPos % Math.max(1, s.steps | 0);
      this.seqMod = s.mods[i] || 0;
      if ((s.probs[i] ?? 1) > Math.random()) {
        const note = (s.root || 36) + (s.notes[i] || 0) + (s.octs[i] || 0) * 12;
        const vel = s.vels[i] ?? 1;
        if (s.gates[i] > 0.02) {
          this.noteOn(note, vel, 0);
          const gate = (s.gates[i] || 0.5) * stepSec;
          const captured = note;
          const offAt = currentTime + gate;
          this._gateOffs = this._gateOffs || [];
          this._gateOffs.push({ note: captured, t: offAt });
        }
      }
      this.seqPos = (this.seqPos + 1) % Math.max(1, s.steps | 0);
    }
    if (this._gateOffs) {
      const keep = [];
      for (const g of this._gateOffs) {
        if (currentTime >= g.t) this.noteOff(g.note);
        else keep.push(g);
      }
      this._gateOffs = keep;
    }
  }

  processArp(n) {
    const a = this.patch.arp;
    if (!a.on || !this.held.length) return;
    const beats = a.sync ? this.beats(a.syncDiv) : expMap(1 - a.rate, 0.05, 2);
    const stepSec = a.sync ? (60 / this.bpm) * beats : beats;
    this.arpTimer += n / this.sr;
    if (this.arpTimer < stepSec) return;
    this.arpTimer -= stepSec;
    const notes = this.held.slice().sort((x, y) => x - y);
    const oct = clamp(a.octaves | 0, 1, 4);
    const pool = [];
    for (let o = 0; o < oct; o++) for (const nt of notes) pool.push(nt + o * 12);
    const mode = a.mode | 0;
    let idx = this.arpIdx;
    if (mode === 0) idx = (idx + 1) % pool.length;
    else if (mode === 1) idx = (idx - 1 + pool.length) % pool.length;
    else if (mode === 2) {
      this._arpDir = this._arpDir || 1;
      idx += this._arpDir;
      if (idx >= pool.length - 1 || idx <= 0) this._arpDir *= -1;
      idx = clamp(idx, 0, pool.length - 1);
    } else if (mode === 3 || mode === 9) idx = (Math.random() * pool.length) | 0;
    else idx = (idx + 1) % pool.length;
    this.arpIdx = idx;
    if (a.prob < 1 && Math.random() > a.prob) return;
    if (this.arpNote >= 0) this.noteOff(this.arpNote);
    const nt = pool[idx];
    this.arpNote = nt;
    this.noteOn(nt, 0.85, 0);
  }

  fxProcess(L, R, i, sr) {
    const p = this.patch;
    let l = L,
      r = R;
    const chain = p.fx;
    for (let f = 0; f < chain.length; f++) {
      const sl = chain[f];
      if (!sl || !sl.on || sl.type === 0) continue;
      const mix = sl.mix;
      const a = sl.p1,
        b = sl.p2,
        c = sl.p3;
      let yl = l,
        yr = r;
      const t = sl.type | 0;
      if (t === 1) {
        yl = tanhF(l * (1 + a * 12));
        yr = tanhF(r * (1 + a * 12));
      } else if (t === 2) {
        const fold = (x) => {
          let y = x * (1 + a * 6);
          while (y > 1 || y < -1) y = y > 1 ? 2 - y : -2 - y;
          return y;
        };
        yl = fold(l);
        yr = fold(r);
      } else if (t === 3) {
        const st = Math.pow(2, 2 + (1 - a) * 12);
        yl = Math.round(l * st) / st;
        yr = Math.round(r * st) / st;
      } else if (t === 4) {
        const rate = 1 + (1 - a) * 64;
        this._dsC = (this._dsC || 0) + 1;
        if (this._dsC >= rate) {
          this._dsC = 0;
          this._dsL = l;
          this._dsR = r;
        }
        yl = this._dsL || 0;
        yr = this._dsR || 0;
      } else if (t === 5) {
        const cut = expMap(a, 80, 12000);
        yl = this.eqLp.tick(l, cut, b, sr).lp;
        yr = this.eqHp.tick(r, cut, b, sr).lp;
      } else if (t === 6) {
        const lo = this.eqLp.tick(l, 180, 0.2, sr).lp;
        const hi = l - lo;
        yl = lo * (0.5 + a) + hi * (0.5 + b);
        yr = yl;
      } else if (t === 7) {
        const e = Math.abs(l) + Math.abs(r);
        this.compEnv = this.compEnv * 0.995 + e * 0.005;
        const thr = 0.2 + (1 - a) * 0.5;
        const gr = this.compEnv > thr ? thr / (this.compEnv + 1e-6) : 1;
        const g = Math.pow(gr, 0.3 + b);
        yl = l * g;
        yr = r * g;
      } else if (t === 8 || t === 9) {
        const beats = this.beats((c * 12) | 0);
        const samp = (60 / this.bpm) * beats * sr * (0.25 + a * 1.5);
        this.dlyL.write(l + (this._fbL || 0) * b);
        this.dlyR.write(r + (this._fbR || 0) * b);
        const dl = this.dlyL.read(samp);
        const dr = this.dlyR.read(t === 9 ? samp * 1.5 : samp * 1.01);
        this._fbL = t === 9 ? dr : dl;
        this._fbR = t === 9 ? dl : dr;
        yl = dl;
        yr = dr;
      } else if (t === 10) {
        const fb = 0.55 + b * 0.35;
        let sl = l,
          sr_ = r;
        for (let k = 0; k < 4; k++) {
          const bufL = this.revBufL[k],
            bufR = this.revBufR[k];
          const nL = bufL.length,
            nR = bufR.length;
          const pL = this.combPos[k] | 0;
          const pR = this.combPos[k + 4] | 0;
          const yL = bufL[pL];
          const yR = bufR[pR];
          bufL[pL] = sl + yL * fb;
          bufR[pR] = sr_ + yR * fb;
          this.combPos[k] = (pL + 1) % nL;
          this.combPos[k + 4] = (pR + 1) % nR;
          sl = yL;
          sr_ = yR;
        }
        yl = sl;
        yr = sr_;
      } else if (t === 11) {
        const rate = expMap(a, 0.05, 8);
        this.chorusPh += rate / sr;
        const mod = sinLut(this.chorusPh) * (0.4 + b);
        let x = l;
        for (let s = 0; s < 4; s++) {
          const g = 0.3 + s * 0.12 + mod * 0.2;
          const y = this.phaser[s];
          const ap = -g * x + y;
          this.phaser[s] = x + g * ap;
          x = ap;
        }
        yl = x;
        yr = x;
      } else if (t === 12 || t === 13) {
        this.chorusPh += expMap(a, 0.05, 6) / sr;
        const d = (0.004 + b * 0.012) * sr * (1 + 0.4 * sinLut(this.chorusPh));
        this.chorus.write(l);
        this.chorusR.write(r);
        yl = this.chorus.read(d);
        yr = this.chorusR.read(d * 1.07);
      } else if (t === 14) {
        this.shiftPh += expMap(a, 0.5, 800) / sr;
        const q = sinLut(this.shiftPh);
        const qq = sinLut(this.shiftPh + 0.25);
        yl = l * q - r * qq * 0.3;
        yr = r * q + l * qq * 0.3;
      } else if (t === 15) {
        this.ringPh += expMap(a, 20, 800) / sr;
        const m = sinLut(this.ringPh);
        yl = l * m;
        yr = r * m;
      } else if (t === 16) {
        const m = a * 0.7;
        yl = l * (1 - m) + (l - r) * m;
        yr = r * (1 - m) + (r - l) * m;
      } else if (t === 17) {
        const e = Math.abs(l) + Math.abs(r);
        const att = e > this.preL ? a : b;
        this.preL = this.preL * (1 - att * 0.2) + e * att * 0.2;
        yl = l * (0.4 + this.preL);
        yr = r * (0.4 + this.preL);
      }
      l = l + (yl - l) * mix;
      r = r + (yr - r) * mix;
    }
    return [l, r];
  }

  psychProcess(l, r) {
    const p = this.patch.psych;
    this.psychPh += 0.37 / this.sr;
    if (p.fold > 0.001) {
      const a = p.fold * 5;
      l = tanhF(Math.sin(l * a * Math.PI) * (1 + p.fold));
      r = tanhF(Math.sin(r * a * Math.PI) * (1 + p.fold));
    }
    if (p.fm > 0.001) {
      const m = sinLut(this.psychPh * 7 + l * 0.3);
      l = Math.sin(l * Math.PI + m * p.fm * 2);
      r = Math.sin(r * Math.PI + m * p.fm * 2);
    }
    if (p.rm > 0.001) {
      const m = sinLut(this.psychPh * 11);
      l = l * (1 - p.rm) + l * m * p.rm;
      r = r * (1 - p.rm) + r * m * p.rm;
    }
    if (p.phase > 0.001) {
      const g = 0.4 + p.phase * 0.5;
      let x = l;
      for (let s = 0; s < 4; s++) {
        const y = this.phaser[s];
        const ap = -g * x + y;
        this.phaser[s] = x + g * ap;
        x = ap;
      }
      l = lerp(l, x, p.phase);
      r = lerp(r, x, p.phase);
    }
    if (p.resonator > 0.001) {
      const f = expMap(0.4 + p.formant * 0.4, 80, 1400);
      const y = this.eqLp.tick(l, f, 0.8, this.sr).bp;
      l = lerp(l, y, p.resonator);
      r = lerp(r, y, p.resonator);
    }
    if (p.formant > 0.001) {
      const y =
        this.eqHp.tick(l, 700 + p.formant * 900, 0.6, this.sr).bp * 0.6 +
        this.eqLp.tick(r, 1200 + p.formant * 800, 0.5, this.sr).bp * 0.4;
      l = lerp(l, y, p.formant);
      r = lerp(r, y, p.formant);
    }
    if (p.smear > 0.001) {
      this.smear.write(l);
      const d = 80 + p.smear * 1200;
      const y = this.smear.read(d);
      l = lerp(l, y, p.smear * 0.7);
      r = lerp(r, this.smear.read(d * 1.17), p.smear * 0.7);
    }
    if (p.space > 0.001) {
      const fb = 0.72;
      const buf = this.revBufL[0];
      const pi = this.combPos[0];
      const y = buf[pi];
      buf[pi] = (l + r) * 0.5 + y * fb;
      this.combPos[0] = (pi + 1) % buf.length;
      l = lerp(l, y, p.space);
      r = lerp(r, y, p.space);
    }
    if (p.chaos > 0.001) {
      l += this.chaosS * p.chaos * 0.25;
      r += this.chaosS * p.chaos * (0.25 * (1 - this.patch.chaos.stereo) + this.perl * this.patch.chaos.stereo * 0.25);
    }
    if (p.freeze > 0.5) {
      this.freeze[this.freezeI] = (l + r) * 0.5;
      this.freezeI = (this.freezeI + 1) & 2047;
      this.freezeOn = true;
    }
    if (this.freezeOn && p.freeze > 0.05) {
      const y = this.freeze[this.freezeI];
      l = lerp(l, y, p.freeze);
      r = lerp(r, this.freeze[(this.freezeI + 40) & 2047], p.freeze);
    }
    return [l, r];
  }

  process(_inputs, outputs) {
    const out = outputs[0];
    const L = out[0];
    const R = out[1] || out[0];
    const n = L.length;
    const sr = this.sr;
    if (!this.patch || !this.ready) {
      L.fill(0);
      if (R !== L) R.fill(0);
      return true;
    }
    const p = this.patch;
    this.processSeq(n);
    this.processArp(n);

    for (let i = 0; i < NUM_LFO; i++) {
      const lf = p.lfo[i];
      const hz = this.lfoHz(lf);
      this.lfoPhG[i] += (hz * n) / sr;
      let sh = lf.shape | 0;
      if (sh === 5) {
        if ((this.lfoPhG[i] | 0) !== ((this.lfoPhG[i] - (hz * n) / sr) | 0)) this.lfoVal[i] = Math.random() * 2 - 1;
      } else {
        this.lfoVal[i] = lfoShape(sh, this.lfoPhG[i] + lf.phase, lf.custom);
      }
      if (!lf.bipolar) this.lfoVal[i] = this.lfoVal[i] * 0.5 + 0.5;
      if (lf.oneshot && this.lfoPhG[i] > 1) this.lfoVal[i] = lf.bipolar ? -1 : 0;
    }

    for (let s = 0; s < n; s++) {
      if ((s & (CR - 1)) === 0) this.tickChaos();

      let mixL = 0,
        mixR = 0;
      let voices = 0;

      for (let vi = 0; vi < MAX_VOICES; vi++) {
        const v = this.voices[vi];
        if (!v.active) continue;
        v.age++;
        const e0 = v.env[0].process(p.env[0], sr);
        const e1 = v.env[1].process(p.env[1], sr);
        const e2 = v.env[2].process(p.env[2], sr);
        v.env[3].process(p.env[3], sr);
        if (v.releasing && e0 <= 0.0001 && v.env[0].stage === 0) {
          v.active = false;
          continue;
        }
        voices++;
        const glideT = p.voice.glide > 0.001 ? Math.exp(-1 / (p.voice.glide * sr * 0.35 + 1)) : 0;
        v.glide = v.glide * glideT + v.note * (1 - glideT);
        const bend = this.bend * (p.voice.bend || 2);
        const key = v.glide + bend + this.modDest("osc.0.semi", v) * 0.12;

        this.modScratch[0] = 0;
        this.modScratch[1] = 0;

        v.modPh += (midiHz(key) * (p.modOsc.ratio || 1)) / sr;
        const modS = p.modOsc.on
          ? analogWave(v.modPh, midiHz(key) / sr, p.modOsc.wave | 0, 0.5) * (p.modOsc.level || 0.4)
          : 0;
        v.noise = (v.noise * 1664525 + 1013904223) | 0;
        const nz = ((v.noise >>> 0) / 4294967295) * 2 - 1;

        const oscOut = [0, 0, 0];
        const oscLR = [
          [0, 0],
          [0, 0],
          [0, 0],
        ];

        for (let order = 2; order >= 0; order--) {
          const osc = p.osc[order];
          if (!osc.on) continue;
          const pitch =
            key +
            osc.octave * 12 +
            osc.semi +
            osc.fine / 100 +
            this.modDest("osc." + order + ".fine", v) * 0.25;
          let fm = 0;
          const src = osc.fmSrc | 0;
          const fmAmt = clamp(osc.fmAmt + this.modDest("osc." + order + ".fmAmt", v), 0, 2);
          if (fmAmt > 0.0001) {
            if (src === 0) fm = oscOut[0];
            else if (src === 1) fm = oscOut[1];
            else if (src === 2) fm = oscOut[2];
            else if (src === 3) fm = modS;
            else if (src === 4) fm = nz;
            else if (order === 0) fm = oscOut[1] + oscOut[2] * 0.5 + modS;
            else if (order === 1) fm = oscOut[2] + modS;
            else fm = modS;
            fm *= fmAmt * (osc.fmRatio || 1);
          }
          this.modScratch[0] = 0;
          this.modScratch[1] = 0;
          const table = this.tableFor(osc);
          oscOut[order] = this.renderOsc(v, order, osc, midiHz(pitch), fm, table, sr);
          oscLR[order][0] = this.modScratch[0];
          oscLR[order][1] = this.modScratch[1];
        }

        let vL = 0,
          vR = 0;
        for (let o = 0; o < 3; o++) {
          const osc = p.osc[o];
          if (!osc.on) continue;
          let sl = oscLR[o][0],
            sr_ = oscLR[o][1];
          if (osc.amAmt > 0.0001) {
            const as =
              osc.amSrc === 0
                ? oscOut[0]
                : osc.amSrc === 1
                  ? oscOut[1]
                  : osc.amSrc === 2
                    ? oscOut[2]
                    : osc.amSrc === 3
                      ? modS
                      : nz;
            const am = 1 + as * osc.amAmt;
            sl *= am;
            sr_ *= am;
          }
          if (osc.rmAmt > 0.0001) {
            const rs =
              osc.rmSrc === 0
                ? oscOut[0]
                : osc.rmSrc === 1
                  ? oscOut[1]
                  : osc.rmSrc === 2
                    ? oscOut[2]
                    : osc.rmSrc === 3
                      ? modS
                      : nz;
            sl *= rs * osc.rmAmt + (1 - osc.rmAmt);
            sr_ *= rs * osc.rmAmt + (1 - osc.rmAmt);
          }
          const lev = clamp(osc.level + this.modDest("osc." + o + ".level", v), 0, 2);
          vL += sl * lev;
          vR += sr_ * lev;
        }

        if (p.sub.on) {
          v.subPh += midiHz(key + p.sub.octave * 12) / sr;
          const sw = analogWave(v.subPh, midiHz(key) / sr, p.sub.wave | 0, 0.5);
          const sl = sw * p.sub.level;
          vL += sl;
          vR += sl;
        }
        if (p.noise.on) {
          const nl = nz * p.noise.level * 0.35;
          vL += nl;
          vR += nl;
        }

        const velG = 1 - p.voice.velAmp + v.vel * p.voice.velAmp;
        let fl = vL,
          fr = vR;

        const runF = (fi, x) => {
          const fp = p.filt[fi];
          if (!fp.on) return x;
          const envA = fi === 0 ? e1 : e2;
          const kt = (v.note - 60) / 48;
          let cut = fp.cutoff + fp.envAmt * envA + fp.keytrack * kt + this.modDest("filt." + fi + ".cutoff", v);
          cut = expMap(clamp(cut, 0, 1.15), 20, 18000);
          const res = clamp(fp.res + this.modDest("filt." + fi + ".res", v), 0, 0.98);
          const y = this.filterSample(v, fi, tanhF(x * (1 + fp.drive * 4)), cut, res, fp.type | 0, sr);
          return x + (y - x) * fp.mix;
        };

        if (p.filtRoute === 1) {
          const a = runF(0, (fl + fr) * 0.5);
          const b = runF(1, (fl + fr) * 0.5);
          fl = (a + b) * 0.5;
          fr = fl;
        } else {
          fl = runF(0, fl);
          fr = runF(0, fr);
          fl = runF(1, fl);
          fr = runF(1, fr);
        }

        const amp = e0 * velG * (0.25 + 0.75 * (1 - p.env[0].vel + v.vel * p.env[0].vel));
        v.amp = amp;
        const g = amp;
        mixL = fl * g;
        mixR = fr * g;
        this.mixL += mixL;
        this.mixR += mixR;
      }

      let l = this.mixL;
      let r = this.mixR;
      this.mixL = 0;
      this.mixR = 0;

      const abs = Math.abs(l) + Math.abs(r);
      this.audioEnv = this.audioEnv * 0.995 + abs * 0.005;

      const fxed = this.fxProcess(l, r, s, sr);
      l = fxed[0];
      r = fxed[1];
      const psy = this.psychProcess(l, r);
      l = psy[0];
      r = psy[1];

      const mg = p.voice.gain;
      const pan = clamp(p.voice.pan, -1, 1);
      l *= mg * (0.707 * (1 - pan));
      r *= mg * (0.707 * (1 + pan));

      l = tanhF(l * 1.15);
      r = tanhF(r * 1.15);

      this.dcL = this.dcL * 0.995 + l * 0.005;
      this.dcR = this.dcR * 0.995 + r * 0.005;
      l -= this.dcL;
      r -= this.dcR;

      L[s] = l;
      R[s] = r;

      const pk = Math.max(Math.abs(l), Math.abs(r));
      this.peak = Math.max(this.peak * 0.9995, pk);
      this.rmsAcc += l * l + r * r;
      this.scope[this.scopeI] = (l + r) * 0.5;
      this.scopeI = (this.scopeI + 1) & 1023;
    }

    this.vizClock += n;
    if (this.vizClock >= (sr / 30) | 0) {
      this.vizClock = 0;
      const wave = new Array(128);
      const step = 1024 / 128;
      for (let i = 0; i < 128; i++) wave[i] = this.scope[((this.scopeI - 1024 + (i * step) | 0) & 1023)];
      const spec = new Array(64);
      for (let k = 0; k < 64; k++) {
        let re = 0,
          im = 0;
        const hop = 8;
        for (let i = 0; i < 128; i++) {
          const x = this.scope[((this.scopeI - 1024 + i * hop) & 1023)];
          const ang = (TAU * k * i) / 128;
          re += x * Math.cos(ang);
          im -= x * Math.sin(ang);
        }
        spec[k] = Math.min(1, Math.hypot(re, im) / 24);
      }
      let vc = 0;
      const env = [0, 0, 0, 0];
      const wt = [p.osc[0].wtPos, p.osc[1].wtPos, p.osc[2].wtPos];
      for (const v of this.voices) {
        if (v.active) {
          vc++;
          env[0] = Math.max(env[0], v.env[0].val);
          env[1] = Math.max(env[1], v.env[1].val);
          env[2] = Math.max(env[2], v.env[2].val);
          env[3] = Math.max(env[3], v.env[3].val);
        }
      }
      const rms = Math.sqrt(this.rmsAcc / (n * 2));
      this.rmsAcc = 0;
      this.port.postMessage({
        type: "viz",
        wave,
        spec,
        voices: vc,
        wtPos: wt,
        cutoff: [p.filt[0].cutoff, p.filt[1].cutoff],
        env,
        lfo: Array.from(this.lfoVal),
        peak: this.peak,
        rms,
      });
      this.peak *= 0.85;
    }
    return true;
  }
}

registerProcessor("salek-hypercore", HypercoreProcessor);
