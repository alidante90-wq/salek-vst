import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function clamp(x: number, min: number, max: number) {
  return x < min ? min : x > max ? max : x;
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function midiToHz(n: number) {
  return 440 * Math.pow(2, (n - 69) / 12);
}

export function expScale(x: number, min: number, max: number) {
  const t = clamp(x, 0, 1);
  return min * Math.pow(max / min, t);
}

export function dbToGain(db: number) {
  return Math.pow(10, db / 20);
}

export function formatHz(hz: number) {
  if (hz < 100) return `${hz.toFixed(1)} Hz`;
  if (hz < 1000) return `${hz.toFixed(0)} Hz`;
  return `${(hz / 1000).toFixed(2)} kHz`;
}

export function formatMs(sec: number) {
  if (sec < 1) return `${Math.round(sec * 1000)} ms`;
  return `${sec.toFixed(2)} s`;
}

export function deepClone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

export function getPath(obj: unknown, path: string): unknown {
  const parts = path.split(".");
  let cur: unknown = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[p];
  }
  return cur;
}

export function setPath(obj: Record<string, unknown>, path: string, value: unknown) {
  const parts = path.split(".");
  let cur: Record<string, unknown> = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i]!;
    const n = cur[k];
    if (n == null || typeof n !== "object") {
      const next = Number.isInteger(Number(parts[i + 1])) ? [] : {};
      cur[k] = next;
      cur = next as Record<string, unknown>;
    } else {
      cur = n as Record<string, unknown>;
    }
  }
  cur[parts[parts.length - 1]!] = value;
}
