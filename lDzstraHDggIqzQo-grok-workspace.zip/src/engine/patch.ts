import {
  DEFAULT_MACRO_NAMES,
  LFO_SHAPE_SIZE,
  NUM_FX,
  NUM_LFOS,
  NUM_MACROS,
  NUM_MATRIX,
  SEQ_STEPS,
} from "./constants";
import type {
  EnvPatch,
  FilterPatch,
  FxSlot,
  LfoPatch,
  MacroPatch,
  MatrixSlot,
  OscPatch,
  Patch,
  WarpSlot,
} from "./types";

function warp(): WarpSlot {
  return { type: 0, amount: 0, mix: 1 };
}

export function defaultOsc(partial?: Partial<OscPatch>): OscPatch {
  return {
    on: false,
    mode: 0,
    table: 0,
    wtPos: 0,
    morph: 1,
    level: 0.7,
    pan: 0,
    octave: 0,
    semi: 0,
    fine: 0,
    phase: 0,
    phaseRand: 1,
    retrigger: true,
    unison: 1,
    detune: 0.12,
    spread: 0.7,
    analogWave: 2,
    pwm: 0.5,
    warp: [warp(), warp(), warp()],
    fmSrc: -1,
    fmAmt: 0,
    fmRatio: 1,
    fmFeedback: 0,
    amSrc: -1,
    amAmt: 0,
    rmSrc: -1,
    rmAmt: 0,
    pmAmt: 0,
    spectralBright: 0.5,
    grainSize: 0.35,
    grainSpray: 0.2,
    grainDensity: 0.5,
    additivePartials: 0.6,
    ...partial,
  };
}

export function defaultEnv(partial?: Partial<EnvPatch>): EnvPatch {
  return {
    attack: 0.004,
    hold: 0,
    decay: 0.25,
    sustain: 0.75,
    release: 0.22,
    aCurve: 0.35,
    dCurve: 0.45,
    rCurve: 0.4,
    vel: 0.65,
    loop: false,
    retrigger: true,
    ...partial,
  };
}

export function defaultFilter(partial?: Partial<FilterPatch>): FilterPatch {
  return {
    on: true,
    type: 1,
    cutoff: 0.72,
    res: 0.18,
    drive: 0.08,
    mix: 1,
    keytrack: 0.35,
    envAmt: 0,
    ...partial,
  };
}

function defaultLfo(i: number): LfoPatch {
  const custom = Array.from({ length: LFO_SHAPE_SIZE }, (_, n) =>
    Math.sin((Math.PI * 2 * n) / LFO_SHAPE_SIZE),
  );
  return {
    shape: 0,
    custom,
    rate: 0.28 + i * 0.04,
    sync: false,
    syncDiv: 2,
    phase: 0,
    delay: 0,
    fade: 0,
    retrigger: false,
    bipolar: true,
    oneshot: false,
    stereo: 0.15,
    smooth: 0.1,
  };
}

function defaultMacro(i: number): MacroPatch {
  return { name: DEFAULT_MACRO_NAMES[i] ?? `MACRO ${i + 1}`, value: 0, routes: [] };
}

function emptyMatrix(): MatrixSlot[] {
  return Array.from({ length: NUM_MATRIX }, () => ({
    on: false,
    source: 0,
    dest: "",
    amount: 0.5,
    curve: 0,
    bipolar: true,
    invert: false,
    aux: 0,
    auxAmt: 0,
    smooth: 0,
  }));
}

function emptyFx(): FxSlot[] {
  return Array.from({ length: NUM_FX }, () => ({
    type: 0,
    on: false,
    mix: 0.5,
    p1: 0.4,
    p2: 0.4,
    p3: 0.3,
    p4: 0.5,
  }));
}

export function createInitPatch(): Patch {
  const notes = Array(SEQ_STEPS).fill(0);
  const ones = Array(SEQ_STEPS).fill(1);
  const zeros = Array(SEQ_STEPS).fill(0);
  const gates = Array(SEQ_STEPS).fill(0.75);
  return {
    name: "Init",
    author: "SALEK",
    category: "BASS",
    tags: ["HIGHTECH"],
    bpm: 174,
    osc: [
      defaultOsc({ on: true, level: 0.78, unison: 1, table: 0, analogWave: 2 }),
      defaultOsc({ on: false, level: 0.45, table: 6, octave: 0, pan: 0.15 }),
      defaultOsc({ on: false, level: 0.35, table: 3, octave: 1, pan: -0.2 }),
    ],
    sub: { on: true, level: 0.35, octave: -1, wave: 0 },
    noise: { on: false, type: 0, level: 0.12 },
    modOsc: { on: false, wave: 0, ratio: 1, level: 0.4 },
    filt: [
      defaultFilter({ type: 1, cutoff: 0.68, res: 0.16, envAmt: 0.22 }),
      defaultFilter({ on: false, type: 0, cutoff: 0.8, res: 0.1, envAmt: 0 }),
    ],
    filtRoute: 0,
    env: [
      defaultEnv({ attack: 0.003, decay: 0.28, sustain: 0.78, release: 0.18 }),
      defaultEnv({ attack: 0.01, decay: 0.32, sustain: 0.35, release: 0.22 }),
      defaultEnv({ attack: 0.08, decay: 0.4, sustain: 0.5, release: 0.4 }),
      defaultEnv({ attack: 0.2, decay: 0.5, sustain: 0.6, release: 0.8 }),
    ],
    lfo: Array.from({ length: NUM_LFOS }, (_, i) => defaultLfo(i)),
    matrix: emptyMatrix(),
    macros: Array.from({ length: NUM_MACROS }, (_, i) => defaultMacro(i)),
    fx: emptyFx(),
    seq: {
      on: false,
      steps: 16,
      division: 4,
      swing: 0,
      euclidHits: 5,
      euclidLen: 16,
      root: 36,
      notes,
      vels: ones.slice(),
      gates,
      probs: ones.slice(),
      slides: zeros.slice(),
      octs: zeros.slice(),
      ratchets: ones.slice(),
      micro: zeros.slice(),
      mods: zeros.slice(),
    },
    arp: {
      on: false,
      mode: 0,
      rate: 0.45,
      sync: true,
      syncDiv: 4,
      octaves: 1,
      gate: 0.55,
      swing: 0,
      prob: 1,
      ratchet: 1,
    },
    voice: {
      mode: 0,
      voices: 8,
      glide: 0,
      retrigger: true,
      bend: 2,
      velAmp: 0.55,
      gain: 0.72,
      pan: 0,
    },
    chaos: { rate: 0.3, amount: 0, smooth: 0.4, type: 0, stereo: 0.3, seed: 1 },
    psych: {
      fold: 0,
      fm: 0,
      rm: 0,
      phase: 0,
      space: 0,
      smear: 0,
      resonator: 0,
      formant: 0,
      chaos: 0,
      freeze: 0,
    },
  };
}

export function clonePatch(p: Patch): Patch {
  return JSON.parse(JSON.stringify(p)) as Patch;
}

export function applyEuclid(steps: number, hits: number, len: number): boolean[] {
  const n = Math.max(1, Math.min(SEQ_STEPS, len | 0));
  const k = Math.max(0, Math.min(n, hits | 0));
  const pattern = new Array<boolean>(steps).fill(false);
  if (k === 0) return pattern;
  let bucket = 0;
  for (let i = 0; i < n; i++) {
    bucket += k;
    if (bucket >= n) {
      bucket -= n;
      if (i < steps) pattern[i] = true;
    }
  }
  return pattern;
}
