export interface DestInfo {
  id: string;
  label: string;
  min: number;
  max: number;
  bipolar?: boolean;
}

export const DESTINATIONS: DestInfo[] = [
  { id: "osc.0.level", label: "OSC A Level", min: 0, max: 1 },
  { id: "osc.0.wtPos", label: "OSC A WT Pos", min: 0, max: 1 },
  { id: "osc.0.pan", label: "OSC A Pan", min: -1, max: 1, bipolar: true },
  { id: "osc.0.fine", label: "OSC A Fine", min: -100, max: 100, bipolar: true },
  { id: "osc.0.semi", label: "OSC A Semi", min: -12, max: 12, bipolar: true },
  { id: "osc.0.fmAmt", label: "OSC A FM", min: 0, max: 1 },
  { id: "osc.0.amAmt", label: "OSC A AM", min: 0, max: 1 },
  { id: "osc.0.rmAmt", label: "OSC A RM", min: 0, max: 1 },
  { id: "osc.0.pmAmt", label: "OSC A PM", min: 0, max: 1 },
  { id: "osc.0.pwm", label: "OSC A PWM", min: 0, max: 1 },
  { id: "osc.0.detune", label: "OSC A Detune", min: 0, max: 1 },
  { id: "osc.0.warp.0.amount", label: "OSC A Warp 1", min: 0, max: 1 },
  { id: "osc.0.warp.1.amount", label: "OSC A Warp 2", min: 0, max: 1 },
  { id: "osc.0.warp.2.amount", label: "OSC A Warp 3", min: 0, max: 1 },
  { id: "osc.1.level", label: "OSC B Level", min: 0, max: 1 },
  { id: "osc.1.wtPos", label: "OSC B WT Pos", min: 0, max: 1 },
  { id: "osc.1.pan", label: "OSC B Pan", min: -1, max: 1, bipolar: true },
  { id: "osc.1.fine", label: "OSC B Fine", min: -100, max: 100, bipolar: true },
  { id: "osc.1.fmAmt", label: "OSC B FM", min: 0, max: 1 },
  { id: "osc.1.amAmt", label: "OSC B AM", min: 0, max: 1 },
  { id: "osc.1.rmAmt", label: "OSC B RM", min: 0, max: 1 },
  { id: "osc.1.warp.0.amount", label: "OSC B Warp 1", min: 0, max: 1 },
  { id: "osc.2.level", label: "OSC C Level", min: 0, max: 1 },
  { id: "osc.2.wtPos", label: "OSC C WT Pos", min: 0, max: 1 },
  { id: "osc.2.fmAmt", label: "OSC C FM", min: 0, max: 1 },
  { id: "osc.2.warp.0.amount", label: "OSC C Warp 1", min: 0, max: 1 },
  { id: "filt.0.cutoff", label: "Filter 1 Cutoff", min: 0, max: 1 },
  { id: "filt.0.res", label: "Filter 1 Res", min: 0, max: 1 },
  { id: "filt.0.drive", label: "Filter 1 Drive", min: 0, max: 1 },
  { id: "filt.1.cutoff", label: "Filter 2 Cutoff", min: 0, max: 1 },
  { id: "filt.1.res", label: "Filter 2 Res", min: 0, max: 1 },
  { id: "filt.1.drive", label: "Filter 2 Drive", min: 0, max: 1 },
  { id: "voice.gain", label: "Amp", min: 0, max: 1 },
  { id: "voice.pan", label: "Master Pan", min: -1, max: 1, bipolar: true },
  { id: "lfo.0.rate", label: "LFO 1 Rate", min: 0, max: 1 },
  { id: "lfo.1.rate", label: "LFO 2 Rate", min: 0, max: 1 },
  { id: "fx.0.mix", label: "FX 1 Mix", min: 0, max: 1 },
  { id: "fx.0.p1", label: "FX 1 P1", min: 0, max: 1 },
  { id: "fx.1.mix", label: "FX 2 Mix", min: 0, max: 1 },
  { id: "psych.fold", label: "Psych Fold", min: 0, max: 1 },
  { id: "psych.fm", label: "Psych FM", min: 0, max: 1 },
  { id: "psych.space", label: "Psych Space", min: 0, max: 1 },
  { id: "psych.smear", label: "Psych Smear", min: 0, max: 1 },
  { id: "chaos.amount", label: "Chaos Amt", min: 0, max: 1 },
  { id: "sub.level", label: "Sub Level", min: 0, max: 1 },
  { id: "noise.level", label: "Noise Level", min: 0, max: 1 },
];

export const DEST_BY_ID = Object.fromEntries(DESTINATIONS.map((d) => [d.id, d]));

export function destLabel(id: string) {
  return DEST_BY_ID[id]?.label ?? id;
}
