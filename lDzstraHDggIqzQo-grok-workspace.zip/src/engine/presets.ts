import { clonePatch, createInitPatch, defaultOsc } from "./patch";
import type { Patch } from "./types";

function base(name: string, category: string, tags: string[]): Patch {
  const p = createInitPatch();
  p.name = name;
  p.category = category;
  p.tags = tags;
  p.author = "SALEK";
  return p;
}

function route(p: Patch, slot: number, source: number, dest: string, amount: number, bipolar = true) {
  p.matrix[slot] = {
    on: true,
    source,
    dest,
    amount,
    curve: 0,
    bipolar,
    invert: false,
    aux: 0,
    auxAmt: 0,
    smooth: 0,
  };
}

function macro(p: Patch, i: number, dest: string, amount: number) {
  p.macros[i]!.routes.push({ dest, amount });
}

export function factoryPresets(): Patch[] {
  const out: Patch[] = [];

  out.push(createInitPatch());

  {
    const p = base("Hypercore Bass", "BASS", ["HIGHTECH", "FM", "AGGRESSIVE"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 5,
      wtPos: 0.22,
      unison: 3,
      detune: 0.22,
      spread: 0.8,
      level: 0.82,
      fmSrc: 1,
      fmAmt: 0.28,
      fmRatio: 1,
      warp: [
        { type: 28, amount: 0.18, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
      ],
    });
    p.osc[1] = defaultOsc({
      on: true,
      table: 6,
      octave: 1,
      level: 0.35,
      pan: 0.2,
      wtPos: 0.4,
    });
    p.sub.on = true;
    p.sub.level = 0.55;
    p.filt[0].type = 12;
    p.filt[0].cutoff = 0.42;
    p.filt[0].res = 0.38;
    p.filt[0].drive = 0.28;
    p.filt[0].envAmt = 0.45;
    p.env[0].attack = 0.002;
    p.env[0].decay = 0.34;
    p.env[0].sustain = 0.72;
    p.env[1].attack = 0.008;
    p.env[1].decay = 0.28;
    p.env[1].sustain = 0.2;
    p.fx[0] = { type: 1, on: true, mix: 0.35, p1: 0.32, p2: 0.4, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 8, on: true, mix: 0.18, p1: 0.35, p2: 0.28, p3: 0.35, p4: 0.5 };
    route(p, 0, 5, "osc.0.wtPos", 0.22);
    route(p, 1, 6, "filt.0.cutoff", 0.12);
    macro(p, 0, "osc.0.wtPos", 0.4);
    macro(p, 0, "osc.0.fmAmt", 0.3);
    macro(p, 0, "filt.0.cutoff", 0.2);
    macro(p, 2, "osc.0.fmAmt", 0.55);
    macro(p, 3, "filt.0.res", 0.4);
    macro(p, 7, "psych.fold", 0.6);
    out.push(p);
  }

  {
    const p = base("Neuro Fold", "BASS", ["HIGHTECH", "WARP", "AGGRESSIVE"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 5,
      mode: 0,
      wtPos: 0.55,
      unison: 5,
      detune: 0.28,
      spread: 0.9,
      warp: [
        { type: 12, amount: 0.42, mix: 1 },
        { type: 28, amount: 0.22, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
      ],
    });
    p.filt[0].type = 1;
    p.filt[0].cutoff = 0.38;
    p.filt[0].res = 0.48;
    p.filt[0].drive = 0.4;
    p.filt[0].envAmt = 0.55;
    p.psych.fold = 0.22;
    route(p, 0, 5, "osc.0.warp.0.amount", 0.35);
    route(p, 1, 2, "filt.0.cutoff", 0.4, false);
    macro(p, 0, "osc.0.warp.0.amount", 0.5);
    macro(p, 7, "psych.fold", 0.8);
    out.push(p);
  }

  {
    const p = base("Acid Diode", "ACID", ["ACID", "CYBERPUNK"]);
    p.osc[0] = defaultOsc({
      on: true,
      mode: 1,
      analogWave: 2,
      unison: 1,
      level: 0.8,
    });
    p.sub.on = true;
    p.sub.level = 0.4;
    p.filt[0].type = 14;
    p.filt[0].cutoff = 0.28;
    p.filt[0].res = 0.72;
    p.filt[0].drive = 0.45;
    p.filt[0].envAmt = 0.7;
    p.env[1].attack = 0.001;
    p.env[1].decay = 0.18;
    p.env[1].sustain = 0.08;
    p.env[1].release = 0.12;
    p.seq.on = true;
    p.seq.steps = 16;
    p.seq.division = 4;
    p.seq.root = 33;
    const pattern = [0, 0, 12, 0, 3, 0, 7, 0, 0, 12, 0, 3, 7, 0, 10, 0];
    p.seq.notes = [...pattern, ...Array(48).fill(0)];
    p.seq.gates = p.seq.notes.map((n, i) => (i < 16 && n >= 0 ? 0.55 : 0));
    p.seq.vels = p.seq.vels.map((_, i) => (i % 4 === 0 ? 1 : 0.7));
    route(p, 0, 5, "filt.0.cutoff", 0.18);
    macro(p, 3, "filt.0.cutoff", 0.45);
    macro(p, 3, "filt.0.res", 0.3);
    out.push(p);
  }

  {
    const p = base("FM Screech", "SCREECH", ["FM", "HIGHTECH", "ALIEN"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 8,
      wtPos: 0.7,
      unison: 3,
      detune: 0.15,
      fmSrc: 1,
      fmAmt: 0.62,
      fmRatio: 2.01,
      octave: 1,
    });
    p.osc[1] = defaultOsc({
      on: true,
      mode: 1,
      analogWave: 0,
      octave: 2,
      level: 0.5,
      fmRatio: 3,
    });
    p.modOsc.on = true;
    p.modOsc.ratio = 3.02;
    p.modOsc.level = 0.6;
    p.filt[0].type = 4;
    p.filt[0].cutoff = 0.55;
    p.filt[0].res = 0.35;
    p.env[0].attack = 0.01;
    p.env[0].decay = 0.4;
    p.env[0].sustain = 0.55;
    p.psych.fm = 0.18;
    route(p, 0, 5, "osc.0.fmAmt", 0.4);
    route(p, 1, 6, "osc.0.wtPos", 0.3);
    macro(p, 2, "osc.0.fmAmt", 0.7);
    out.push(p);
  }

  {
    const p = base("Psy Lead", "LEAD", ["PSYCHEDELIC", "HIGHTECH"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 6,
      wtPos: 0.35,
      unison: 3,
      detune: 0.18,
      spread: 0.85,
      warp: [
        { type: 20, amount: 0.28, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
      ],
    });
    p.osc[1] = defaultOsc({ on: true, table: 2, octave: 1, level: 0.28, pan: -0.3, wtPos: 0.5 });
    p.filt[0].cutoff = 0.62;
    p.filt[0].res = 0.22;
    p.lfo[0].rate = 0.22;
    p.lfo[0].sync = true;
    p.lfo[0].syncDiv = 2;
    p.fx[0] = { type: 13, on: true, mix: 0.28, p1: 0.3, p2: 0.4, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 8, on: true, mix: 0.22, p1: 0.4, p2: 0.35, p3: 0.4, p4: 0.5 };
    p.psych.space = 0.18;
    route(p, 0, 5, "osc.0.wtPos", 0.45);
    route(p, 1, 6, "osc.0.pan", 0.4);
    macro(p, 1, "psych.space", 0.5);
    macro(p, 1, "osc.0.wtPos", 0.35);
    out.push(p);
  }

  {
    const p = base("Dark Pad", "PAD", ["DARK", "ORGANIC"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 9,
      wtPos: 0.2,
      unison: 5,
      detune: 0.2,
      spread: 1,
      level: 0.55,
    });
    p.osc[1] = defaultOsc({ on: true, table: 0, wtPos: 0.9, level: 0.35, pan: 0.4, unison: 3 });
    p.filt[0].type = 1;
    p.filt[0].cutoff = 0.32;
    p.filt[0].res = 0.12;
    p.env[0].attack = 0.45;
    p.env[0].decay = 0.8;
    p.env[0].sustain = 0.7;
    p.env[0].release = 1.4;
    p.env[1].attack = 0.6;
    p.env[1].decay = 1.2;
    p.fx[0] = { type: 13, on: true, mix: 0.4, p1: 0.25, p2: 0.45, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 10, on: true, mix: 0.45, p1: 0.5, p2: 0.55, p3: 0.4, p4: 0.5 };
    route(p, 0, 5, "osc.0.wtPos", 0.25);
    route(p, 1, 7, "filt.0.cutoff", 0.15);
    macro(p, 5, "psych.space", 0.7);
    out.push(p);
  }

  {
    const p = base("Alien Texture", "TEXTURE", ["ALIEN", "GRANULAR", "CHAOTIC"]);
    p.osc[0] = defaultOsc({
      on: true,
      mode: 4,
      table: 6,
      grainSize: 0.45,
      grainSpray: 0.6,
      grainDensity: 0.7,
      unison: 1,
      wtPos: 0.4,
    });
    p.osc[1] = defaultOsc({ on: true, mode: 5, table: 3, level: 0.3, spectralBright: 0.7 });
    p.filt[0].type = 8;
    p.filt[0].cutoff = 0.48;
    p.noise.on = true;
    p.noise.level = 0.08;
    p.chaos.amount = 0.35;
    p.psych.smear = 0.28;
    p.psych.chaos = 0.2;
    route(p, 0, 34, "osc.0.wtPos", 0.4);
    route(p, 1, 32, "filt.0.cutoff", 0.25);
    macro(p, 4, "chaos.amount", 0.8);
    out.push(p);
  }

  {
    const p = base("Laser", "FX", ["HIGHTECH", "CYBERPUNK"]);
    p.osc[0] = defaultOsc({
      on: true,
      mode: 1,
      analogWave: 0,
      fmSrc: 3,
      fmAmt: 0.55,
      fmRatio: 4,
      unison: 1,
    });
    p.modOsc.on = true;
    p.modOsc.ratio = 7;
    p.env[0].attack = 0.001;
    p.env[0].decay = 0.22;
    p.env[0].sustain = 0;
    p.env[0].release = 0.08;
    p.filt[0].type = 3;
    p.filt[0].cutoff = 0.55;
    p.filt[0].envAmt = 0.5;
    route(p, 0, 5, "osc.0.fmAmt", 0.5);
    out.push(p);
  }

  {
    const p = base("Glass Pluck", "PLUCK", ["METALLIC", "ORGANIC"]);
    p.osc[0] = defaultOsc({ on: true, table: 9, wtPos: 0.15, unison: 3, detune: 0.08, level: 0.7 });
    p.env[0].attack = 0.001;
    p.env[0].decay = 0.42;
    p.env[0].sustain = 0.12;
    p.env[0].release = 0.28;
    p.filt[0].cutoff = 0.7;
    p.filt[0].envAmt = 0.3;
    p.fx[0] = { type: 10, on: true, mix: 0.28, p1: 0.4, p2: 0.4, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 8, on: true, mix: 0.16, p1: 0.3, p2: 0.25, p3: 0.5, p4: 0.5 };
    out.push(p);
  }

  {
    const p = base("Metallic Bell", "LEAD", ["METALLIC", "FM"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 3,
      fmSrc: 1,
      fmAmt: 0.48,
      fmRatio: 1.41,
      unison: 1,
      level: 0.65,
    });
    p.osc[1] = defaultOsc({ on: true, mode: 1, analogWave: 0, octave: 1, level: 0.4, fine: 6 });
    p.env[0].attack = 0.002;
    p.env[0].decay = 1.1;
    p.env[0].sustain = 0.15;
    p.env[0].release = 0.9;
    p.fx[0] = { type: 10, on: true, mix: 0.4, p1: 0.5, p2: 0.5, p3: 0.3, p4: 0.5 };
    out.push(p);
  }

  {
    const p = base("Chaos Arp", "ARP", ["CHAOTIC", "HIGHTECH"]);
    p.osc[0] = defaultOsc({ on: true, table: 4, wtPos: 0.4, unison: 3, detune: 0.14 });
    p.arp.on = true;
    p.arp.mode = 0;
    p.arp.sync = true;
    p.arp.syncDiv = 4;
    p.arp.octaves = 2;
    p.arp.gate = 0.45;
    p.filt[0].cutoff = 0.58;
    p.lfo[0].sync = true;
    p.lfo[0].syncDiv = 1;
    route(p, 0, 5, "filt.0.cutoff", 0.28);
    route(p, 1, 5, "osc.0.wtPos", 0.4);
    p.fx[0] = { type: 8, on: true, mix: 0.22, p1: 0.35, p2: 0.3, p3: 0.45, p4: 0.5 };
    out.push(p);
  }

  {
    const p = base("Formant Vocal", "LEAD", ["ORGANIC", "SPECTRAL"]);
    p.osc[0] = defaultOsc({ on: true, table: 2, wtPos: 0.3, unison: 1, level: 0.75, warp: [
      { type: 21, amount: 0.4, mix: 1 },
      { type: 20, amount: 0.2, mix: 1 },
      { type: 0, amount: 0, mix: 1 },
    ]});
    p.filt[0].type = 9;
    p.filt[0].cutoff = 0.45;
    p.filt[0].res = 0.4;
    p.psych.formant = 0.35;
    route(p, 0, 5, "osc.0.wtPos", 0.55);
    route(p, 1, 6, "psych.formant", 0.4);
    out.push(p);
  }

  {
    const p = base("Digital Scream", "SCREECH", ["AGGRESSIVE", "DIGITAL"]);
    p.osc[0] = defaultOsc({
      on: true,
      mode: 2,
      analogWave: 2,
      table: 8,
      unison: 3,
      detune: 0.25,
      warp: [
        { type: 4, amount: 0.45, mix: 1 },
        { type: 22, amount: 0.3, mix: 1 },
        { type: 0, amount: 0, mix: 1 },
      ],
    });
    p.filt[0].type = 4;
    p.filt[0].cutoff = 0.6;
    p.filt[0].res = 0.28;
    p.env[0].attack = 0.02;
    p.psych.fold = 0.15;
    route(p, 0, 5, "osc.0.warp.0.amount", 0.5);
    out.push(p);
  }

  {
    const p = base("Hypnotic Seq", "ARP", ["PSYCHEDELIC", "DARKPSY"]);
    p.osc[0] = defaultOsc({ on: true, table: 13, wtPos: 0.25, unison: 1 });
    p.seq.on = true;
    p.seq.steps = 16;
    p.seq.division = 4;
    p.seq.root = 38;
    p.seq.notes = [0, 7, 3, 10, 0, 7, 12, 5, 0, 3, 7, 10, 14, 7, 3, 0].concat(Array(48).fill(0));
    p.seq.mods = p.seq.notes.map((_, i) => (i % 4) / 4);
    p.filt[0].cutoff = 0.4;
    p.filt[0].res = 0.35;
    p.filt[0].envAmt = 0.35;
    route(p, 0, 36, "filt.0.cutoff", 0.4);
    route(p, 1, 5, "osc.0.wtPos", 0.3);
    p.fx[0] = { type: 9, on: true, mix: 0.2, p1: 0.4, p2: 0.32, p3: 0.4, p4: 0.5 };
    out.push(p);
  }

  {
    const p = base("Space Atmos", "ATMOS", ["DARK", "PSYCHEDELIC"]);
    p.osc[0] = defaultOsc({ on: true, table: 14, wtPos: 0.4, unison: 5, detune: 0.3, spread: 1, level: 0.45 });
    p.osc[1] = defaultOsc({ on: true, mode: 4, table: 9, level: 0.3, grainSpray: 0.7 });
    p.env[0].attack = 1.2;
    p.env[0].release = 2.2;
    p.filt[0].cutoff = 0.28;
    p.psych.space = 0.55;
    p.psych.smear = 0.35;
    p.fx[0] = { type: 10, on: true, mix: 0.6, p1: 0.6, p2: 0.7, p3: 0.4, p4: 0.5 };
    route(p, 0, 5, "osc.0.wtPos", 0.4);
    macro(p, 5, "psych.space", 0.8);
    out.push(p);
  }

  {
    const p = base("Destroyer", "BASS", ["AGGRESSIVE", "CHAOTIC"]);
    p.osc[0] = defaultOsc({
      on: true,
      table: 11,
      wtPos: 0.5,
      unison: 5,
      detune: 0.35,
      warp: [
        { type: 28, amount: 0.5, mix: 1 },
        { type: 22, amount: 0.35, mix: 1 },
        { type: 12, amount: 0.3, mix: 1 },
      ],
    });
    p.filt[0].type = 12;
    p.filt[0].cutoff = 0.35;
    p.filt[0].res = 0.45;
    p.filt[0].drive = 0.55;
    p.psych.fold = 0.4;
    p.psych.chaos = 0.25;
    p.fx[0] = { type: 1, on: true, mix: 0.5, p1: 0.55, p2: 0.4, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 3, on: true, mix: 0.22, p1: 0.4, p2: 0.3, p3: 0.3, p4: 0.5 };
    macro(p, 7, "psych.fold", 0.9);
    macro(p, 7, "osc.0.warp.0.amount", 0.6);
    out.push(p);
  }

  {
    const p = base("Sub Mutation", "BASS", ["HIGHTECH", "DARK"]);
    p.osc[0] = defaultOsc({ on: true, mode: 1, analogWave: 2, unison: 1, level: 0.55 });
    p.sub.on = true;
    p.sub.level = 0.85;
    p.sub.octave = -1;
    p.osc[1] = defaultOsc({ on: true, table: 5, octave: 1, level: 0.25, wtPos: 0.3, unison: 3 });
    p.filt[0].type = 1;
    p.filt[0].cutoff = 0.36;
    p.filt[0].res = 0.22;
    p.filt[0].envAmt = 0.25;
    route(p, 0, 5, "osc.1.wtPos", 0.5);
    macro(p, 0, "osc.1.level", 0.6);
    macro(p, 0, "filt.0.cutoff", 0.3);
    out.push(p);
  }

  {
    const p = base("Hi-Tech Stab", "LEAD", ["HIGHTECH", "CYBERPUNK"]);
    p.osc[0] = defaultOsc({ on: true, table: 0, wtPos: 0.12, unison: 5, detune: 0.16, spread: 0.85 });
    p.osc[1] = defaultOsc({ on: true, table: 4, octave: 1, level: 0.3, wtPos: 0.2 });
    p.env[0].attack = 0.001;
    p.env[0].decay = 0.22;
    p.env[0].sustain = 0.45;
    p.env[0].release = 0.16;
    p.filt[0].cutoff = 0.58;
    p.filt[0].envAmt = 0.4;
    p.fx[0] = { type: 13, on: true, mix: 0.2, p1: 0.3, p2: 0.3, p3: 0.3, p4: 0.5 };
    p.fx[1] = { type: 8, on: true, mix: 0.14, p1: 0.28, p2: 0.22, p3: 0.35, p4: 0.5 };
    out.push(p);
  }

  {
    const p = base("Glitch Perc", "PERCUSSION", ["CHAOTIC", "DIGITAL"]);
    p.osc[0] = defaultOsc({
      on: true,
      mode: 6,
      analogWave: 0,
      level: 0.5,
    });
    p.osc[0].mode = 6;
    p.noise.on = true;
    p.noise.level = 0.4;
    p.env[0].attack = 0.001;
    p.env[0].decay = 0.12;
    p.env[0].sustain = 0;
    p.env[0].release = 0.08;
    p.filt[0].type = 3;
    p.filt[0].cutoff = 0.5;
    p.filt[0].envAmt = 0.6;
    p.fx[0] = { type: 3, on: true, mix: 0.3, p1: 0.45, p2: 0.3, p3: 0.3, p4: 0.5 };
    out.push(p);
  }

  return out.map((p) => clonePatch(p));
}

export const USER_PRESET_KEY = "salek-hypercore-user-presets";
export const FAVORITES_KEY = "salek-hypercore-favorites";
export const RECENT_KEY = "salek-hypercore-recent";
