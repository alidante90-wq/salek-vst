export const WT_SIZE = 2048;
export const WT_FRAMES = 64;
export const MAX_VOICES = 12;
export const UNISON_MAX = 7;
export const NUM_OSCS = 3;
export const NUM_WARPS = 3;
export const NUM_ENVS = 4;
export const NUM_LFOS = 8;
export const NUM_MACROS = 8;
export const NUM_MATRIX = 64;
export const NUM_FILTERS = 2;
export const NUM_FX = 8;
export const SEQ_STEPS = 64;
export const LFO_SHAPE_SIZE = 128;
export const HARMONICS = 32;

export const OSC_MODES = [
  "WAVETABLE",
  "ANALOG",
  "DIGITAL",
  "SAMPLE",
  "GRANULAR",
  "SPECTRAL",
  "NOISE",
  "ADDITIVE",
] as const;

export const ANALOG_WAVES = ["SINE", "TRI", "SAW", "SQUARE", "PULSE"] as const;

export const WARP_TYPES = [
  "OFF",
  "BEND+",
  "BEND-",
  "MIRROR",
  "SYNC",
  "SYNC+",
  "SYNC-",
  "PWM",
  "ASYMMETRY",
  "SQUEEZE",
  "STRETCH",
  "COMPRESS",
  "FOLD",
  "MIRROR FOLD",
  "ZERO FOLD",
  "FM WARP",
  "PHASE WARP",
  "PHASE DIST",
  "HARM STRETCH",
  "HARM COMPRESS",
  "FORMANT",
  "VOWEL",
  "BITCRUSH",
  "QUANTIZE",
  "DOWNSAMPLE",
  "RECTIFY",
  "SOFT CLIP",
  "HARD CLIP",
  "WAVEFOLD",
  "FRACTAL",
  "CHAOS",
  "LOGISTIC",
  "RANDOM",
] as const;

export const FILTER_TYPES = [
  "LP12",
  "LP24",
  "LP36",
  "HP12",
  "HP24",
  "BP",
  "NOTCH",
  "COMB",
  "FORMANT",
  "VOWEL",
  "RESONATOR",
  "DIODE",
  "LADDER",
  "SVF",
  "ACID",
  "PSYCHO",
] as const;

export const LFO_SHAPES = [
  "SINE",
  "TRI",
  "SAW",
  "RAMP",
  "SQUARE",
  "S&H",
  "SMOOTH",
  "CUSTOM",
] as const;

export const FX_TYPES = [
  "OFF",
  "DISTORT",
  "WAVEFOLD",
  "BITCRUSH",
  "DOWNSAMPLE",
  "FILTER",
  "EQ",
  "COMPRESS",
  "DELAY",
  "PINGPONG",
  "REVERB",
  "PHASER",
  "FLANGER",
  "CHORUS",
  "FREQ SHIFT",
  "RING MOD",
  "WIDENER",
  "TRANSIENT",
] as const;

export const ARP_MODES = [
  "UP",
  "DOWN",
  "UP/DOWN",
  "RANDOM",
  "CONVERGE",
  "DIVERGE",
  "INSIDE",
  "OUTSIDE",
  "ORDER",
  "CHAOS",
] as const;

export const VOICE_MODES = ["POLY", "MONO", "LEGATO"] as const;

export const SYNC_DIVS = [
  "1/1",
  "1/2",
  "1/4",
  "1/8",
  "1/16",
  "1/32",
  "1/64",
  "1/4T",
  "1/8T",
  "1/16T",
  "1/4D",
  "1/8D",
  "1/16D",
] as const;

export const SYNC_BEATS = [
  4, 2, 1, 0.5, 0.25, 0.125, 0.0625, 2 / 3, 1 / 3, 1 / 6, 1.5, 0.75, 0.375,
];

export const MOD_SOURCES = [
  "OFF",
  "ENV 1",
  "ENV 2",
  "ENV 3",
  "ENV 4",
  "LFO 1",
  "LFO 2",
  "LFO 3",
  "LFO 4",
  "LFO 5",
  "LFO 6",
  "LFO 7",
  "LFO 8",
  "MACRO 1",
  "MACRO 2",
  "MACRO 3",
  "MACRO 4",
  "MACRO 5",
  "MACRO 6",
  "MACRO 7",
  "MACRO 8",
  "VELOCITY",
  "NOTE",
  "KEYTRACK",
  "AFTERTOUCH",
  "MOD WHEEL",
  "PITCH BEND",
  "MPE X",
  "MPE Y",
  "MPE PRESS",
  "RANDOM",
  "S&H",
  "PERLIN",
  "LORENZ",
  "CHAOS",
  "AUDIO ENV",
  "SEQUENCER",
] as const;

export const PRESET_CATEGORIES = [
  "BASS",
  "LEAD",
  "FM LEAD",
  "SCREECH",
  "ACID",
  "PAD",
  "ATMOS",
  "FX",
  "PLUCK",
  "ARP",
  "DRUM",
  "PERCUSSION",
  "RISER",
  "IMPACT",
  "TEXTURE",
  "EXPERIMENTAL",
] as const;

export const PRESET_TAGS = [
  "HIGHTECH",
  "DARKPSY",
  "PSYCHEDELIC",
  "CYBERPUNK",
  "FM",
  "AM",
  "RM",
  "WARP",
  "GRANULAR",
  "SPECTRAL",
  "ACID",
  "AGGRESSIVE",
  "DARK",
  "ALIEN",
  "METALLIC",
  "ORGANIC",
  "CHAOTIC",
] as const;

export const DEFAULT_MACRO_NAMES = [
  "MUTATION",
  "PSYCHE",
  "FM",
  "ACID",
  "CHAOS",
  "SPACE",
  "ENERGY",
  "DESTROY",
] as const;

export const WAVETABLE_NAMES = [
  "Analog Morph",
  "Harmonic Sweep",
  "Formant Vowels",
  "Metallic",
  "Digital Sync",
  "Neuro Fold",
  "Alien FM",
  "Organ Drawbar",
  "Scream",
  "Glass",
  "Bit Crush",
  "Chaos Map",
  "Pulse Width",
  "Spectral Saw",
  "Vocal Tract",
  "User",
] as const;

export const PAGES = [
  "SYNTH",
  "WAVETABLE",
  "MOD",
  "MATRIX",
  "FX",
  "SEQ",
  "GLOBAL",
] as const;

export type PageId = (typeof PAGES)[number];
