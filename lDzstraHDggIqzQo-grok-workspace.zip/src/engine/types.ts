import type {
  ANALOG_WAVES,
  ARP_MODES,
  FILTER_TYPES,
  FX_TYPES,
  LFO_SHAPES,
  OSC_MODES,
  WARP_TYPES,
} from "./constants";

export type OscMode = (typeof OSC_MODES)[number];
export type AnalogWave = (typeof ANALOG_WAVES)[number];
export type WarpType = (typeof WARP_TYPES)[number];
export type FilterType = (typeof FILTER_TYPES)[number];
export type LfoShape = (typeof LFO_SHAPES)[number];
export type FxType = (typeof FX_TYPES)[number];
export type ArpMode = (typeof ARP_MODES)[number];

export interface WarpSlot {
  type: number;
  amount: number;
  mix: number;
}

export interface OscPatch {
  on: boolean;
  mode: number;
  table: number;
  wtPos: number;
  morph: number;
  level: number;
  pan: number;
  octave: number;
  semi: number;
  fine: number;
  phase: number;
  phaseRand: number;
  retrigger: boolean;
  unison: number;
  detune: number;
  spread: number;
  analogWave: number;
  pwm: number;
  warp: [WarpSlot, WarpSlot, WarpSlot];
  fmSrc: number;
  fmAmt: number;
  fmRatio: number;
  fmFeedback: number;
  amSrc: number;
  amAmt: number;
  rmSrc: number;
  rmAmt: number;
  pmAmt: number;
  spectralBright: number;
  grainSize: number;
  grainSpray: number;
  grainDensity: number;
  additivePartials: number;
}

export interface FilterPatch {
  on: boolean;
  type: number;
  cutoff: number;
  res: number;
  drive: number;
  mix: number;
  keytrack: number;
  envAmt: number;
}

export interface EnvPatch {
  attack: number;
  hold: number;
  decay: number;
  sustain: number;
  release: number;
  aCurve: number;
  dCurve: number;
  rCurve: number;
  vel: number;
  loop: boolean;
  retrigger: boolean;
}

export interface LfoPatch {
  shape: number;
  custom: number[];
  rate: number;
  sync: boolean;
  syncDiv: number;
  phase: number;
  delay: number;
  fade: number;
  retrigger: boolean;
  bipolar: boolean;
  oneshot: boolean;
  stereo: number;
  smooth: number;
}

export interface MatrixSlot {
  on: boolean;
  source: number;
  dest: string;
  amount: number;
  curve: number;
  bipolar: boolean;
  invert: boolean;
  aux: number;
  auxAmt: number;
  smooth: number;
}

export interface MacroRoute {
  dest: string;
  amount: number;
}

export interface MacroPatch {
  name: string;
  value: number;
  routes: MacroRoute[];
}

export interface FxSlot {
  type: number;
  on: boolean;
  mix: number;
  p1: number;
  p2: number;
  p3: number;
  p4: number;
}

export interface SeqPatch {
  on: boolean;
  steps: number;
  division: number;
  swing: number;
  euclidHits: number;
  euclidLen: number;
  root: number;
  notes: number[];
  vels: number[];
  gates: number[];
  probs: number[];
  slides: number[];
  octs: number[];
  ratchets: number[];
  micro: number[];
  mods: number[];
}

export interface ArpPatch {
  on: boolean;
  mode: number;
  rate: number;
  sync: boolean;
  syncDiv: number;
  octaves: number;
  gate: number;
  swing: number;
  prob: number;
  ratchet: number;
}

export interface VoicePatch {
  mode: number;
  voices: number;
  glide: number;
  retrigger: boolean;
  bend: number;
  velAmp: number;
  gain: number;
  pan: number;
}

export interface ChaosPatch {
  rate: number;
  amount: number;
  smooth: number;
  type: number;
  stereo: number;
  seed: number;
}

export interface PsychPatch {
  fold: number;
  fm: number;
  rm: number;
  phase: number;
  space: number;
  smear: number;
  resonator: number;
  formant: number;
  chaos: number;
  freeze: number;
}

export interface SubPatch {
  on: boolean;
  level: number;
  octave: number;
  wave: number;
}

export interface NoisePatch {
  on: boolean;
  type: number;
  level: number;
}

export interface ModOscPatch {
  on: boolean;
  wave: number;
  ratio: number;
  level: number;
}

export interface Patch {
  name: string;
  author: string;
  category: string;
  tags: string[];
  bpm: number;
  osc: [OscPatch, OscPatch, OscPatch];
  sub: SubPatch;
  noise: NoisePatch;
  modOsc: ModOscPatch;
  filt: [FilterPatch, FilterPatch];
  filtRoute: number;
  env: [EnvPatch, EnvPatch, EnvPatch, EnvPatch];
  lfo: LfoPatch[];
  matrix: MatrixSlot[];
  macros: MacroPatch[];
  fx: FxSlot[];
  seq: SeqPatch;
  arp: ArpPatch;
  voice: VoicePatch;
  chaos: ChaosPatch;
  psych: PsychPatch;
}

export interface VizFrame {
  wave: number[];
  spec: number[];
  voices: number;
  wtPos: [number, number, number];
  cutoff: [number, number];
  env: [number, number, number, number];
  lfo: number[];
  peak: number;
  rms: number;
}

export type EngineMessage =
  | { type: "patch"; patch: Patch }
  | { type: "set"; path: string; value: number | boolean | string | number[] }
  | { type: "noteOn"; note: number; velocity: number; channel?: number }
  | { type: "noteOff"; note: number; channel?: number }
  | { type: "cc"; cc: number; value: number }
  | { type: "bend"; value: number; channel?: number }
  | { type: "at"; value: number }
  | { type: "panic" }
  | { type: "tables"; tables: ArrayBuffer[] }
  | { type: "userTable"; data: ArrayBuffer; frames: number; size: number }
  | { type: "lfoShape"; index: number; points: number[] }
  | { type: "seq"; seq: SeqPatch }
  | { type: "bpm"; value: number };
