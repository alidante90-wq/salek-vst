import { WT_FRAMES, WT_SIZE } from "./constants";

export interface WaveTable {
  name: string;
  frames: number;
  size: number;
  data: Float32Array;
}

function normalize(buf: Float32Array, off: number, size: number) {
  let peak = 1e-12;
  for (let i = 0; i < size; i++) peak = Math.max(peak, Math.abs(buf[off + i]!));
  const g = 0.99 / peak;
  for (let i = 0; i < size; i++) buf[off + i]! *= g;
}

function fillTable(
  name: string,
  fn: (phase: number, frame: number) => number,
  frames = WT_FRAMES,
  size = WT_SIZE,
): WaveTable {
  const data = new Float32Array(frames * size);
  for (let f = 0; f < frames; f++) {
    const t = frames === 1 ? 0 : f / (frames - 1);
    const off = f * size;
    for (let i = 0; i < size; i++) data[off + i] = fn(i / size, t);
    normalize(data, off, size);
  }
  return { name, frames, size, data };
}

function blSaw(p: number, harmonics: number) {
  let s = 0;
  const h = Math.max(1, harmonics | 0);
  for (let n = 1; n <= h; n++) s += Math.sin(Math.PI * 2 * n * p) / n;
  return s * (2 / Math.PI);
}

function blSquare(p: number, harmonics: number) {
  let s = 0;
  const h = Math.max(1, harmonics | 0);
  for (let n = 1; n <= h; n += 2) s += Math.sin(Math.PI * 2 * n * p) / n;
  return s * (4 / Math.PI);
}

function vowel(p: number, formants: number[]) {
  let s = 0;
  for (const f of formants) {
    s += Math.sin(Math.PI * 2 * f * p) * Math.exp(-0.08 * f);
  }
  return s;
}

const VOWELS = [
  [1, 3, 5],
  [1, 2.4, 7],
  [1, 5, 9],
  [1, 2.2, 4.4],
  [1, 1.8, 8],
];

export function generateFactoryTables(): WaveTable[] {
  return [
    fillTable("Analog Morph", (p, t) => {
      const saw = blSaw(p, 24);
      const sq = blSquare(p, 24);
      const tri = (2 / Math.PI) * Math.asin(Math.sin(Math.PI * 2 * p));
      const sine = Math.sin(Math.PI * 2 * p);
      if (t < 0.33) return saw * (1 - t / 0.33) + sq * (t / 0.33);
      if (t < 0.66) {
        const u = (t - 0.33) / 0.33;
        return sq * (1 - u) + tri * u;
      }
      const u = (t - 0.66) / 0.34;
      return tri * (1 - u) + sine * u;
    }),
    fillTable("Harmonic Sweep", (p, t) => blSaw(p, 2 + Math.floor(t * 46))),
    fillTable("Formant Vowels", (p, t) => {
      const i = t * (VOWELS.length - 1);
      const a = VOWELS[i | 0]!;
      const b = VOWELS[Math.min(VOWELS.length - 1, (i | 0) + 1)]!;
      const u = i - (i | 0);
      const f = a.map((v, k) => v + (b[k]! - v) * u);
      return vowel(p, f);
    }),
    fillTable("Metallic", (p, t) => {
      const r = 1.41 + t * 1.7;
      return (
        Math.sin(Math.PI * 2 * p) +
        0.55 * Math.sin(Math.PI * 2 * p * r) +
        0.32 * Math.sin(Math.PI * 2 * p * r * 1.61) +
        0.18 * Math.sin(Math.PI * 2 * p * (2 + t * 5))
      );
    }),
    fillTable("Digital Sync", (p, t) => {
      const ratio = 1 + t * 11;
      const sp = (p * ratio) % 1;
      return blSaw(sp, 18) * (1 - p * 0.35);
    }),
    fillTable("Neuro Fold", (p, t) => {
      let s = blSaw(p, 20);
      const drive = 1 + t * 6;
      s = Math.sin(s * drive * Math.PI);
      s = Math.abs(s) * 2 - 1;
      return Math.sin(s * (1 + t * 3));
    }),
    fillTable("Alien FM", (p, t) => {
      const mod = Math.sin(Math.PI * 2 * p * (1 + Math.floor(t * 7)));
      const idx = 0.4 + t * 8;
      return Math.sin(Math.PI * 2 * p + mod * idx);
    }),
    fillTable("Organ Drawbar", (p, t) => {
      const bars = [1, 0.7, 0.45, 0.6, 0.3, 0.25, 0.18, 0.12];
      let s = 0;
      for (let n = 0; n < bars.length; n++) {
        const g = bars[n]! * (n < 2 + t * 6 ? 1 : 0.35 + t);
        s += Math.sin(Math.PI * 2 * p * (n + 1)) * g;
      }
      return s;
    }),
    fillTable("Scream", (p, t) => {
      const h = 8 + t * 30;
      let s = 0;
      for (let n = 1; n <= h; n++) {
        const w = n > 6 ? 1 : 0.15;
        s += (Math.sin(Math.PI * 2 * n * p) / n) * w;
      }
      return Math.tanh(s * (2 + t * 4));
    }),
    fillTable("Glass", (p, t) => {
      let s = 0;
      for (let n = 1; n <= 16; n++) {
        const inh = n * (1 + t * 0.07 * n);
        s += Math.sin(Math.PI * 2 * inh * p) / (n * n);
      }
      return s;
    }),
    fillTable("Bit Crush", (p, t) => {
      const bits = 3 + t * 5;
      const steps = Math.pow(2, bits);
      const s = blSaw(p, 16);
      return Math.round(s * steps) / steps;
    }),
    fillTable("Chaos Map", (p, t) => {
      const r = 3.6 + t * 0.399;
      let x = 0.2 + p * 0.6;
      for (let i = 0; i < 8; i++) x = r * x * (1 - x);
      return x * 2 - 1;
    }),
    fillTable("Pulse Width", (p, t) => {
      const w = 0.08 + t * 0.42;
      return p < w ? 1 : -1;
    }),
    fillTable("Spectral Saw", (p, t) => {
      let s = 0;
      const tilt = -0.2 - t * 1.4;
      for (let n = 1; n <= 40; n++) {
        s += Math.sin(Math.PI * 2 * n * p) * Math.pow(n, tilt);
      }
      return s;
    }),
    fillTable("Vocal Tract", (p, t) => {
      const f1 = 2 + t * 4;
      const f2 = 6 + Math.sin(t * 6) * 3;
      const f3 = 11 + t * 5;
      return (
        Math.sin(Math.PI * 2 * f1 * p) * 0.7 +
        Math.sin(Math.PI * 2 * f2 * p) * 0.45 +
        Math.sin(Math.PI * 2 * f3 * p) * 0.22
      );
    }),
    fillTable("User", (p) => Math.sin(Math.PI * 2 * p), 64, WT_SIZE),
  ];
}

export function lookupTable(table: WaveTable, framePos: number, phase: number) {
  const { frames, size, data } = table;
  const f = Math.max(0, Math.min(frames - 1.0001, framePos * (frames - 1)));
  const f0 = f | 0;
  const f1 = Math.min(frames - 1, f0 + 1);
  const ft = f - f0;
  const p = (phase - Math.floor(phase)) * size;
  const i0 = p | 0;
  const i1 = (i0 + 1) % size;
  const pt = p - i0;
  const a = data[f0 * size + i0]! + (data[f0 * size + i1]! - data[f0 * size + i0]!) * pt;
  const b = data[f1 * size + i0]! + (data[f1 * size + i1]! - data[f1 * size + i0]!) * pt;
  return a + (b - a) * ft;
}

export function frameSlice(table: WaveTable, framePos: number): Float32Array {
  const out = new Float32Array(table.size);
  const f = Math.max(0, Math.min(table.frames - 1.0001, framePos * (table.frames - 1)));
  const f0 = f | 0;
  const f1 = Math.min(table.frames - 1, f0 + 1);
  const ft = f - f0;
  const size = table.size;
  for (let i = 0; i < size; i++) {
    out[i] = table.data[f0 * size + i]! + (table.data[f1 * size + i]! - table.data[f0 * size + i]!) * ft;
  }
  return out;
}

export function harmonicsOf(frame: Float32Array, n = 32): number[] {
  const N = frame.length;
  const mags: number[] = [];
  for (let k = 1; k <= n; k++) {
    let re = 0;
    let im = 0;
    for (let i = 0; i < N; i++) {
      const ang = (Math.PI * 2 * k * i) / N;
      re += frame[i]! * Math.cos(ang);
      im -= frame[i]! * Math.sin(ang);
    }
    mags.push(Math.hypot(re, im) / N);
  }
  const peak = Math.max(1e-9, ...mags);
  return mags.map((m) => m / peak);
}

export function fromHarmonics(mags: number[], size = WT_SIZE, phases?: number[]): Float32Array {
  const out = new Float32Array(size);
  for (let i = 0; i < size; i++) {
    let s = 0;
    for (let k = 0; k < mags.length; k++) {
      const ph = phases?.[k] ?? 0;
      s += mags[k]! * Math.sin((Math.PI * 2 * (k + 1) * i) / size + ph);
    }
    out[i] = s;
  }
  normalize(out, 0, size);
  return out;
}

export function applyWaveOp(
  frame: Float32Array,
  op:
    | "normalize"
    | "smooth"
    | "invert"
    | "mirror"
    | "phase"
    | "randomize"
    | "silence"
    | "sine",
): Float32Array {
  const n = frame.length;
  const out = new Float32Array(n);
  if (op === "normalize") {
    out.set(frame);
    normalize(out, 0, n);
    return out;
  }
  if (op === "invert") {
    for (let i = 0; i < n; i++) out[i] = -frame[i]!;
    return out;
  }
  if (op === "mirror") {
    for (let i = 0; i < n; i++) out[i] = frame[n - 1 - i]!;
    return out;
  }
  if (op === "smooth") {
    for (let i = 0; i < n; i++) {
      const a = frame[(i - 1 + n) % n]!;
      const b = frame[i]!;
      const c = frame[(i + 1) % n]!;
      out[i] = (a + b * 2 + c) * 0.25;
    }
    return out;
  }
  if (op === "phase") {
    const shift = (n / 16) | 0;
    for (let i = 0; i < n; i++) out[i] = frame[(i + shift) % n]!;
    return out;
  }
  if (op === "randomize") {
    for (let i = 0; i < n; i++) out[i] = frame[i]! * 0.55 + (Math.random() * 2 - 1) * 0.45;
    normalize(out, 0, n);
    return out;
  }
  if (op === "silence") return out;
  for (let i = 0; i < n; i++) out[i] = Math.sin((Math.PI * 2 * i) / n);
  return out;
}

export function interpolateFrames(a: Float32Array, b: Float32Array, t: number) {
  const n = a.length;
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = a[i]! + (b[i]! - a[i]!) * t;
  return out;
}

export function audioToWavetable(samples: Float32Array, frames = WT_FRAMES, size = WT_SIZE): WaveTable {
  const data = new Float32Array(frames * size);
  const chunk = Math.max(1, Math.floor(samples.length / frames));
  for (let f = 0; f < frames; f++) {
    const srcOff = Math.min(samples.length - 2, f * chunk);
    const off = f * size;
    for (let i = 0; i < size; i++) {
      const x = srcOff + (i / size) * chunk;
      const i0 = Math.min(samples.length - 1, x | 0);
      const i1 = Math.min(samples.length - 1, i0 + 1);
      const frac = x - i0;
      data[off + i] = samples[i0]! + (samples[i1]! - samples[i0]!) * frac;
    }
    normalize(data, off, size);
  }
  return { name: "Imported", frames, size, data };
}
