import type { EngineMessage, Patch, VizFrame } from "./types";
import { generateFactoryTables } from "./wavetables";

export class SynthEngine {
  ctx: AudioContext | null = null;
  node: AudioWorkletNode | null = null;
  analyser: AnalyserNode | null = null;
  master: GainNode | null = null;
  ready = false;
  onViz: ((v: VizFrame) => void) | null = null;
  private started = false;

  async engage(): Promise<void> {
    if (this.started && this.ctx) {
      if (this.ctx.state === "suspended") await this.ctx.resume();
      return;
    }
    const ctx = new AudioContext({ latencyHint: "interactive" });
    this.ctx = ctx;
    if (ctx.state === "suspended") await ctx.resume();
    await ctx.audioWorklet.addModule("/worklets/hypercore-processor.js");
    const node = new AudioWorkletNode(ctx, "salek-hypercore", {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
    });
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    analyser.smoothingTimeConstant = 0.65;
    const master = ctx.createGain();
    master.gain.value = 1;
    node.connect(analyser);
    analyser.connect(master);
    master.connect(ctx.destination);
    this.node = node;
    this.analyser = analyser;
    this.master = master;
    node.port.onmessage = (e: MessageEvent) => {
      const d = e.data;
      if (d && d.type === "viz" && this.onViz) this.onViz(d as VizFrame);
    };
    const tables = generateFactoryTables();
    const buffers = tables.map((t) => t.data.slice().buffer);
    node.port.postMessage({ type: "tables", tables: buffers });
    this.started = true;
    this.ready = true;

    const resume = () => {
      if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
    };
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") resume();
    });
  }

  send(msg: EngineMessage) {
    this.node?.port.postMessage(msg);
  }

  loadPatch(patch: Patch) {
    this.send({ type: "patch", patch });
  }

  set(path: string, value: number | boolean | string | number[]) {
    this.send({ type: "set", path, value });
  }

  noteOn(note: number, velocity = 0.85) {
    this.send({ type: "noteOn", note, velocity });
  }

  noteOff(note: number) {
    this.send({ type: "noteOff", note });
  }

  panic() {
    this.send({ type: "panic" });
  }

  setBpm(value: number) {
    this.send({ type: "bpm", value });
  }
}

export const engine = new SynthEngine();
