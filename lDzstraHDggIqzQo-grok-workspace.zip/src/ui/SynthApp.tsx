import { useEffect } from "react";
import { PAGES, type PageId } from "@/engine/constants";
import { generateFactoryTables } from "@/engine/wavetables";
import { useSynth } from "@/store/synth-store";
import { AuxOscPanel, OscPanel } from "./OscPanel";
import { FilterPanel } from "./FilterPanel";
import { Visualizer } from "./Visualizer";
import { Keyboard } from "./Keyboard";
import { MacroBar } from "./MacroBar";
import { ModPanel } from "./ModPanel";
import { MatrixPanel } from "./MatrixPanel";
import { FxPanel } from "./FxPanel";
import { SeqPanel } from "./SeqPanel";
import { WavetableEditor } from "./WavetableEditor";
import { GlobalPanel } from "./GlobalPanel";
import { PresetBrowser } from "./PresetBrowser";
import { ModContextMenu } from "./ContextMenu";
import { Knob } from "./Knob";

function EngageGate() {
  const engaged = useSynth((s) => s.engaged);
  const engage = useSynth((s) => s.engage);
  if (engaged) return null;
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-void/92 p-6">
      <button
        type="button"
        onClick={() => void engage()}
        className="panel max-w-md px-8 py-8 text-left"
      >
        <p className="font-display text-[11px] tracking-[0.28em] text-acid uppercase">SALEK</p>
        <h1 className="mt-1 font-display text-4xl font-semibold tracking-[0.08em] text-fg">HYPERCORE</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Polyphonic wavetable instrument. Arm the engine, then play the keyboard — every control is live DSP.
        </p>
        <p className="mt-5 inline-block rounded-sm bg-acid px-4 py-2 font-display text-[12px] tracking-[0.18em] text-void uppercase">
          Arm Engine
        </p>
      </button>
    </div>
  );
}

function SynthPage() {
  return (
    <div className="grid min-h-0 gap-2">
      <Visualizer />
      <div className="grid min-h-0 grid-cols-1 gap-2 lg:grid-cols-3">
        <OscPanel index={0} />
        <OscPanel index={1} />
        <OscPanel index={2} />
      </div>
      <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
        <FilterPanel index={0} />
        <FilterPanel index={1} />
        <AuxOscPanel />
      </div>
    </div>
  );
}

export function SynthApp() {
  const page = useSynth((s) => s.page);
  const patch = useSynth((s) => s.patch);
  const octave = useSynth((s) => s.octave);
  const voices = useSynth((s) => s.viz.voices);
  const setPage = useSynth((s) => s.setPage);

  useEffect(() => {
    const close = () => useSynth.getState().setContext(null);
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, []);

  useEffect(() => {
    if (useSynth.getState().tables.length === 0) {
      const tables = generateFactoryTables();
      useSynth.setState({ tables, userTable: tables[15]! });
    }
  }, []);

  return (
    <div className="flex h-dvh min-h-0 flex-col bg-void text-fg">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-line bg-graphite px-2 py-1.5">
        <div className="flex items-baseline gap-2 pr-2">
          <span className="font-display text-[11px] tracking-[0.28em] text-acid uppercase">SALEK</span>
          <span className="font-display text-[16px] font-semibold tracking-[0.12em]">HYPERCORE</span>
        </div>
        <nav className="flex min-w-0 flex-1 gap-0.5 overflow-x-auto">
          {PAGES.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPage(p as PageId)}
              className={`rounded-sm px-2 py-1 font-display text-[11px] tracking-[0.14em] uppercase ${
                page === p ? "bg-acid text-void" : "text-muted hover:text-fg"
              }`}
            >
              {p}
            </button>
          ))}
        </nav>
        <button
          type="button"
          onClick={() => useSynth.setState({ browserOpen: true })}
          className="max-w-48 truncate rounded-sm border border-line bg-inset px-2 py-1 font-display text-[12px] tracking-wide"
          title="Open preset browser"
        >
          {patch.name}
        </button>
        <span className="hidden font-mono text-[10px] text-faint sm:inline">
          {patch.bpm | 0} BPM · {voices} V · OCT {octave}
        </span>
        <div className="hidden sm:block">
          <Knob path="voice.gain" label="OUT" size={36} />
        </div>
      </header>
      <div className="shrink-0 px-2 pt-2">
        <MacroBar />
      </div>
      <main className="min-h-0 flex-1 overflow-auto px-2 py-2">
        {page === "SYNTH" ? <SynthPage /> : null}
        {page === "WAVETABLE" ? <WavetableEditor /> : null}
        {page === "MOD" ? <ModPanel /> : null}
        {page === "MATRIX" ? <MatrixPanel /> : null}
        {page === "FX" ? <FxPanel /> : null}
        {page === "SEQ" ? <SeqPanel /> : null}
        {page === "GLOBAL" ? <GlobalPanel /> : null}
      </main>
      <div className="shrink-0 px-2 pb-2">
        <Keyboard />
      </div>
      <EngageGate />
      <PresetBrowser />
      <ModContextMenu />
    </div>
  );
}
