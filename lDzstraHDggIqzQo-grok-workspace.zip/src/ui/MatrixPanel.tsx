import { MOD_SOURCES } from "@/engine/constants";
import { DESTINATIONS, destLabel } from "@/engine/destinations";
import { useSynth } from "@/store/synth-store";
import { Knob } from "./Knob";

export function MatrixPanel() {
  const matrix = useSynth((s) => s.patch.matrix);
  const setParam = useSynth((s) => s.setParam);
  const used = matrix.filter((s) => s.on).length;
  return (
    <section className="panel flex min-h-0 flex-col">
      <div className="panel-head">
        <span>Modulation Matrix</span>
        <span className="font-mono text-[10px] text-acid">{used} / 64</span>
      </div>
      <div className="min-h-0 flex-1 overflow-auto">
        <table className="w-full text-left font-mono text-[10px]">
          <thead className="sticky top-0 bg-panel font-display text-[10px] tracking-[0.12em] text-muted uppercase">
            <tr>
              <th className="px-2 py-1">#</th>
              <th className="px-2 py-1">On</th>
              <th className="px-2 py-1">Source</th>
              <th className="px-2 py-1">Destination</th>
              <th className="px-2 py-1">Amt</th>
              <th className="px-2 py-1">Curve</th>
              <th className="px-2 py-1">Pol</th>
              <th className="px-2 py-1">Inv</th>
              <th className="px-2 py-1">Aux</th>
            </tr>
          </thead>
          <tbody>
            {matrix.map((s, i) => (
              <tr key={i} className="border-t border-line/60 hover:bg-raised/60">
                <td className="px-2 py-1 text-faint">{String(i + 1).padStart(2, "0")}</td>
                <td className="px-2 py-1">
                  <input
                    type="checkbox"
                    checked={s.on}
                    onChange={(e) => setParam(`matrix.${i}.on`, e.target.checked)}
                  />
                </td>
                <td className="px-2 py-1">
                  <select
                    className="h-6 w-28 rounded-sm border border-line bg-inset"
                    value={s.source}
                    onChange={(e) => setParam(`matrix.${i}.source`, Number(e.target.value))}
                  >
                    {MOD_SOURCES.map((n, k) => (
                      <option key={n} value={k}>
                        {n}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="px-2 py-1">
                  <select
                    className="h-6 w-40 rounded-sm border border-line bg-inset"
                    value={s.dest}
                    onChange={(e) => setParam(`matrix.${i}.dest`, e.target.value)}
                  >
                    <option value="">—</option>
                    {DESTINATIONS.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.label}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="px-2 py-1">
                  <input
                    type="range"
                    min={-1}
                    max={1}
                    step={0.01}
                    value={s.amount}
                    onChange={(e) => setParam(`matrix.${i}.amount`, Number(e.target.value))}
                  />
                </td>
                <td className="px-2 py-1">
                  <input
                    type="range"
                    min={-1}
                    max={1}
                    step={0.01}
                    value={s.curve}
                    onChange={(e) => setParam(`matrix.${i}.curve`, Number(e.target.value))}
                  />
                </td>
                <td className="px-2 py-1">
                  <button
                    type="button"
                    className="text-cyan"
                    onClick={() => setParam(`matrix.${i}.bipolar`, !s.bipolar)}
                  >
                    {s.bipolar ? "BIP" : "UNI"}
                  </button>
                </td>
                <td className="px-2 py-1">
                  <input
                    type="checkbox"
                    checked={s.invert}
                    onChange={(e) => setParam(`matrix.${i}.invert`, e.target.checked)}
                  />
                </td>
                <td className="px-2 py-1">
                  <select
                    className="h-6 w-24 rounded-sm border border-line bg-inset"
                    value={s.aux}
                    onChange={(e) => setParam(`matrix.${i}.aux`, Number(e.target.value))}
                  >
                    {MOD_SOURCES.map((n, k) => (
                      <option key={n} value={k}>
                        {n}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="border-t border-line p-2">
        <p className="font-display text-[10px] tracking-wide text-muted">
          Drag LFO / ENV chips onto knobs, or assign here. Remap curve warps the source before the destination.
          {destLabel("filt.0.cutoff")} is a common Hi-Tech target.
        </p>
        <div className="mt-1 flex flex-wrap gap-2">
          <Knob path="macros.0.value" label="M1" size={36} />
          <Knob path="macros.1.value" label="M2" size={36} />
          <Knob path="macros.2.value" label="M3" size={36} />
        </div>
      </div>
    </section>
  );
}
