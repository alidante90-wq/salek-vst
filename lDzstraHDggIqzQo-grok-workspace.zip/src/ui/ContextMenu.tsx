import { MOD_SOURCES } from "@/engine/constants";
import { destLabel } from "@/engine/destinations";
import { useSynth } from "@/store/synth-store";

export function ModContextMenu() {
  const menu = useSynth((s) => s.contextMenu);
  const modsFor = useSynth((s) => s.modsFor);
  const removeMod = useSynth((s) => s.removeMod);
  const setParam = useSynth((s) => s.setParam);
  const setContext = useSynth((s) => s.setContext);
  if (!menu) return null;
  const mods = modsFor(menu.dest);
  return (
    <div
      className="fixed z-50 min-w-44 rounded-md border border-line bg-panel p-1 shadow-panel"
      style={{ left: menu.x, top: menu.y }}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="px-2 py-1 font-display text-[10px] tracking-wide text-muted uppercase">
        {destLabel(menu.dest)}
      </div>
      {mods.length === 0 ? (
        <div className="px-2 py-1 text-[11px] text-faint">No modulation</div>
      ) : (
        mods.map((m) => (
          <div key={m.slot} className="flex items-center gap-2 px-2 py-1">
            <span className="flex-1 font-display text-[11px]">{MOD_SOURCES[m.source]}</span>
            <input
              type="range"
              min={-1}
              max={1}
              step={0.01}
              value={m.amount}
              onChange={(e) => setParam(`matrix.${m.slot}.amount`, Number(e.target.value))}
            />
            <button
              type="button"
              className="text-[10px] text-danger"
              onClick={() => {
                removeMod(menu.dest, m.source);
                setContext(null);
              }}
            >
              Remove
            </button>
          </div>
        ))
      )}
      <button
        type="button"
        className="block w-full px-2 py-1 text-left font-display text-[10px] uppercase text-muted"
        onClick={() => setContext(null)}
      >
        Close
      </button>
    </div>
  );
}
