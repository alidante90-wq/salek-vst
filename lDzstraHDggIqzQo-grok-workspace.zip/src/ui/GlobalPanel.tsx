import { VOICE_MODES } from "@/engine/constants";
import { engine } from "@/engine/host";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam, Toggle } from "./Knob";

export function GlobalPanel() {
  const patch = useSynth((s) => s.patch);
  const saveUserPreset = useSynth((s) => s.saveUserPreset);
  const initPatch = useSynth((s) => s.initPatch);
  const panic = useSynth((s) => s.panic);
  const exportPatch = () => {
    const blob = new Blob([JSON.stringify(patch, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${patch.name.replace(/\s+/g, "-")}.salek.json`;
    a.click();
  };
  const importPatch = async (file: File) => {
    const text = await file.text();
    const p = JSON.parse(text);
    useSynth.getState().loadPatch(p);
  };
  return (
    <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
      <section className="panel">
        <div className="panel-head">
          <span>Voice</span>
        </div>
        <div className="flex flex-wrap items-center gap-3 p-3">
          <SelectParam path="voice.mode" options={VOICE_MODES} />
          <Knob path="voice.voices" label="Voices" min={1} max={12} step={1} format={(v) => String(v | 0)} />
          <Knob path="voice.glide" label="Glide" />
          <Knob path="voice.bend" label="Bend" min={0} max={24} step={1} format={(v) => String(v | 0)} />
          <Knob path="voice.velAmp" label="Vel>Amp" />
          <Knob path="voice.gain" label="Master" />
          <Knob path="voice.pan" label="Pan" min={-1} max={1} bipolar />
          <Toggle path="voice.retrigger" label="Retrig" />
          <Knob path="bpm" label="BPM" min={60} max={220} step={1} format={(v) => String(v | 0)} />
        </div>
      </section>
      <section className="panel">
        <div className="panel-head">
          <span>Library / MIDI / State</span>
        </div>
        <div className="flex flex-col gap-2 p-3">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="rounded-sm border border-line px-3 py-1.5 font-display text-[11px] uppercase"
              onClick={initPatch}
            >
              Init
            </button>
            <button
              type="button"
              className="rounded-sm border border-line px-3 py-1.5 font-display text-[11px] uppercase"
              onClick={() => saveUserPreset(patch.name)}
            >
              Save
            </button>
            <button
              type="button"
              className="rounded-sm border border-line px-3 py-1.5 font-display text-[11px] uppercase"
              onClick={exportPatch}
            >
              Export JSON
            </button>
            <label className="rounded-sm border border-line px-3 py-1.5 font-display text-[11px] uppercase">
              Import
              <input
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void importPatch(f);
                }}
              />
            </label>
            <button
              type="button"
              className="rounded-sm border border-danger px-3 py-1.5 font-display text-[11px] text-danger uppercase"
              onClick={panic}
            >
              Panic
            </button>
            <button
              type="button"
              className="rounded-sm border border-line px-3 py-1.5 font-display text-[11px] uppercase"
              onClick={async () => {
                const nav = navigator as Navigator & {
                  requestMIDIAccess?: () => Promise<{
                    inputs: { values: () => Iterable<{ onmidimessage: ((ev: { data?: Uint8Array }) => void) | null }> };
                  }>;
                };
                if (!nav.requestMIDIAccess) return;
                const midi = await nav.requestMIDIAccess();
                for (const input of midi.inputs.values()) {
                  input.onmidimessage = (ev) => {
                    const d = ev.data;
                    if (!d || d.length < 1) return;
                    const st = d[0]! & 0xf0;
                    if (st === 0x90 && (d[2] ?? 0) > 0) engine.noteOn(d[1]!, d[2]! / 127);
                    else if (st === 0x80 || (st === 0x90 && (d[2] ?? 0) === 0)) engine.noteOff(d[1]!);
                    else if (st === 0xb0) engine.send({ type: "cc", cc: d[1]!, value: (d[2] ?? 0) / 127 });
                    else if (st === 0xe0) {
                      const v = ((d[2]! << 7) | (d[1] ?? 0)) / 8192 - 1;
                      engine.send({ type: "bend", value: v });
                    } else if (st === 0xd0) engine.send({ type: "at", value: (d[1] ?? 0) / 127 });
                  };
                }
                useSynth.setState({ midiEnabled: true });
              }}
            >
              Enable MIDI
            </button>
          </div>
          <p className="font-display text-[12px] leading-relaxed text-muted">
            SALEK HYPERCORE is a polyphonic wavetable instrument. This session is the live engine: every knob writes
            into the audio worklet. The companion JUCE VST3 sources in the project compile the same voice architecture
            for DAWs.
          </p>
          <p className="font-mono text-[10px] text-faint">
            Computer keys A–L play notes · [ ] octave · drag LFO/ENV chips onto knobs
          </p>
        </div>
      </section>
    </div>
  );
}
