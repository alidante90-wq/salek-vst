import { FILTER_TYPES } from "@/engine/constants";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam, Toggle } from "./Knob";

export function FilterPanel({ index }: { index: number }) {
  const route = useSynth((s) => s.patch.filtRoute);
  const setParam = useSynth((s) => s.setParam);
  return (
    <section className="panel">
      <div className="panel-head">
        <span>Filter {index + 1}</span>
        <div className="flex items-center gap-1">
          {index === 0 ? (
            <div className="seg">
              <button type="button" data-on={route === 0} onClick={() => setParam("filtRoute", 0)}>
                Series
              </button>
              <button type="button" data-on={route === 1} onClick={() => setParam("filtRoute", 1)}>
                Parallel
              </button>
            </div>
          ) : null}
          <Toggle path={`filt.${index}.on`} label="On" />
        </div>
      </div>
      <div className="flex flex-col gap-2 p-2">
        <SelectParam path={`filt.${index}.type`} options={FILTER_TYPES} />
        <div className="flex flex-wrap justify-center gap-1">
          <Knob path={`filt.${index}.cutoff`} label="Cutoff" defaultValue={0.7} format={(v) => {
            const hz = 20 * Math.pow(900, v);
            return hz >= 1000 ? `${(hz / 1000).toFixed(1)}k` : `${hz | 0}`;
          }} />
          <Knob path={`filt.${index}.res`} label="Res" defaultValue={0.18} />
          <Knob path={`filt.${index}.drive`} label="Drive" defaultValue={0.08} />
          <Knob path={`filt.${index}.mix`} label="Mix" defaultValue={1} />
          <Knob path={`filt.${index}.keytrack`} label="Key" defaultValue={0.35} />
          <Knob path={`filt.${index}.envAmt`} label="Env" min={-1} max={1} bipolar defaultValue={0} />
        </div>
      </div>
    </section>
  );
}
