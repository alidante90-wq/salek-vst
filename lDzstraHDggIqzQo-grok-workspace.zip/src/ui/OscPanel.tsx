import {
  ANALOG_WAVES,
  OSC_MODES,
  WARP_TYPES,
  WAVETABLE_NAMES,
} from "@/engine/constants";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam, Toggle } from "./Knob";
import { WaveMini } from "./WaveMini";

const FM_SRC = ["AUTO", "OSC A", "OSC B", "OSC C", "MOD OSC", "NOISE"];

export function OscPanel({ index }: { index: number }) {
  const osc = useSynth((s) => s.patch.osc[index]!);
  const setParam = useSynth((s) => s.setParam);
  const name = ["A", "B", "C"][index];
  const selected = useSynth((s) => s.selectedOsc === index);
  return (
    <section className={`panel flex min-w-0 flex-col ${selected ? "border-acid/40" : ""}`}>
      <div className="panel-head">
        <button
          type="button"
          className="font-display text-[12px] tracking-[0.16em] text-fg"
          onClick={() => useSynth.setState({ selectedOsc: index })}
        >
          OSC {name}
        </button>
        <div className="flex items-center gap-1">
          <Toggle path={`osc.${index}.on`} label="On" />
        </div>
      </div>
      <div className="flex flex-col gap-2 p-2">
        <WaveMini osc={index} />
        <div className="grid grid-cols-2 gap-1">
          <SelectParam path={`osc.${index}.mode`} options={OSC_MODES} />
          <SelectParam path={`osc.${index}.table`} options={WAVETABLE_NAMES} />
        </div>
        <div className="flex flex-wrap justify-center gap-1">
          <Knob path={`osc.${index}.wtPos`} label="WT" defaultValue={0} />
          <Knob path={`osc.${index}.level`} label="Level" defaultValue={0.7} />
          <Knob path={`osc.${index}.pan`} label="Pan" min={-1} max={1} bipolar defaultValue={0} />
          <Knob path={`osc.${index}.unison`} label="Uni" min={1} max={7} step={1} format={(v) => String(v | 0)} defaultValue={1} />
          <Knob path={`osc.${index}.detune`} label="Detune" defaultValue={0.12} />
          <Knob path={`osc.${index}.spread`} label="Spread" defaultValue={0.7} />
        </div>
        <div className="flex flex-wrap justify-center gap-1">
          <Knob path={`osc.${index}.octave`} label="Oct" min={-3} max={3} step={1} format={(v) => String(v | 0)} defaultValue={0} />
          <Knob path={`osc.${index}.semi`} label="Semi" min={-12} max={12} step={1} format={(v) => String(v | 0)} defaultValue={0} />
          <Knob path={`osc.${index}.fine`} label="Fine" min={-100} max={100} format={(v) => `${v | 0}`} defaultValue={0} />
          <Knob path={`osc.${index}.phase`} label="Phase" defaultValue={0} />
        </div>
        <details className="rounded-sm border border-line bg-inset/40 p-1.5">
          <summary className="cursor-pointer font-display text-[10px] tracking-[0.14em] text-muted uppercase">
            Warp / FM
          </summary>
          <div className="mt-2 grid grid-cols-3 gap-1">
            {[0, 1, 2].map((w) => (
              <div key={w} className="flex flex-col items-center gap-1">
                <SelectParam path={`osc.${index}.warp.${w}.type`} options={WARP_TYPES} className="h-6 w-full rounded-sm border border-line bg-inset px-1 font-display text-[9px] text-fg" />
                <Knob path={`osc.${index}.warp.${w}.amount`} label={`W${w + 1}`} size={40} defaultValue={0} />
              </div>
            ))}
          </div>
          <div className="mt-2 flex flex-wrap items-end justify-center gap-2">
            <label className="flex flex-col gap-1">
              <span className="knob-label">FM Src</span>
              <select
                className="h-6 rounded-sm border border-line bg-inset px-1 font-display text-[10px]"
                value={osc.fmSrc + 1}
                onChange={(e) => setParam(`osc.${index}.fmSrc`, Number(e.target.value) - 1)}
              >
                {FM_SRC.map((n, i) => (
                  <option key={n} value={i}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <Knob path={`osc.${index}.fmAmt`} label="FM" defaultValue={0} />
            <Knob path={`osc.${index}.fmRatio`} label="Ratio" min={0.25} max={8} defaultValue={1} format={(v) => v.toFixed(2)} />
            <Knob path={`osc.${index}.fmFeedback`} label="FB" defaultValue={0} />
            <Knob path={`osc.${index}.amAmt`} label="AM" defaultValue={0} />
            <Knob path={`osc.${index}.rmAmt`} label="RM" defaultValue={0} />
            <Knob path={`osc.${index}.pmAmt`} label="PM" defaultValue={0} />
          </div>
          {osc.mode === 1 || osc.mode === 2 ? (
            <div className="mt-2 flex justify-center gap-2">
              <SelectParam path={`osc.${index}.analogWave`} options={ANALOG_WAVES} />
              <Knob path={`osc.${index}.pwm`} label="PWM" defaultValue={0.5} />
            </div>
          ) : null}
          {osc.mode === 4 ? (
            <div className="mt-2 flex justify-center gap-1">
              <Knob path={`osc.${index}.grainSize`} label="Grain" />
              <Knob path={`osc.${index}.grainSpray`} label="Spray" />
              <Knob path={`osc.${index}.grainDensity`} label="Dense" />
            </div>
          ) : null}
          {osc.mode === 5 || osc.mode === 7 ? (
            <div className="mt-2 flex justify-center gap-1">
              <Knob path={`osc.${index}.spectralBright`} label="Bright" />
              <Knob path={`osc.${index}.additivePartials`} label="Partials" />
            </div>
          ) : null}
        </details>
      </div>
    </section>
  );
}

export function AuxOscPanel() {
  return (
    <section className="panel">
      <div className="panel-head">
        <span>Sub / Noise / Mod</span>
      </div>
      <div className="flex flex-wrap items-start justify-around gap-2 p-2">
        <div className="flex flex-col items-center gap-1">
          <Toggle path="sub.on" label="Sub" />
          <Knob path="sub.level" label="Level" size={40} />
          <Knob path="sub.octave" label="Oct" min={-2} max={0} step={1} size={40} format={(v) => String(v | 0)} />
        </div>
        <div className="flex flex-col items-center gap-1">
          <Toggle path="noise.on" label="Noise" />
          <Knob path="noise.level" label="Level" size={40} />
          <SelectParam path="noise.type" options={["WHITE", "PINK", "BROWN"]} />
        </div>
        <div className="flex flex-col items-center gap-1">
          <Toggle path="modOsc.on" label="Mod OSC" />
          <Knob path="modOsc.ratio" label="Ratio" min={0.25} max={12} size={40} format={(v) => v.toFixed(2)} />
          <Knob path="modOsc.level" label="Level" size={40} />
        </div>
      </div>
    </section>
  );
}
