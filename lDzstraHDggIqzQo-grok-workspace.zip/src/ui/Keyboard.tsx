import { useEffect } from "react";
import { useSynth } from "@/store/synth-store";

const WHITE = [0, 2, 4, 5, 7, 9, 11];
const KEYMAP: Record<string, number> = {
  a: 0, w: 1, s: 2, e: 3, d: 4, f: 5, t: 6, g: 7, y: 8, h: 9, u: 10, j: 11, k: 12,
  o: 13, l: 14, p: 15, ";": 16, "'": 17,
  z: 0, x: 2, c: 4, v: 5, b: 7, n: 9, m: 11, ",": 12, ".": 14, "/": 16,
  q: 12, "2": 13, "3": 15, r: 17, "5": 18, "6": 20, "7": 22, i: 24,
};

export function Keyboard() {
  const octave = useSynth((s) => s.octave);
  const held = useSynth((s) => s.heldNotes);
  const noteOn = useSynth((s) => s.noteOn);
  const noteOff = useSynth((s) => s.noteOff);
  const engaged = useSynth((s) => s.engaged);
  const start = 36 + octave * 12;
  const whites: number[] = [];
  for (let n = start; n < start + 29; n++) if (WHITE.includes(n % 12)) whites.push(n);

  useEffect(() => {
    if (!engaged) return;
    const down = new Set<string>();
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "SELECT" || t.tagName === "TEXTAREA")) return;
      if (e.repeat) return;
      if (e.key === "[") {
        useSynth.setState({ octave: Math.max(-2, useSynth.getState().octave - 1) });
        return;
      }
      if (e.key === "]") {
        useSynth.setState({ octave: Math.min(3, useSynth.getState().octave + 1) });
        return;
      }
      const off = KEYMAP[e.key.toLowerCase()];
      if (off == null) return;
      e.preventDefault();
      const note = 48 + useSynth.getState().octave * 12 + off;
      if (down.has(e.key)) return;
      down.add(e.key);
      noteOn(note, 0.9);
    };
    const onUp = (e: KeyboardEvent) => {
      const off = KEYMAP[e.key.toLowerCase()];
      if (off == null) return;
      down.delete(e.key);
      noteOff(48 + useSynth.getState().octave * 12 + off);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onUp);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onUp);
    };
  }, [engaged, noteOn, noteOff]);

  return (
    <div className="panel overflow-hidden">
      <div className="flex h-[88px] md:h-[104px]">
        {whites.map((n) => {
          const black = n % 12 !== 4 && n % 12 !== 11 ? n + 1 : null;
          const on = held.includes(n);
          return (
            <div key={n} className="relative min-w-0 flex-1">
              <button
                type="button"
                data-on={on}
                className="key-white absolute inset-0 rounded-b-sm"
                onPointerDown={(e) => {
                  (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
                  noteOn(n, 0.9);
                }}
                onPointerUp={() => noteOff(n)}
                onPointerCancel={() => noteOff(n)}
              />
              {black && black < start + 29 ? (
                <button
                  type="button"
                  data-on={held.includes(black)}
                  className="key-black absolute top-0 z-10 h-[58%] w-[64%] rounded-b-sm"
                  style={{ left: "68%" }}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
                    noteOn(black, 0.9);
                  }}
                  onPointerUp={() => noteOff(black)}
                  onPointerCancel={() => noteOff(black)}
                />
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
