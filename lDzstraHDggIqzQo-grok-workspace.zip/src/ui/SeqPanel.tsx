import { ARP_MODES, SYNC_DIVS } from "@/engine/constants";
import { applyEuclid } from "@/engine/patch";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam, Toggle } from "./Knob";

const NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

export function SeqPanel() {
  const seq = useSynth((s) => s.patch.seq);
  const setParam = useSynth((s) => s.setParam);
  const steps = Math.max(1, seq.steps | 0);
  const fillEuclid = () => {
    const pat = applyEuclid(64, seq.euclidHits, seq.euclidLen);
    for (let i = 0; i < 64; i++) {
      setParam(`seq.gates.${i}`, pat[i] ? 0.7 : 0);
      if (pat[i] && seq.notes[i] === 0) setParam(`seq.notes.${i}`, 0);
    }
  };
  return (
    <div className="grid min-h-0 grid-cols-1 gap-2 xl:grid-cols-3">
      <section className="panel xl:col-span-2">
        <div className="panel-head">
          <span>Sequencer</span>
          <div className="flex items-center gap-2">
            <Toggle path="seq.on" label="Run" />
            <button
              type="button"
              className="rounded-sm border border-line px-2 py-0.5 font-display text-[10px] uppercase"
              onClick={fillEuclid}
            >
              Euclid
            </button>
          </div>
        </div>
        <div className="p-2">
          <div className="mb-2 flex flex-wrap justify-center gap-1">
            <Knob path="seq.steps" label="Steps" min={1} max={64} step={1} size={40} format={(v) => String(v | 0)} />
            <SelectParam path="seq.division" options={SYNC_DIVS} />
            <Knob path="seq.swing" label="Swing" size={40} />
            <Knob path="seq.root" label="Root" min={24} max={72} step={1} size={40} format={(v) => `${NAMES[(v | 0) % 12]}${((v | 0) / 12 | 0) - 1}`} />
            <Knob path="seq.euclidHits" label="Hits" min={0} max={32} step={1} size={40} format={(v) => String(v | 0)} />
            <Knob path="seq.euclidLen" label="Len" min={1} max={32} step={1} size={40} format={(v) => String(v | 0)} />
          </div>
          <div className="grid grid-cols-8 gap-1 lg:grid-cols-8 xl:grid-cols-8" style={{ gridTemplateColumns: "repeat(8, minmax(0, 1fr))" }}>
            {Array.from({ length: Math.min(64, steps) }, (_, i) => {
              const on = (seq.gates[i] ?? 0) > 0.05;
              const note = seq.notes[i] ?? 0;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => setParam(`seq.gates.${i}`, on ? 0 : 0.75)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setParam(`seq.notes.${i}`, (note + 1) % 13);
                  }}
                  className="flex h-10 flex-col items-center justify-center rounded-sm border border-line font-mono text-[9px]"
                  style={{
                    background: on ? "var(--color-acid)" : "var(--color-inset)",
                    color: on ? "var(--color-void)" : "var(--color-muted)",
                  }}
                >
                  <span>{i + 1}</span>
                  <span>{on ? note : "·"}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-2 font-display text-[10px] text-faint">
            Click gate on/off. Right-click cycles interval. Velocity / ratchet / probability live on each step in the
            patch.
          </p>
        </div>
      </section>
      <section className="panel">
        <div className="panel-head">
          <span>Arpeggiator</span>
          <Toggle path="arp.on" label="Arp" />
        </div>
        <div className="flex flex-col gap-2 p-2">
          <SelectParam path="arp.mode" options={ARP_MODES} />
          <div className="flex flex-wrap justify-center gap-1">
            <Toggle path="arp.sync" label="Sync" />
            <SelectParam path="arp.syncDiv" options={SYNC_DIVS} />
            <Knob path="arp.rate" label="Rate" size={40} />
            <Knob path="arp.octaves" label="Oct" min={1} max={4} step={1} size={40} format={(v) => String(v | 0)} />
            <Knob path="arp.gate" label="Gate" size={40} />
            <Knob path="arp.swing" label="Swing" size={40} />
            <Knob path="arp.prob" label="Prob" size={40} />
            <Knob path="arp.ratchet" label="Ratch" min={1} max={4} step={1} size={40} />
          </div>
          <p className="font-display text-[10px] leading-snug text-muted">
            Hold a chord on the keyboard. ARP latches the held notes and plays the pattern at the engine clock — not a
            UI timer.
          </p>
        </div>
      </section>
    </div>
  );
}
