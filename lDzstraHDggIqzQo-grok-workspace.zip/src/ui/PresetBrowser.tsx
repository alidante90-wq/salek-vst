import { PRESET_CATEGORIES, PRESET_TAGS } from "@/engine/constants";
import { useSynth } from "@/store/synth-store";
import { Star } from "lucide-react";

export function PresetBrowser() {
  const open = useSynth((s) => s.browserOpen);
  const factory = useSynth((s) => s.factory);
  const user = useSynth((s) => s.userPresets);
  const query = useSynth((s) => s.query);
  const category = useSynth((s) => s.category);
  const favorites = useSynth((s) => s.favorites);
  const recents = useSynth((s) => s.recents);
  const loadPatch = useSynth((s) => s.loadPatch);
  const toggleFavorite = useSynth((s) => s.toggleFavorite);
  const saveUserPreset = useSynth((s) => s.saveUserPreset);
  const patch = useSynth((s) => s.patch);

  if (!open) return null;

  const all = [
    ...user.map((u) => u.patch),
    ...factory,
  ];
  const filtered = all.filter((p) => {
    if (category === "FAV") return favorites.includes(p.name);
    if (category === "RECENT") return recents.includes(p.name);
    if (category === "USER") return user.some((u) => u.name === p.name);
    if (category !== "ALL" && p.category !== category) return false;
    if (query) {
      const q = query.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q)) ||
        p.author.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="absolute inset-0 z-40 flex items-start justify-center bg-void/80 p-3 pt-16 md:p-8 md:pt-20">
      <div className="panel flex max-h-[80vh] w-full max-w-3xl flex-col">
        <div className="panel-head">
          <span>Preset Browser</span>
          <button
            type="button"
            className="font-display text-[11px] tracking-wide uppercase text-muted"
            onClick={() => useSynth.setState({ browserOpen: false })}
          >
            Close
          </button>
        </div>
        <div className="flex flex-wrap gap-2 border-b border-line p-2">
          <input
            value={query}
            onChange={(e) => useSynth.setState({ query: e.target.value })}
            placeholder="Search name, tag, author"
            className="h-8 min-w-40 flex-1 rounded-sm border border-line bg-inset px-2 text-sm"
          />
          <button
            type="button"
            className="h-8 rounded-sm border border-acid bg-acid px-3 font-display text-[11px] tracking-wide text-void uppercase"
            onClick={() => {
              const name = window.prompt("Preset name", patch.name);
              if (name) saveUserPreset(name);
            }}
          >
            Save
          </button>
        </div>
        <div className="flex min-h-0 flex-1">
          <div className="w-28 shrink-0 overflow-auto border-r border-line p-1 md:w-36">
            {["ALL", "FAV", "RECENT", "USER", ...PRESET_CATEGORIES].map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => useSynth.setState({ category: c })}
                className={`block w-full px-2 py-1 text-left font-display text-[10px] tracking-[0.12em] uppercase ${
                  category === c ? "text-acid" : "text-muted"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-auto p-1">
            {filtered.map((p) => (
              <button
                key={p.name + p.category}
                type="button"
                onClick={() => loadPatch(p)}
                className="flex w-full items-center gap-2 rounded-sm px-2 py-2 text-left hover:bg-raised"
              >
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(p.name);
                  }}
                  className={favorites.includes(p.name) ? "text-acid" : "text-faint"}
                >
                  <Star className="size-3.5" fill={favorites.includes(p.name) ? "currentColor" : "none"} />
                </span>
                <span className="flex-1 font-display text-[13px] tracking-wide">{p.name}</span>
                <span className="font-display text-[10px] text-muted">{p.category}</span>
                <span className="hidden font-mono text-[9px] text-faint md:inline">{p.tags.slice(0, 2).join(" ")}</span>
              </button>
            ))}
            {filtered.length === 0 ? (
              <p className="p-4 text-sm text-muted">No presets in this filter.</p>
            ) : null}
          </div>
        </div>
        <div className="flex flex-wrap gap-1 border-t border-line p-2">
          {PRESET_TAGS.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => useSynth.setState({ query: t })}
              className="rounded-sm border border-line px-1.5 py-0.5 font-display text-[9px] tracking-wide text-faint uppercase"
            >
              {t}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
