import { useSynth } from "@/store/synth-store";
import { ModSourceChip } from "./Knob";
import { clamp } from "@/lib/utils";

export function MacroBar() {
  const macros = useSynth((s) => s.patch.macros);
  const setParam = useSynth((s) => s.setParam);
  return (
    <div className="panel">
      <div className="flex gap-1 overflow-x-auto p-1.5">
        {macros.map((m, i) => (
          <div key={i} className="flex min-w-[92px] flex-1 items-center gap-1 rounded-md border border-line bg-inset px-1.5 py-1">
            <ModSourceChip id={13 + i} label={`M${i + 1}`} />
            <div className="min-w-0 flex-1">
              <input
                value={m.name}
                onChange={(e) => setParam(`macros.${i}.name`, e.target.value)}
                className="w-full bg-transparent font-display text-[10px] tracking-[0.12em] text-muted uppercase outline-none"
              />
              <input
                type="range"
                min={0}
                max={1}
                step={0.001}
                value={m.value}
                onChange={(e) => setParam(`macros.${i}.value`, Number(e.target.value))}
                className="w-full accent-[var(--color-acid)]"
              />
            </div>
            <span className="w-8 font-mono text-[10px] text-acid">{clamp(m.value, 0, 1).toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
