import { useEffect, useRef, useState } from "react";
import { MOD_SOURCES } from "@/engine/constants";
import { destLabel } from "@/engine/destinations";
import { useSynth } from "@/store/synth-store";
import { clamp } from "@/lib/utils";
import { getPath } from "@/lib/utils";

const RING = [
  "var(--color-cyan)",
  "var(--color-magenta)",
  "var(--color-violet)",
  "var(--color-acid)",
  "var(--color-warn)",
];

function sourceColor(src: number) {
  if (src >= 1 && src <= 4) return "var(--color-magenta)";
  if (src >= 5 && src <= 12) return "var(--color-cyan)";
  if (src >= 13 && src <= 20) return "var(--color-acid)";
  return "var(--color-violet)";
}

export function Knob({
  path,
  label,
  min = 0,
  max = 1,
  step,
  size = 44,
  bipolar,
  format,
  defaultValue,
}: {
  path: string;
  label: string;
  min?: number;
  max?: number;
  step?: number;
  size?: number;
  bipolar?: boolean;
  format?: (v: number) => string;
  defaultValue?: number;
}) {
  const raw = useSynth((s) => getPath(s.patch, path));
  const value = typeof raw === "number" ? raw : Number(raw) || 0;
  const matrix = useSynth((s) => s.patch.matrix);
  const mods = matrix
    .map((s, slot) => ({ source: s.source, amount: s.amount, slot, on: s.on, dest: s.dest }))
    .filter((s) => s.on && s.dest === path);
  const draggingMod = useSynth((s) => s.draggingMod);
  const setParam = useSynth((s) => s.setParam);
  const assignMod = useSynth((s) => s.assignMod);
  const setContext = useSynth((s) => s.setContext);
  const viz = useSynth((s) => s.viz);
  const [hot, setHot] = useState(false);
  const start = useRef({ y: 0, v: 0 });

  const t = (value - min) / (max - min || 1);
  const angle = -135 + t * 270;

  let live = value;
  for (const m of mods) {
    const src =
      m.source >= 5 && m.source <= 12
        ? viz.lfo[m.source - 5] ?? 0
        : m.source >= 1 && m.source <= 4
          ? viz.env[m.source - 1] ?? 0
          : 0;
    live += src * m.amount * (max - min);
  }
  const liveT = clamp((live - min) / (max - min || 1), 0, 1);

  useEffect(() => {
    const up = () => setHot(false);
    window.addEventListener("pointerup", up);
    return () => window.removeEventListener("pointerup", up);
  }, []);

  const onDown = (e: React.PointerEvent) => {
    if (e.button === 2) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    start.current = { y: e.clientY, v: value };
    setHot(true);
  };
  const onMove = (e: React.PointerEvent) => {
    if (!hot) return;
    const fine = e.shiftKey ? 0.12 : 1;
    const dy = (start.current.y - e.clientY) * fine;
    const span = max - min;
    let next = start.current.v + (dy / 110) * span;
    next = clamp(next, min, max);
    if (step) next = Math.round(next / step) * step;
    setParam(path, next);
  };

  const text =
    format?.(value) ??
    (Math.abs(max) > 10 || Math.abs(min) > 10
      ? value.toFixed(0)
      : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, ""));

  return (
    <div
      className="flex flex-col items-center gap-0.5 select-none"
      onDragOver={(e) => {
        if (draggingMod != null) e.preventDefault();
      }}
      onDrop={(e) => {
        e.preventDefault();
        const src = draggingMod ?? Number(e.dataTransfer.getData("text/salek-mod"));
        if (src > 0) assignMod(src, path);
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        setContext({ x: e.clientX, y: e.clientY, dest: path });
      }}
      title={destLabel(path)}
    >
      <div
        className="relative"
        style={{ width: size, height: size }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onDoubleClick={() => defaultValue != null && setParam(path, defaultValue)}
      >
        <svg width={size} height={size} viewBox="0 0 48 48" className="block">
          <circle cx="24" cy="24" r="18" fill="var(--color-inset)" stroke="var(--color-line)" strokeWidth="1" />
          <circle
            cx="24"
            cy="24"
            r="16"
            fill="none"
            stroke="var(--color-line-strong)"
            strokeWidth="3"
            strokeDasharray="75.4"
            strokeDashoffset="0"
            strokeLinecap="butt"
            transform="rotate(135 24 24)"
          />
          <circle
            cx="24"
            cy="24"
            r="16"
            fill="none"
            stroke="var(--color-acid)"
            strokeWidth="3"
            strokeDasharray={`${liveT * 75.4} 75.4`}
            transform="rotate(135 24 24)"
            opacity="0.35"
          />
          <circle
            cx="24"
            cy="24"
            r="16"
            fill="none"
            stroke="var(--color-fg)"
            strokeWidth="2.2"
            strokeDasharray={`${t * 75.4} 75.4`}
            transform="rotate(135 24 24)"
          />
          {mods.map((m, i) => (
            <circle
              key={m.slot}
              cx="24"
              cy="24"
              r={20 + i}
              fill="none"
              stroke={sourceColor(m.source)}
              strokeWidth="1.4"
              opacity="0.9"
            />
          ))}
          {bipolar ? <line x1="24" y1="6" x2="24" y2="10" stroke="var(--color-faint)" strokeWidth="1" /> : null}
          <g transform={`rotate(${angle} 24 24)`}>
            <line x1="24" y1="24" x2="24" y2="10" stroke="var(--color-acid)" strokeWidth="2" strokeLinecap="round" />
          </g>
          <circle cx="24" cy="24" r="3.2" fill="var(--color-raised)" stroke="var(--color-line-strong)" />
        </svg>
        {draggingMod != null ? (
          <div className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-cyan/80" />
        ) : null}
      </div>
      <div className="knob-label max-w-16 truncate">{label}</div>
      <div className="readout">{text}</div>
    </div>
  );
}

export function Toggle({
  path,
  label,
}: {
  path: string;
  label: string;
}) {
  const raw = useSynth((s) => getPath(s.patch, path));
  const on = Boolean(raw);
  const setParam = useSynth((s) => s.setParam);
  return (
    <button
      type="button"
      data-on={on}
      onClick={() => setParam(path, !on)}
      className="rounded-sm border border-line px-2 py-0.5 font-display text-[10px] tracking-[0.12em] uppercase text-muted data-[on=true]:border-acid data-[on=true]:bg-acid data-[on=true]:text-void"
    >
      {label}
    </button>
  );
}

export function SelectParam({
  path,
  options,
  className,
}: {
  path: string;
  options: readonly string[];
  className?: string;
}) {
  const raw = useSynth((s) => getPath(s.patch, path));
  const value = typeof raw === "number" ? raw : Number(raw) || 0;
  const setParam = useSynth((s) => s.setParam);
  return (
    <select
      className={
        className ??
        "h-6 min-w-0 max-w-full rounded-sm border border-line bg-inset px-1 font-display text-[10px] tracking-wide text-fg"
      }
      value={value}
      onChange={(e) => setParam(path, Number(e.target.value))}
    >
      {options.map((o, i) => (
        <option key={o} value={i}>
          {o}
        </option>
      ))}
    </select>
  );
}

export function ModSourceChip({ id, label }: { id: number; label: string }) {
  const setDragging = useSynth((s) => s.setDragging);
  const color = sourceColor(id);
  return (
    <button
      type="button"
      draggable
      onDragStart={(e) => {
        setDragging(id);
        e.dataTransfer.setData("text/salek-mod", String(id));
        e.dataTransfer.effectAllowed = "copy";
      }}
      onDragEnd={() => setDragging(null)}
      className="rounded-sm border border-line bg-raised px-1.5 py-0.5 font-display text-[10px] tracking-[0.1em] text-fg"
      style={{ boxShadow: `inset 2px 0 0 ${color}` }}
      title={`Drag onto a control · ${MOD_SOURCES[id] ?? label}`}
    >
      {label}
    </button>
  );
}

export { sourceColor };
