import { useEffect, useRef } from "react";
import { frameSlice } from "@/engine/wavetables";
import { useSynth } from "@/store/synth-store";

export function WaveMini({ osc, height = 56 }: { osc: number; height?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const patch = useSynth((s) => s.patch.osc[osc]);
  const tables = useSynth((s) => s.tables);
  const wtPos = useSynth((s) => s.viz.wtPos[osc]);

  useEffect(() => {
    const c = ref.current;
    if (!c || !patch) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = (c.width = c.clientWidth * 2 || 400);
    const h = (c.height = height * 2);
    ctx.fillStyle = "#0c0e13";
    ctx.fillRect(0, 0, w, h);
    const table = tables[patch.table] ?? tables[0];
    if (!table) {
      ctx.fillStyle = "#0c0e13";
      ctx.fillRect(0, 0, w, h);
      return;
    }
    const frame = frameSlice(table, patch.wtPos);
    ctx.beginPath();
    ctx.strokeStyle = patch.on ? "#c6ff4a" : "#5c6678";
    ctx.lineWidth = 2;
    const n = frame.length;
    const step = Math.max(1, (n / w) | 0);
    for (let x = 0; x < w; x++) {
      const i = Math.min(n - 1, ((x / w) * n) | 0);
      const y = h / 2 - frame[i]! * h * 0.42;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    const px = (wtPos ?? patch.wtPos) * w;
    ctx.fillStyle = "#3ee0ff";
    ctx.fillRect(px, 0, 2, h);
  }, [patch, tables, wtPos, height, osc]);

  return <canvas ref={ref} className="w-full rounded-sm" style={{ height }} />;
}
