import { useEffect, useRef } from "react";
import { engine } from "@/engine/host";
import { useSynth } from "@/store/synth-store";
import { expScale } from "@/lib/utils";

export function Visualizer() {
  const waveRef = useRef<HTMLCanvasElement>(null);
  const specRef = useRef<HTMLCanvasElement>(null);
  const filtRef = useRef<HTMLCanvasElement>(null);
  const viz = useSynth((s) => s.viz);
  const patch = useSynth((s) => s.patch);

  useEffect(() => {
    const c = waveRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = (c.width = c.clientWidth * 2);
    const h = (c.height = c.clientHeight * 2);
    ctx.fillStyle = "#0c0e13";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "rgba(42,49,64,0.8)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();
    const data = viz.wave;
    if (!data.length) return;
    ctx.beginPath();
    ctx.strokeStyle = "#c6ff4a";
    ctx.lineWidth = 2;
    for (let i = 0; i < data.length; i++) {
      const x = (i / (data.length - 1)) * w;
      const y = h / 2 - data[i]! * h * 0.42;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }, [viz.wave]);

  useEffect(() => {
    const c = specRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const analyser = engine.analyser;
    const w = (c.width = c.clientWidth * 2);
    const h = (c.height = c.clientHeight * 2);
    ctx.fillStyle = "#0c0e13";
    ctx.fillRect(0, 0, w, h);
    let bins: number[] = viz.spec;
    if (analyser) {
      const arr = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(arr);
      bins = Array.from({ length: 96 }, (_, i) => {
        const t = i / 95;
        const idx = Math.pow(t, 1.6) * (arr.length - 1);
        return arr[idx | 0]! / 255;
      });
    }
    const bw = w / bins.length;
    for (let i = 0; i < bins.length; i++) {
      const v = bins[i]!;
      const bh = v * h * 0.92;
      ctx.fillStyle = v > 0.7 ? "#ff2bd6" : v > 0.4 ? "#3ee0ff" : "#c6ff4a";
      ctx.globalAlpha = 0.35 + v * 0.65;
      ctx.fillRect(i * bw + 1, h - bh, Math.max(1, bw - 2), bh);
    }
    ctx.globalAlpha = 1;
  }, [viz.spec, viz.peak]);

  useEffect(() => {
    const c = filtRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = (c.width = c.clientWidth * 2);
    const h = (c.height = c.clientHeight * 2);
    ctx.fillStyle = "#0c0e13";
    ctx.fillRect(0, 0, w, h);
    const draw = (cutoff: number, res: number, color: string, type: number) => {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      for (let i = 0; i < w; i++) {
        const freq = 20 * Math.pow(1000, i / w);
        const fc = expScale(cutoff, 20, 18000);
        const q = 0.5 + res * 8;
        const ratio = freq / fc;
        let mag = 1;
        if (type <= 2 || type === 12 || type === 13 || type === 14) {
          mag = 1 / Math.sqrt(1 + Math.pow(ratio, 4));
        } else if (type === 3 || type === 4) {
          mag = 1 / Math.sqrt(1 + Math.pow(1 / Math.max(ratio, 1e-6), 4));
        } else if (type === 5 || type === 8 || type === 9) {
          mag = 1 / Math.sqrt(1 + Math.pow((ratio - 1 / ratio) * q, 2));
        } else {
          mag = 1 / Math.sqrt(1 + Math.pow(ratio - 1, 2) * q);
        }
        mag *= 1 + res * 1.8 * Math.exp(-Math.pow((Math.log(freq) - Math.log(fc)) * 2.2, 2));
        const y = h - 8 - Math.min(1.4, mag) * (h - 16) * 0.7;
        if (i === 0) ctx.moveTo(i, y);
        else ctx.lineTo(i, y);
      }
      ctx.stroke();
    };
    if (patch.filt[0].on) draw(patch.filt[0].cutoff, patch.filt[0].res, "#3ee0ff", patch.filt[0].type);
    if (patch.filt[1].on) draw(patch.filt[1].cutoff, patch.filt[1].res, "#ff2bd6", patch.filt[1].type);
  }, [patch.filt, viz.cutoff]);

  const voices = useSynth((s) => s.viz.voices);
  const peak = viz.peak;

  return (
    <div className="panel overflow-hidden">
      <div className="panel-head">
        <span>Core View</span>
        <span className="font-mono text-[10px] text-acid">
          {voices} VCX · {Math.round(peak * 100)}%
        </span>
      </div>
      <div className="grid grid-cols-3 gap-px bg-line">
        <div className="bg-inset p-1">
          <div className="px-1 font-display text-[9px] tracking-[0.14em] text-faint uppercase">Wave</div>
          <canvas ref={waveRef} className="h-24 w-full md:h-28" />
        </div>
        <div className="bg-inset p-1">
          <div className="px-1 font-display text-[9px] tracking-[0.14em] text-faint uppercase">Spectrum</div>
          <canvas ref={specRef} className="h-24 w-full md:h-28" />
        </div>
        <div className="bg-inset p-1">
          <div className="px-1 font-display text-[9px] tracking-[0.14em] text-faint uppercase">Filter</div>
          <canvas ref={filtRef} className="h-24 w-full md:h-28" />
        </div>
      </div>
    </div>
  );
}
