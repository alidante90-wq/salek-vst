import { useMemo, useRef } from "react";
import { HARMONICS, WT_FRAMES, WT_SIZE } from "@/engine/constants";
import {
  applyWaveOp,
  audioToWavetable,
  fromHarmonics,
  harmonicsOf,
  interpolateFrames,
  type WaveTable,
} from "@/engine/wavetables";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam } from "./Knob";
import { WAVETABLE_NAMES } from "@/engine/constants";

function writeFrame(table: WaveTable, frame: number, data: Float32Array): WaveTable {
  const next = { ...table, data: table.data.slice() };
  next.data.set(data, frame * table.size);
  return next;
}

export function WavetableEditor() {
  const osc = useSynth((s) => s.selectedOsc);
  const patch = useSynth((s) => s.patch.osc[osc]!);
  const tables = useSynth((s) => s.tables);
  const editFrame = useSynth((s) => s.editFrame);
  const setUserTable = useSynth((s) => s.setUserTable);
  const setEditFrame = useSynth((s) => s.setEditFrame);
  const table = tables[patch.table] ?? tables[15] ?? tables[0];
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const specRef = useRef<HTMLCanvasElement>(null);
  const frame = useMemo(() => {
    if (!table) return new Float32Array(WT_SIZE);
    const out = new Float32Array(table.size);
    const off = Math.min(table.frames - 1, editFrame) * table.size;
    for (let i = 0; i < table.size; i++) out[i] = table.data[off + i]!;
    return out;
  }, [table, editFrame]);
  const harmonics = useMemo(() => harmonicsOf(frame, HARMONICS), [frame]);
  if (!table) {
    return (
      <section className="panel p-6 text-sm text-muted">Loading wavetables…</section>
    );
  }

  const commit = (data: Float32Array) => {
    const src = patch.table === 15 ? table : { ...table, name: "User", data: table.data.slice() };
    setUserTable(writeFrame(src, editFrame, data));
  };

  const drawWave = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const c = e.currentTarget;
    const r = c.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = 1 - (e.clientY - r.top) / r.height;
    const i = Math.max(0, Math.min(WT_SIZE - 1, (x * WT_SIZE) | 0));
    const v = y * 2 - 1;
    const next = frame.slice();
    next[i] = v;
    const span = 6;
    for (let k = 1; k < span; k++) {
      const a = (i + k) % WT_SIZE;
      const b = (i - k + WT_SIZE) % WT_SIZE;
      const fall = 1 - k / span;
      next[a] = next[a]! * (1 - fall * 0.4) + v * fall * 0.4;
      next[b] = next[b]! * (1 - fall * 0.4) + v * fall * 0.4;
    }
    commit(next);
  };

  const w = 640;
  const h = 180;
  const d = frame.reduce((acc, v, i) => {
    const x = (i / (frame.length - 1)) * w;
    const y = h / 2 - v * (h * 0.42);
    return acc + (i === 0 ? `M ${x} ${y}` : ` L ${x} ${y}`);
  }, "");

  const importWav = async (file: File) => {
    const buf = await file.arrayBuffer();
    const ctx = new AudioContext();
    const audio = await ctx.decodeAudioData(buf);
    const ch = audio.getChannelData(0);
    const wt = audioToWavetable(ch, WT_FRAMES, WT_SIZE);
    wt.name = file.name.replace(/\.[^.]+$/, "");
    setUserTable(wt);
    await ctx.close();
  };

  return (
    <div className="grid min-h-0 grid-cols-1 gap-2 lg:grid-cols-[1fr_220px]">
      <section className="panel">
        <div className="panel-head">
          <span>Wavetable Editor</span>
          <div className="flex items-center gap-2">
            <SelectParam path={`osc.${osc}.table`} options={WAVETABLE_NAMES} />
            <label className="rounded-sm border border-line px-2 py-0.5 font-display text-[10px] uppercase">
              Import WAV
              <input
                type="file"
                accept="audio/*,.wav"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void importWav(f);
                }}
              />
            </label>
          </div>
        </div>
        <div className="p-2">
          <svg
            ref={canvasRef as unknown as React.RefObject<SVGSVGElement>}
            viewBox={`0 0 ${w} ${h}`}
            className="h-44 w-full touch-none rounded-sm bg-inset"
            onPointerDown={(e) => {
              (e.currentTarget as SVGSVGElement).setPointerCapture(e.pointerId);
              const fake = {
                currentTarget: {
                  getBoundingClientRect: () => (e.currentTarget as SVGSVGElement).getBoundingClientRect(),
                },
                clientX: e.clientX,
                clientY: e.clientY,
              } as unknown as React.PointerEvent<HTMLCanvasElement>;
              drawWave(fake);
            }}
            onPointerMove={(e) => {
              if (!e.buttons) return;
              const fake = {
                currentTarget: {
                  getBoundingClientRect: () => (e.currentTarget as SVGSVGElement).getBoundingClientRect(),
                },
                clientX: e.clientX,
                clientY: e.clientY,
              } as unknown as React.PointerEvent<HTMLCanvasElement>;
              drawWave(fake);
            }}
          >
            <path d={d} fill="none" stroke="var(--color-acid)" strokeWidth="1.6" />
            <line x1="0" x2={w} y1={h / 2} y2={h / 2} stroke="var(--color-line)" />
          </svg>
          <div className="mt-2 flex flex-wrap gap-1">
            {(
              [
                ["normalize", "Norm"],
                ["smooth", "Smooth"],
                ["invert", "Invert"],
                ["mirror", "Mirror"],
                ["phase", "Rotate"],
                ["randomize", "Rand"],
                ["sine", "Sine"],
                ["silence", "Clear"],
              ] as const
            ).map(([op, lab]) => (
              <button
                key={op}
                type="button"
                className="rounded-sm border border-line px-2 py-1 font-display text-[10px] tracking-wide uppercase text-muted hover:border-acid hover:text-acid"
                onClick={() => commit(applyWaveOp(frame, op))}
              >
                {lab}
              </button>
            ))}
            <button
              type="button"
              className="rounded-sm border border-line px-2 py-1 font-display text-[10px] uppercase"
              onClick={() => {
                const a = editFrame;
                const b = Math.min(table.frames - 1, a + 1);
                const fa = frame;
                const fb = table.data.slice(b * table.size, b * table.size + table.size);
                commit(interpolateFrames(fa, fb, 0.5));
              }}
            >
              Morph
            </button>
          </div>
          <div className="mt-3">
            <div className="mb-1 font-display text-[10px] tracking-[0.14em] text-muted uppercase">Harmonics</div>
            <div ref={specRef} className="flex h-24 items-end gap-px bg-inset px-1">
              {harmonics.map((m, i) => (
                <input
                  key={i}
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={m}
                  onChange={(e) => {
                    const next = harmonics.slice();
                    next[i] = Number(e.target.value);
                    commit(fromHarmonics(next, WT_SIZE));
                  }}
                  className="h-24 w-2 origin-bottom appearance-none"
                  style={{ writingMode: "vertical-lr", direction: "rtl" }}
                  title={`H${i + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>
      <section className="panel">
        <div className="panel-head">
          <span>Frames</span>
          <span className="font-mono text-[10px] text-cyan">{editFrame + 1}/{table.frames}</span>
        </div>
        <div className="grid max-h-[420px] grid-cols-4 gap-1 overflow-auto p-2">
          {Array.from({ length: table.frames }, (_, f) => (
            <button
              key={f}
              type="button"
              onClick={() => setEditFrame(f)}
              className={`h-10 rounded-sm border ${f === editFrame ? "border-acid" : "border-line"} bg-inset`}
              title={`Frame ${f + 1}`}
            >
              <svg viewBox="0 0 64 24" className="h-full w-full">
                <polyline
                  fill="none"
                  stroke={f === editFrame ? "var(--color-acid)" : "var(--color-muted)"}
                  strokeWidth="1"
                  points={Array.from({ length: 64 }, (_, x) => {
                    const i = ((x / 63) * (table.size - 1)) | 0;
                    const v = table.data[f * table.size + i]!;
                    return `${x},${12 - v * 10}`;
                  }).join(" ")}
                />
              </svg>
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1 border-t border-line p-2">
          <button
            type="button"
            className="rounded-sm border border-line px-2 py-1 font-display text-[10px] uppercase"
            onClick={() => {
              const src = table.data.slice(editFrame * table.size, editFrame * table.size + table.size);
              const dst = Math.min(table.frames - 1, editFrame + 1);
              setUserTable(writeFrame({ ...table, data: table.data.slice() }, dst, src));
            }}
          >
            Copy →
          </button>
          <Knob path={`osc.${osc}.wtPos`} label="Pos" size={40} />
        </div>
      </section>
    </div>
  );
}
