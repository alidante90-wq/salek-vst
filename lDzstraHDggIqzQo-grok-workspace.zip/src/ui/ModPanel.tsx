import { useRef } from "react";
import { LFO_SHAPES, MOD_SOURCES, SYNC_DIVS } from "@/engine/constants";
import { useSynth } from "@/store/synth-store";
import { Knob, ModSourceChip, SelectParam, Toggle } from "./Knob";

function EnvCanvas({ index }: { index: number }) {
  const env = useSynth((s) => s.patch.env[index]!);
  const live = useSynth((s) => s.viz.env[index] ?? 0);
  const w = 220;
  const h = 72;
  const A = Math.max(0.02, env.attack);
  const H = env.hold;
  const D = Math.max(0.02, env.decay);
  const R = Math.max(0.02, env.release);
  const tot = A + H + D + 0.45 + R;
  const xA = (A / tot) * w;
  const xH = xA + (H / tot) * w;
  const xD = xH + (D / tot) * w;
  const xS = xD + (0.45 / tot) * w;
  const yS = 8 + (1 - env.sustain) * (h - 16);
  const d = `M 0 ${h - 8} L ${xA} 8 L ${xH} 8 L ${xD} ${yS} L ${xS} ${yS} L ${w} ${h - 8}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-[72px] w-full">
      <rect width={w} height={h} fill="var(--color-inset)" />
      <path d={d} fill="none" stroke="var(--color-magenta)" strokeWidth="1.6" />
      <line
        x1={0}
        x2={w}
        y1={h - 8 - live * (h - 16)}
        y2={h - 8 - live * (h - 16)}
        stroke="var(--color-acid)"
        strokeWidth="1"
        opacity="0.7"
      />
    </svg>
  );
}

function LfoCanvas({ index }: { index: number }) {
  const lfo = useSynth((s) => s.patch.lfo[index]!);
  const live = useSynth((s) => s.viz.lfo[index] ?? 0);
  const setParam = useSynth((s) => s.setParam);
  const ref = useRef<SVGSVGElement>(null);
  const pts = lfo.custom;
  const d = pts
    .map((v, i) => {
      const x = (i / (pts.length - 1)) * 220;
      const y = 36 - v * 28;
      return `${i === 0 ? "M" : "L"} ${x} ${y}`;
    })
    .join(" ");
  const paint = (e: React.PointerEvent) => {
    const svg = ref.current;
    if (!svg) return;
    const r = svg.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width;
    const y = 1 - (e.clientY - r.top) / r.height;
    const i = Math.round(x * (pts.length - 1));
    const next = pts.slice();
    next[Math.max(0, Math.min(pts.length - 1, i))] = y * 2 - 1;
    setParam(`lfo.${index}.custom`, next);
    setParam(`lfo.${index}.shape`, 7);
  };
  return (
    <svg
      ref={ref}
      viewBox="0 0 220 72"
      className="h-[72px] w-full touch-none"
      onPointerDown={(e) => {
        (e.currentTarget as SVGSVGElement).setPointerCapture(e.pointerId);
        paint(e);
      }}
      onPointerMove={(e) => {
        if (e.buttons) paint(e);
      }}
    >
      <rect width="220" height="72" fill="var(--color-inset)" />
      <path d={d} fill="none" stroke="var(--color-cyan)" strokeWidth="1.6" />
      <circle cx={110 + live * 90} cy={36 - live * 28} r="3" fill="var(--color-acid)" />
    </svg>
  );
}

export function ModPanel() {
  const envI = useSynth((s) => s.selectedEnv);
  const lfoI = useSynth((s) => s.selectedLfo);
  const chaos = useSynth((s) => s.patch.chaos);
  return (
    <div className="grid min-h-0 grid-cols-1 gap-2 lg:grid-cols-2">
      <section className="panel">
        <div className="panel-head">
          <span>Envelopes</span>
          <div className="seg">
            {[0, 1, 2, 3].map((i) => (
              <button
                key={i}
                type="button"
                data-on={envI === i}
                onClick={() => useSynth.setState({ selectedEnv: i })}
              >
                E{i + 1}
              </button>
            ))}
          </div>
        </div>
        <div className="p-2">
          <EnvCanvas index={envI} />
          <div className="mt-2 flex flex-wrap justify-center gap-1">
            <Knob path={`env.${envI}.attack`} label="A" min={0.001} max={4} format={(v) => `${(v * 1000) | 0}ms`} />
            <Knob path={`env.${envI}.hold`} label="H" min={0} max={2} />
            <Knob path={`env.${envI}.decay`} label="D" min={0.01} max={4} />
            <Knob path={`env.${envI}.sustain`} label="S" />
            <Knob path={`env.${envI}.release`} label="R" min={0.01} max={6} />
            <Knob path={`env.${envI}.aCurve`} label="A crv" min={-1} max={1} bipolar />
            <Knob path={`env.${envI}.dCurve`} label="D crv" min={-1} max={1} bipolar />
            <Knob path={`env.${envI}.rCurve`} label="R crv" min={-1} max={1} bipolar />
            <Knob path={`env.${envI}.vel`} label="Vel" />
          </div>
          <div className="mt-2 flex gap-2">
            <Toggle path={`env.${envI}.loop`} label="Loop" />
            <Toggle path={`env.${envI}.retrigger`} label="Retrig" />
            <ModSourceChip id={1 + envI} label={`ENV ${envI + 1}`} />
          </div>
          <p className="mt-2 font-display text-[10px] tracking-wide text-faint uppercase">
            ENV 1 → Amp · ENV 2 → Filter 1 · ENV 3 → Filter 2
          </p>
        </div>
      </section>
      <section className="panel">
        <div className="panel-head">
          <span>LFOs</span>
          <div className="seg">
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
              <button
                key={i}
                type="button"
                data-on={lfoI === i}
                onClick={() => useSynth.setState({ selectedLfo: i })}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
        <div className="p-2">
          <LfoCanvas index={lfoI} />
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <SelectParam path={`lfo.${lfoI}.shape`} options={LFO_SHAPES} />
            <Toggle path={`lfo.${lfoI}.sync`} label="Sync" />
            <SelectParam path={`lfo.${lfoI}.syncDiv`} options={SYNC_DIVS} />
            <Toggle path={`lfo.${lfoI}.retrigger`} label="Retrig" />
            <Toggle path={`lfo.${lfoI}.bipolar`} label="Bipolar" />
            <Toggle path={`lfo.${lfoI}.oneshot`} label="One-shot" />
            <ModSourceChip id={5 + lfoI} label={`LFO ${lfoI + 1}`} />
          </div>
          <div className="mt-2 flex flex-wrap justify-center gap-1">
            <Knob path={`lfo.${lfoI}.rate`} label="Rate" />
            <Knob path={`lfo.${lfoI}.phase`} label="Phase" />
            <Knob path={`lfo.${lfoI}.delay`} label="Delay" />
            <Knob path={`lfo.${lfoI}.fade`} label="Fade" />
            <Knob path={`lfo.${lfoI}.stereo`} label="Stereo" />
            <Knob path={`lfo.${lfoI}.smooth`} label="Smooth" />
          </div>
        </div>
      </section>
      <section className="panel lg:col-span-2">
        <div className="panel-head">
          <span>Chaos Engine</span>
          <span className="font-mono text-[10px] text-violet">{chaos.type}</span>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 p-2">
          <div className="flex flex-wrap gap-1">
            {MOD_SOURCES.slice(30, 37).map((n, i) => (
              <ModSourceChip key={n} id={30 + i} label={n} />
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-1">
            <SelectParam path="chaos.type" options={["S&H", "PERLIN", "LORENZ", "LOGISTIC"]} />
            <Knob path="chaos.rate" label="Rate" size={40} />
            <Knob path="chaos.amount" label="Amt" size={40} />
            <Knob path="chaos.smooth" label="Smooth" size={40} />
            <Knob path="chaos.stereo" label="Stereo" size={40} />
          </div>
        </div>
      </section>
    </div>
  );
}
