import { FX_TYPES } from "@/engine/constants";
import { useSynth } from "@/store/synth-store";
import { Knob, SelectParam, Toggle } from "./Knob";

const PSYCH = [
  ["psych.fold", "Fold"],
  ["psych.fm", "FM"],
  ["psych.rm", "RM"],
  ["psych.phase", "Phase"],
  ["psych.space", "Space"],
  ["psych.smear", "Smear"],
  ["psych.resonator", "Reson"],
  ["psych.formant", "Formant"],
  ["psych.chaos", "Chaos"],
  ["psych.freeze", "Freeze"],
] as const;

export function FxPanel() {
  const fx = useSynth((s) => s.patch.fx);
  const setParam = useSynth((s) => s.setParam);
  const move = (i: number, dir: number) => {
    const j = i + dir;
    if (j < 0 || j >= fx.length) return;
    const a = { ...fx[i]! };
    const b = { ...fx[j]! };
    setParam(`fx.${i}.type`, b.type);
    setParam(`fx.${i}.on`, b.on);
    setParam(`fx.${i}.mix`, b.mix);
    setParam(`fx.${i}.p1`, b.p1);
    setParam(`fx.${i}.p2`, b.p2);
    setParam(`fx.${i}.p3`, b.p3);
    setParam(`fx.${j}.type`, a.type);
    setParam(`fx.${j}.on`, a.on);
    setParam(`fx.${j}.mix`, a.mix);
    setParam(`fx.${j}.p1`, a.p1);
    setParam(`fx.${j}.p2`, a.p2);
    setParam(`fx.${j}.p3`, a.p3);
  };
  return (
    <div className="grid min-h-0 grid-cols-1 gap-2 lg:grid-cols-2">
      <section className="panel">
        <div className="panel-head">
          <span>FX Chain</span>
          <span className="font-display text-[10px] text-muted">Reorderable · real DSP</span>
        </div>
        <div className="flex flex-col gap-1 p-2">
          {fx.map((slot, i) => (
            <div key={i} className="flex flex-wrap items-center gap-2 rounded-md border border-line bg-inset/50 p-1.5">
              <span className="w-5 font-mono text-[10px] text-faint">{i + 1}</span>
              <Toggle path={`fx.${i}.on`} label="On" />
              <SelectParam path={`fx.${i}.type`} options={FX_TYPES} />
              <Knob path={`fx.${i}.mix`} label="Mix" size={36} />
              <Knob path={`fx.${i}.p1`} label="P1" size={36} />
              <Knob path={`fx.${i}.p2`} label="P2" size={36} />
              <Knob path={`fx.${i}.p3`} label="P3" size={36} />
              <div className="ml-auto flex gap-1">
                <button type="button" className="border border-line px-1 text-[10px]" onClick={() => move(i, -1)}>
                  Up
                </button>
                <button type="button" className="border border-line px-1 text-[10px]" onClick={() => move(i, 1)}>
                  Dn
                </button>
              </div>
              <span className="w-full font-display text-[9px] tracking-wide text-faint uppercase">
                {slot.type === 8 || slot.type === 9
                  ? "P1 time · P2 feedback · P3 division"
                  : slot.type === 1
                    ? "P1 drive"
                    : slot.type === 10
                      ? "P2 decay"
                      : slot.type === 11
                        ? "P1 rate · P2 depth"
                        : ""}
              </span>
            </div>
          ))}
        </div>
      </section>
      <section className="panel">
        <div className="panel-head">
          <span>Psych Engine</span>
          <span className="font-display text-[10px] text-magenta">Nonlinear layer</span>
        </div>
        <div className="grid grid-cols-5 gap-2 p-3">
          {PSYCH.map(([path, label]) => (
            <Knob key={path} path={path} label={label} />
          ))}
        </div>
        <p className="px-3 pb-3 font-display text-[11px] leading-snug text-muted">
          Psych modules process the summed voice output: wavefold, self-FM, ring, phaser, resonator, formant, freeze
          buffer, smear delay, and Lorenz-driven chaos. Amounts are modulatable from the matrix.
        </p>
      </section>
    </div>
  );
}
