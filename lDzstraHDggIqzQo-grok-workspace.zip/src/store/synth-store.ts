import { create } from "zustand";
import { DESTINATIONS } from "@/engine/destinations";
import { engine } from "@/engine/host";
import { clonePatch, createInitPatch } from "@/engine/patch";
import {
  FAVORITES_KEY,
  factoryPresets,
  RECENT_KEY,
  USER_PRESET_KEY,
} from "@/engine/presets";
import type { PageId } from "@/engine/constants";
import type { Patch, VizFrame } from "@/engine/types";
import { getPath, setPath } from "@/lib/utils";
import type { WaveTable } from "@/engine/wavetables";

export interface UserPresetMeta {
  name: string;
  patch: Patch;
  savedAt: number;
}

interface SynthStore {
  patch: Patch;
  page: PageId;
  engaged: boolean;
  engineReady: boolean;
  selectedOsc: number;
  selectedEnv: number;
  selectedLfo: number;
  selectedWarp: number;
  octave: number;
  heldNotes: number[];
  draggingMod: number | null;
  viz: VizFrame;
  tables: WaveTable[];
  userTable: WaveTable;
  editFrame: number;
  factory: Patch[];
  userPresets: UserPresetMeta[];
  favorites: string[];
  recents: string[];
  query: string;
  category: string;
  browserOpen: boolean;
  contextMenu: { x: number; y: number; dest: string } | null;
  midiEnabled: boolean;
  uiScale: number;

  engage: () => Promise<void>;
  setPage: (p: PageId) => void;
  setParam: (path: string, value: number | boolean | string | number[]) => void;
  loadPatch: (p: Patch) => void;
  initPatch: () => void;
  noteOn: (note: number, vel?: number) => void;
  noteOff: (note: number) => void;
  panic: () => void;
  assignMod: (source: number, dest: string, amount?: number) => void;
  removeMod: (dest: string, source?: number) => void;
  modsFor: (dest: string) => { source: number; amount: number; slot: number }[];
  setDragging: (source: number | null) => void;
  saveUserPreset: (name?: string) => void;
  deleteUserPreset: (name: string) => void;
  toggleFavorite: (name: string) => void;
  setUserTable: (table: WaveTable) => void;
  setEditFrame: (i: number) => void;
  setContext: (m: { x: number; y: number; dest: string } | null) => void;
}

const emptyViz = (): VizFrame => ({
  wave: new Array(128).fill(0),
  spec: new Array(64).fill(0),
  voices: 0,
  wtPos: [0, 0, 0],
  cutoff: [0.7, 0.7],
  env: [0, 0, 0, 0],
  lfo: new Array(8).fill(0),
  peak: 0,
  rms: 0,
});

function loadJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export const useSynth = create<SynthStore>((set, get) => ({
  patch: createInitPatch(),
  page: "SYNTH",
  engaged: false,
  engineReady: false,
  selectedOsc: 0,
  selectedEnv: 0,
  selectedLfo: 0,
  selectedWarp: 0,
  octave: 0,
  heldNotes: [],
  draggingMod: null,
  viz: emptyViz(),
  tables: [],
  userTable: { name: "User", frames: 64, size: 2048, data: new Float32Array(64 * 2048) },
  editFrame: 0,
  factory: factoryPresets(),
  userPresets: loadJson(USER_PRESET_KEY, []),
  favorites: loadJson(FAVORITES_KEY, []),
  recents: loadJson(RECENT_KEY, []),
  query: "",
  category: "ALL",
  browserOpen: false,
  contextMenu: null,
  midiEnabled: false,
  uiScale: 1,

  engage: async () => {
    await engine.engage();
    engine.onViz = (v) => set({ viz: v });
    engine.loadPatch(get().patch);
    set({ engaged: true, engineReady: true });
  },

  setPage: (page) => set({ page }),

  setParam: (path, value) => {
    const patch = clonePatch(get().patch);
    setPath(patch as unknown as Record<string, unknown>, path, value);
    engine.set(path, value);
    set({ patch });
  },

  loadPatch: (p) => {
    const patch = clonePatch(p);
    engine.loadPatch(patch);
    const recents = [p.name, ...get().recents.filter((n) => n !== p.name)].slice(0, 12);
    if (typeof window !== "undefined") localStorage.setItem(RECENT_KEY, JSON.stringify(recents));
    set({ patch, recents, browserOpen: false });
  },

  initPatch: () => get().loadPatch(createInitPatch()),

  noteOn: (note, vel = 0.85) => {
    engine.noteOn(note, vel);
    set({ heldNotes: [...new Set([...get().heldNotes, note])] });
  },
  noteOff: (note) => {
    engine.noteOff(note);
    set({ heldNotes: get().heldNotes.filter((n) => n !== note) });
  },
  panic: () => {
    engine.panic();
    set({ heldNotes: [] });
  },

  assignMod: (source, dest, amount = 0.35) => {
    const patch = clonePatch(get().patch);
    const existing = patch.matrix.find((s) => s.on && s.source === source && s.dest === dest);
    if (existing) {
      existing.amount = amount;
    } else {
      const slot = patch.matrix.find((s) => !s.on);
      if (!slot) return;
      slot.on = true;
      slot.source = source;
      slot.dest = dest;
      slot.amount = amount;
      slot.bipolar = DESTINATIONS.find((d) => d.id === dest)?.bipolar ?? true;
    }
    engine.loadPatch(patch);
    set({ patch });
  },

  removeMod: (dest, source) => {
    const patch = clonePatch(get().patch);
    for (const s of patch.matrix) {
      if (s.on && s.dest === dest && (source == null || s.source === source)) {
        s.on = false;
        s.dest = "";
        s.source = 0;
        s.amount = 0.5;
      }
    }
    engine.loadPatch(patch);
    set({ patch });
  },

  modsFor: (dest) =>
    get()
      .patch.matrix.map((s, slot) => ({ ...s, slot }))
      .filter((s) => s.on && s.dest === dest)
      .map((s) => ({ source: s.source, amount: s.amount, slot: s.slot })),

  setDragging: (source) => set({ draggingMod: source }),

  saveUserPreset: (name) => {
    const patch = clonePatch(get().patch);
    patch.name = name || patch.name || "User Patch";
    const list = get().userPresets.filter((u) => u.name !== patch.name);
    list.unshift({ name: patch.name, patch, savedAt: Date.now() });
    if (typeof window !== "undefined") localStorage.setItem(USER_PRESET_KEY, JSON.stringify(list));
    set({ userPresets: list, patch });
  },

  deleteUserPreset: (name) => {
    const list = get().userPresets.filter((u) => u.name !== name);
    if (typeof window !== "undefined") localStorage.setItem(USER_PRESET_KEY, JSON.stringify(list));
    set({ userPresets: list });
  },

  toggleFavorite: (name) => {
    const cur = get().favorites;
    const next = cur.includes(name) ? cur.filter((n) => n !== name) : [...cur, name];
    if (typeof window !== "undefined") localStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
    set({ favorites: next });
  },

  setUserTable: (table) => {
    engine.send({
      type: "userTable",
      data: table.data.slice().buffer,
      frames: table.frames,
      size: table.size,
    });
    const tables = get().tables.slice();
    tables[15] = table;
    set({ userTable: table, tables });
    get().setParam("osc." + get().selectedOsc + ".table", 15);
  },

  setEditFrame: (i) => set({ editFrame: i }),
  setContext: (m) => set({ contextMenu: m }),
}));

export function paramNumber(path: string): number {
  const v = getPath(useSynth.getState().patch, path);
  return typeof v === "number" ? v : Number(v) || 0;
}

export function paramBool(path: string): boolean {
  return Boolean(getPath(useSynth.getState().patch, path));
}
