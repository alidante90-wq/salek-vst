import { createFileRoute } from "@tanstack/react-router";
import { SynthApp } from "@/ui/SynthApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SynthApp />;
}
