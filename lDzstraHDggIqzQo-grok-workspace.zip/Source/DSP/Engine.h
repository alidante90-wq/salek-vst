#pragma once
#include <JuceHeader.h>
#include <array>
#include <cmath>
#include <vector>

namespace salek
{
inline float midiHz(float n) { return 440.0f * std::pow(2.0f, (n - 69.0f) / 12.0f); }
inline float clamp(float x, float a, float b) { return juce::jlimit(a, b, x); }
inline float expMap(float x, float lo, float hi) { return lo * std::pow(hi / lo, clamp(x, 0.0f, 1.0f)); }
inline float tanhF(float x)
{
    if (x < -3.0f) return -1.0f;
    if (x > 3.0f) return 1.0f;
    const float x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

struct SVF
{
    float ic1 = 0, ic2 = 0;
    void reset() { ic1 = ic2 = 0; }
    float lp(float x, float cutoff, float res, float sr)
    {
        const float g = std::tan(juce::MathConstants<float>::pi * clamp(cutoff, 20.0f, sr * 0.45f) / sr);
        const float k = 2.0f - 2.0f * clamp(res, 0.0f, 0.97f);
        const float hp = (x - ic1 * k - ic2) / (1.0f + g * (g + k));
        const float bp = hp * g + ic1;
        const float l = bp * g + ic2;
        ic1 = hp * g + bp;
        ic2 = bp * g + l;
        return l;
    }
};

struct Env
{
    int stage = 0;
    float t = 0, val = 0, relFrom = 0;
    void noteOn() { stage = 1; t = 0; val = 0; }
    void noteOff() { stage = 5; t = 0; relFrom = val; }
    float process(float a, float d, float s, float r, float sr)
    {
        a = juce::jmax(1.0f / sr, a); d = juce::jmax(1.0f / sr, d); r = juce::jmax(1.0f / sr, r);
        if (stage == 1) { t += 1.0f / sr; val = juce::jmin(1.0f, t / a); if (val >= 1.0f) { stage = 3; t = 0; } }
        else if (stage == 3) { t += 1.0f / sr; const float u = juce::jmin(1.0f, t / d); val = 1.0f - u * (1.0f - s); if (u >= 1.0f) { stage = 4; val = s; } }
        else if (stage == 4) val = s;
        else if (stage == 5) { t += 1.0f / sr; const float u = juce::jmin(1.0f, t / r); val = relFrom * (1.0f - u); if (u >= 1.0f) { stage = 0; val = 0; } }
        return val;
    }
};

struct Osc
{
    float phase = 0, fb = 0;
    float tick(int mode, float freq, float sr, float wtPos, const float* table, int frames, int size,
               float fm, int analog, float pwm, float fold)
    {
        const float dt = freq / sr;
        phase += dt;
        if (phase >= 2048.0f) phase -= 2048.0f;
        float ph = phase + fm + fb * 0.1f;
        ph -= std::floor(ph);
        float s = 0;
        if (mode == 1)
        {
            if (analog == 0) s = std::sin(juce::MathConstants<float>::twoPi * ph);
            else if (analog == 2) s = 2.0f * ph - 1.0f;
            else s = ph < pwm ? 1.0f : -1.0f;
        }
        else
        {
            const float f = wtPos * (float) (frames - 1);
            const int f0 = (int) f;
            const int f1 = juce::jmin(frames - 1, f0 + 1);
            const float ft = f - (float) f0;
            const float p = ph * (float) size;
            const int i0 = (int) p;
            const int i1 = (i0 + 1) % size;
            const float pt = p - (float) i0;
            const float a = table[f0 * size + i0] + (table[f0 * size + i1] - table[f0 * size + i0]) * pt;
            const float b = table[f1 * size + i0] + (table[f1 * size + i1] - table[f1 * size + i0]) * pt;
            s = a + (b - a) * ft;
        }
        if (fold > 0.001f) s = tanhF(std::sin(s * (1.0f + fold * 6.0f) * juce::MathConstants<float>::pi));
        fb = s;
        return s;
    }
};

struct Voice
{
    bool active = false;
    int note = 60;
    float vel = 1, glide = 60, age = 0;
    Osc osc[3];
    Osc sub, mod;
    Env amp, fenv;
    SVF f1, f2;
    void start(int n, float v)
    {
        active = true; note = n; vel = v; glide = n; age = 0;
        amp.noteOn(); fenv.noteOn();
        for (auto& o : osc) o.phase = 0;
    }
    void stop() { amp.noteOff(); fenv.noteOff(); }
};

struct Params
{
    float oscLevel[3] { 0.78f, 0.0f, 0.0f };
    float oscWt[3] { 0.0f, 0.4f, 0.2f };
    float oscFine[3] { 0, 0, 0 };
    float oscOct[3] { 0, 0, 1 };
    float oscFm[3] { 0, 0, 0 };
    float oscOn[3] { 1, 0, 0 };
    float cutoff = 0.68f, res = 0.18f, drive = 0.1f, envAmt = 0.22f;
    float attack = 0.004f, decay = 0.28f, sustain = 0.78f, release = 0.18f;
    float fAttack = 0.01f, fDecay = 0.32f, fSustain = 0.35f, fRelease = 0.22f;
    float subOn = 1, subLevel = 0.35f;
    float master = 0.72f;
    float fold = 0, delayMix = 0, delayTime = 0.25f, delayFb = 0.3f;
    float reverb = 0, unison = 1, detune = 0.12f;
    float lfoRate = 0.4f, lfoAmt = 0;
    float warp = 0, psychFm = 0;
};

struct Engine
{
    static constexpr int kWtSize = 2048;
    static constexpr int kFrames = 64;
    static constexpr int kVoices = 12;
    float sr = 44100;
    Params p;
    std::array<Voice, kVoices> voices;
    std::vector<float> table;
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> dlyL { 192000 }, dlyR { 192000 };
    float lfoPh = 0, dcL = 0, dcR = 0;

    void prepare(double sampleRate, int /*block*/)
    {
        sr = (float) sampleRate;
        buildTable();
        dlyL.reset(); dlyR.reset();
        dlyL.prepare({ sampleRate, 512, 1 });
        dlyR.prepare({ sampleRate, 512, 1 });
        dlyL.setMaximumDelayInSamples((int) (sampleRate * 2));
        dlyR.setMaximumDelayInSamples((int) (sampleRate * 2));
    }

    void buildTable()
    {
        table.assign((size_t) kFrames * kWtSize, 0.0f);
        for (int f = 0; f < kFrames; ++f)
        {
            const float t = f / (float) (kFrames - 1);
            float peak = 1.0e-6f;
            for (int i = 0; i < kWtSize; ++i)
            {
                const float ph = i / (float) kWtSize;
                float s = 0;
                const int harm = 2 + (int) (t * 28);
                for (int n = 1; n <= harm; ++n)
                    s += std::sin(juce::MathConstants<float>::twoPi * n * ph) / (float) n;
                s *= 2.0f / juce::MathConstants<float>::pi;
                if (t > 0.5f)
                {
                    const float sine = std::sin(juce::MathConstants<float>::twoPi * ph);
                    s = s * (1.0f - (t - 0.5f) * 2.0f) + sine * (t - 0.5f) * 2.0f;
                }
                table[(size_t) f * kWtSize + (size_t) i] = s;
                peak = juce::jmax(peak, std::abs(s));
            }
            const float g = 0.99f / peak;
            for (int i = 0; i < kWtSize; ++i) table[(size_t) f * kWtSize + (size_t) i] *= g;
        }
    }

    void noteOn(int note, float vel)
    {
        Voice* slot = nullptr;
        Voice* oldest = &voices[0];
        for (auto& v : voices)
        {
            if (!v.active) { slot = &v; break; }
            if (v.age > oldest->age) oldest = &v;
        }
        (slot ? slot : oldest)->start(note, vel);
    }
    void noteOff(int note)
    {
        for (auto& v : voices) if (v.active && v.note == note) v.stop();
    }
    void allOff() { for (auto& v : voices) { v.active = false; v.amp.stage = 0; } }

    void render(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
    {
        buffer.clear();
        auto* L = buffer.getWritePointer(0);
        auto* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer(1) : L;
        const int n = buffer.getNumSamples();
        int midiIdx = 0;
        auto it = midi.findNextSamplePosition(0);
        for (int i = 0; i < n; ++i)
        {
            while (it != midi.cend() && (*it).samplePosition == i)
            {
                const auto msg = (*it).getMessage();
                if (msg.isNoteOn()) noteOn(msg.getNoteNumber(), msg.getFloatVelocity());
                else if (msg.isNoteOff()) noteOff(msg.getNoteNumber());
                else if (msg.isAllNotesOff() || msg.isAllSoundOff()) allOff();
                ++it;
            }
            lfoPh += expMap(p.lfoRate, 0.05f, 12.0f) / sr;
            const float lfo = std::sin(juce::MathConstants<float>::twoPi * lfoPh);
            float mixL = 0, mixR = 0;
            for (auto& v : voices)
            {
                if (!v.active) continue;
                v.age += 1.0f;
                const float a = v.amp.process(p.attack, p.decay, p.sustain, p.release, sr);
                const float fe = v.fenv.process(p.fAttack, p.fDecay, p.fSustain, p.fRelease, sr);
                if (v.amp.stage == 0 && a <= 0.0001f) { v.active = false; continue; }
                const float key = (float) v.note;
                float fm = 0;
                if (p.oscOn[1] > 0.5f)
                {
                    const float f1 = midiHz(key + p.oscOct[1] * 12.0f);
                    fm = v.osc[1].tick(0, f1, sr, clamp(p.oscWt[1] + lfo * p.lfoAmt * 0.2f, 0.f, 1.f),
                                       table.data(), kFrames, kWtSize, 0, 0, 0.5f, 0) * p.oscFm[0] * 2.0f;
                }
                float s = 0;
                if (p.oscOn[0] > 0.5f)
                {
                    const int uni = juce::jlimit(1, 5, (int) p.unison);
                    for (int u = 0; u < uni; ++u)
                    {
                        const float cents = uni == 1 ? 0.0f : ((u / (float) (uni - 1)) - 0.5f) * 2.0f * p.detune * 40.0f;
                        const float f0 = midiHz(key + p.oscOct[0] * 12.0f + cents / 100.0f);
                        s += v.osc[0].tick(0, f0, sr, clamp(p.oscWt[0] + lfo * p.lfoAmt, 0.f, 1.f),
                                           table.data(), kFrames, kWtSize, fm, 0, 0.5f, p.fold) / std::sqrt((float) uni);
                    }
                    s *= p.oscLevel[0];
                }
                if (p.oscOn[2] > 0.5f)
                {
                    const float f2 = midiHz(key + p.oscOct[2] * 12.0f);
                    s += v.osc[2].tick(0, f2, sr, p.oscWt[2], table.data(), kFrames, kWtSize, 0, 0, 0.5f, 0) * p.oscLevel[2];
                }
                if (p.subOn > 0.5f)
                    s += v.sub.tick(1, midiHz(key - 12.0f), sr, 0, table.data(), kFrames, kWtSize, 0, 0, 0.5f, 0) * p.subLevel;
                if (p.psychFm > 0.001f)
                    s = std::sin(s * juce::MathConstants<float>::pi + fm * p.psychFm);
                float cut = expMap(clamp(p.cutoff + p.envAmt * fe + lfo * p.lfoAmt * 0.15f, 0.0f, 1.1f), 20.0f, 16000.0f);
                s = v.f1.lp(tanhF(s * (1.0f + p.drive * 3.0f)), cut, p.res, sr);
                s *= a * (0.3f + 0.7f * v.vel);
                mixL += s; mixR += s;
            }
            if (p.delayMix > 0.001f)
            {
                dlyL.setDelay(juce::jmax(1.0f, p.delayTime * sr));
                dlyR.setDelay(juce::jmax(1.0f, p.delayTime * sr * 1.07f));
                const float dl = dlyL.popSample(0);
                const float dr = dlyR.popSample(0);
                dlyL.pushSample(0, mixL + dl * p.delayFb);
                dlyR.pushSample(0, mixR + dr * p.delayFb);
                mixL += dl * p.delayMix;
                mixR += dr * p.delayMix;
            }
            mixL *= p.master; mixR *= p.master;
            mixL = tanhF(mixL); mixR = tanhF(mixR);
            dcL = dcL * 0.995f + mixL * 0.005f;
            dcR = dcR * 0.995f + mixR * 0.005f;
            L[i] = mixL - dcL;
            R[i] = mixR - dcR;
            juce::ignoreUnused(midiIdx);
        }
    }
};
}
