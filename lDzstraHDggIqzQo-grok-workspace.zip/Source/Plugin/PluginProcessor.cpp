#include "PluginProcessor.h"
#include "PluginEditor.h"

static juce::String pid(const juce::String& s) { return s; }

SalekHypercoreAudioProcessor::SalekHypercoreAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMS", createLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout SalekHypercoreAudioProcessor::createLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    auto fl = [](const juce::String& id, const juce::String& name, float def, float min = 0.f, float max = 1.f) {
        return std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { id, 1 }, name, juce::NormalisableRange<float>(min, max), def);
    };
    p.push_back(fl("oscA_level", "OSC A Level", 0.78f));
    p.push_back(fl("oscA_wt", "OSC A WT", 0.0f));
    p.push_back(fl("oscA_fm", "OSC A FM", 0.0f));
    p.push_back(fl("oscA_on", "OSC A On", 1.0f));
    p.push_back(fl("oscB_level", "OSC B Level", 0.0f));
    p.push_back(fl("oscB_wt", "OSC B WT", 0.4f));
    p.push_back(fl("oscB_on", "OSC B On", 0.0f));
    p.push_back(fl("oscC_level", "OSC C Level", 0.0f));
    p.push_back(fl("oscC_on", "OSC C On", 0.0f));
    p.push_back(fl("cutoff", "Filter Cutoff", 0.68f));
    p.push_back(fl("res", "Filter Res", 0.18f));
    p.push_back(fl("drive", "Filter Drive", 0.1f));
    p.push_back(fl("envAmt", "Filter Env", 0.22f));
    p.push_back(fl("attack", "Amp Attack", 0.01f));
    p.push_back(fl("decay", "Amp Decay", 0.28f));
    p.push_back(fl("sustain", "Amp Sustain", 0.78f));
    p.push_back(fl("release", "Amp Release", 0.18f));
    p.push_back(fl("subOn", "Sub On", 1.0f));
    p.push_back(fl("subLevel", "Sub Level", 0.35f));
    p.push_back(fl("master", "Master", 0.72f));
    p.push_back(fl("fold", "Psych Fold", 0.0f));
    p.push_back(fl("psychFm", "Psych FM", 0.0f));
    p.push_back(fl("delayMix", "Delay Mix", 0.0f));
    p.push_back(fl("delayTime", "Delay Time", 0.25f));
    p.push_back(fl("delayFb", "Delay FB", 0.3f));
    p.push_back(fl("unison", "Unison", 1.0f, 1.0f, 5.0f));
    p.push_back(fl("detune", "Detune", 0.12f));
    p.push_back(fl("lfoRate", "LFO Rate", 0.4f));
    p.push_back(fl("lfoAmt", "LFO Amount", 0.0f));
    juce::ignoreUnused(pid);
    return { p.begin(), p.end() };
}

void SalekHypercoreAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    engine.prepare(sampleRate, samplesPerBlock);
}

bool SalekHypercoreAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto& main = layouts.getMainOutputChannelSet();
    return main == juce::AudioChannelSet::mono() || main == juce::AudioChannelSet::stereo();
}

void SalekHypercoreAudioProcessor::pullParams()
{
    auto g = [this](const char* id) { return apvts.getRawParameterValue(id)->load(); };
    engine.p.oscLevel[0] = g("oscA_level");
    engine.p.oscWt[0] = g("oscA_wt");
    engine.p.oscFm[0] = g("oscA_fm");
    engine.p.oscOn[0] = g("oscA_on");
    engine.p.oscLevel[1] = g("oscB_level");
    engine.p.oscWt[1] = g("oscB_wt");
    engine.p.oscOn[1] = g("oscB_on");
    engine.p.oscLevel[2] = g("oscC_level");
    engine.p.oscOn[2] = g("oscC_on");
    engine.p.cutoff = g("cutoff");
    engine.p.res = g("res");
    engine.p.drive = g("drive");
    engine.p.envAmt = g("envAmt");
    engine.p.attack = 0.001f + g("attack") * 2.0f;
    engine.p.decay = 0.02f + g("decay") * 2.0f;
    engine.p.sustain = g("sustain");
    engine.p.release = 0.02f + g("release") * 3.0f;
    engine.p.subOn = g("subOn");
    engine.p.subLevel = g("subLevel");
    engine.p.master = g("master");
    engine.p.fold = g("fold");
    engine.p.psychFm = g("psychFm");
    engine.p.delayMix = g("delayMix");
    engine.p.delayTime = 0.05f + g("delayTime") * 0.7f;
    engine.p.delayFb = g("delayFb");
    engine.p.unison = g("unison");
    engine.p.detune = g("detune");
    engine.p.lfoRate = g("lfoRate");
    engine.p.lfoAmt = g("lfoAmt");
}

void SalekHypercoreAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    pullParams();
    engine.render(buffer, midi);
}

void SalekHypercoreAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, destData);
}

void SalekHypercoreAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessorEditor* SalekHypercoreAudioProcessor::createEditor()
{
    return new SalekHypercoreAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new SalekHypercoreAudioProcessor();
}
