#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class SalekHypercoreAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit SalekHypercoreAudioProcessorEditor(SalekHypercoreAudioProcessor&);
    ~SalekHypercoreAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    SalekHypercoreAudioProcessor& proc;
    juce::Slider cutoff, res, wt, fm, master, fold, lfoAmt;
    juce::Label title, sub;
    using Attach = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<Attach> aCut, aRes, aWt, aFm, aMaster, aFold, aLfo;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SalekHypercoreAudioProcessorEditor)
};
