#include "PluginEditor.h"

SalekHypercoreAudioProcessorEditor::SalekHypercoreAudioProcessorEditor(SalekHypercoreAudioProcessor& p)
    : AudioProcessorEditor(&p), proc(p)
{
    setSize(720, 320);
    auto setup = [this](juce::Slider& s) {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 64, 16);
        addAndMakeVisible(s);
    };
    setup(cutoff); setup(res); setup(wt); setup(fm); setup(master); setup(fold); setup(lfoAmt);
    aCut = std::make_unique<Attach>(proc.apvts, "cutoff", cutoff);
    aRes = std::make_unique<Attach>(proc.apvts, "res", res);
    aWt = std::make_unique<Attach>(proc.apvts, "oscA_wt", wt);
    aFm = std::make_unique<Attach>(proc.apvts, "oscA_fm", fm);
    aMaster = std::make_unique<Attach>(proc.apvts, "master", master);
    aFold = std::make_unique<Attach>(proc.apvts, "fold", fold);
    aLfo = std::make_unique<Attach>(proc.apvts, "lfoAmt", lfoAmt);
    title.setText("SALEK HYPERCORE", juce::dontSendNotification);
    title.setColour(juce::Label::textColourId, juce::Colour(0xffc6ff4a));
    title.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    addAndMakeVisible(title);
    sub.setText("VST3 instrument — cutoff / WT / FM / fold / LFO. Full matrix lives in the editor host session.",
                juce::dontSendNotification);
    sub.setColour(juce::Label::textColourId, juce::Colour(0xff8b95a8));
    addAndMakeVisible(sub);
}

void SalekHypercoreAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff07080c));
    g.setColour(juce::Colour(0xff2a3140));
    g.drawRect(getLocalBounds(), 1);
}

void SalekHypercoreAudioProcessorEditor::resized()
{
    auto r = getLocalBounds().reduced(16);
    title.setBounds(r.removeFromTop(28));
    sub.setBounds(r.removeFromTop(22));
    r.removeFromTop(8);
    const int w = r.getWidth() / 7;
    cutoff.setBounds(r.removeFromLeft(w));
    res.setBounds(r.removeFromLeft(w));
    wt.setBounds(r.removeFromLeft(w));
    fm.setBounds(r.removeFromLeft(w));
    fold.setBounds(r.removeFromLeft(w));
    lfoAmt.setBounds(r.removeFromLeft(w));
    master.setBounds(r);
}
